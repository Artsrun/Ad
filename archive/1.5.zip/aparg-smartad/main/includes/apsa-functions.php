<?php
defined('ABSPATH') or die('No script kiddies please!');

// get elements options structure
function apsa_get_element_options_struct($element_options, $element_type, $campaign_type, $event_count) {
    global $apsa_admin_labels;

    $restrict_visits = isset($element_options['restrict_visits']) ? $element_options['restrict_visits'] : "";
    $bg_type = isset($element_options['background_type']) ? $element_options['background_type'] : "";
    $auto_play_video = isset($element_options['auto_play_video']) ? $element_options['auto_play_video'] : "";

    if (trim($restrict_visits) != "" && $event_count >= $restrict_visits) {
        $visit_text = $apsa_admin_labels['visits_warning_message'];
        $warning_visit_class = 'apsa-warning-message';
    } else {
        $visit_text = $apsa_admin_labels['default'] . ' ' . $apsa_admin_labels['max_visits_def'];
        $warning_visit_class = '';
    }

    $htm = '<li class="apsa-form-item apsa-element-usual-input apsa-child-option">' .
            '<span>' . $apsa_admin_labels["max_clicks"] . '</span>' .
            '<span class="apsa-with-question" title="' . ucfirst($apsa_admin_labels["detailed_description"]) . '" data-apsa-message="' . $apsa_admin_labels["max_clicks_desc"] . '"></span>' .
            '<div class="apsa-input-block">' .
            '<input type="text" class="apsa-positive-int ' . (trim($restrict_visits) != "" && $event_count >= $restrict_visits ? ' apsa-overdue-element ' : '') . '" name="restrict_visits" value="' . $restrict_visits . '" />' .
            '</div>' .
            '<span class="apsa-input-message  ' . $warning_visit_class . '" data-apsa-default-message="' . $apsa_admin_labels['default'] . ' ' . $apsa_admin_labels['max_visits_def'] . '">' . $visit_text . '</span>' .
            '</li>' .
            '<li class="apsa-form-item apsa-element-extra-large-input apsa-child-option">' .
            '<span>' . $apsa_admin_labels["link_to"] . '</span>' .
            '<span class="apsa-with-question" title="' . ucfirst($apsa_admin_labels["detailed_description"]) . '" data-apsa-message="' . $apsa_admin_labels["link_to_desc"] . '"></span>' .
            '<div class="apsa-input-block">' .
            '<input type="text" class="apsa-link apsa-broken-link" name="link_to" value="' . (isset($element_options['link_to']) ? $element_options['link_to'] : "") . '" />' .
            '</div>' .
            '<span class="apsa-input-message"></span>' .
            '</li>' .
            '<li class="apsa-form-item apsa-element-large-input apsa-child-option">';
    if ($element_type == 'image'):
        $htm .= '<span>' . $apsa_admin_labels["image_file"] . '</span>' .
                '<span class="apsa-with-question" title="' . ucfirst($apsa_admin_labels["detailed_description"]) . '" data-apsa-message="' . $apsa_admin_labels["image_file_desc"] . '"></span>' .
                '<div class="apsa-input-block">' .
                '<div class="apsa-upload-wrap">' .
                '<button type="button" class="apsa-upload-file button" data-apsa-file-type="image">' . $apsa_admin_labels["choose_img_file"] . '</button>' .
                '</div>' .
                '<div class="apsa-upload-input-wrap">' .
                '<input type="text" class="apsa-hold-element-content" name="element_content" value="' . (isset($element_options['element_content']) ? $element_options['element_content'] : "") . '" />' .
                '</div>' .
                '</div>' .
                '<span class="apsa-input-message"></span>';

    elseif ($element_type == 'flash'):
        $htm .= '<span>' . $apsa_admin_labels["swf_file"] . '</span>' .
                '<span class="apsa-with-question" title="' . ucfirst($apsa_admin_labels["detailed_description"]) . '" data-apsa-message="' . $apsa_admin_labels["swf_file_desc"] . '"></span>' .
                '<div class="apsa-input-block">' .
                '<div class="apsa-upload-wrap">' .
                '<button type="button" class="apsa-upload-file button" data-apsa-file-type="application">' . $apsa_admin_labels["choose_swf_file"] . '</button>' .
                '</div>' .
                '<div class="apsa-upload-input-wrap">' .
                '<input type="text" class="apsa-hold-element-content" name="element_content" value="' . ( isset($element_options['element_content']) ? $element_options['element_content'] : "" ) . '" />' .
                '</div>' .
                '</div>' .
                '<span class="apsa-input-message"></span>';
    elseif ($element_type == 'video'):
        $url_data = isset($element_options['element_content']) ? json_decode($element_options['element_content'], TRUE) : "";
        $video_url = (!empty($url_data) ? $url_data['origin_url'] : '');
        $htm .= '<span>' . $apsa_admin_labels["video_url"] . '</span>' .
                '<span class="apsa-with-question" title="' . ucfirst($apsa_admin_labels["detailed_description"]) . '" data-apsa-message="' . $apsa_admin_labels["video_url_desc"] . '"></span>' .
                '<div class="apsa-input-block">' .
                '<input type="text" class="apsa-hold-element-content apsa-video-url" name="element_content" value="' . $video_url . '" />' .
                '</div>' .
                '<span class="apsa-input-message"></span>';
    elseif ($element_type == 'iframe'):
        $htm .= '<span>' . $apsa_admin_labels["source_url"] . '</span>' .
                '<span class="apsa-with-question" title="' . ucfirst($apsa_admin_labels["detailed_description"]) . '" data-apsa-message="' . $apsa_admin_labels["source_url_desc"] . '"></span>' .
                '<div class="apsa-input-block">' .
                '<input type="text" class="apsa-link apsa-broken-link apsa-hold-element-content" name="element_content" value="' . (isset($element_options['element_content']) ? $element_options['element_content'] : "" ) . '"" />' .
                '</div>' .
                '<span class="apsa-input-message"></span>';
    elseif ($element_type == 'code'):
        $htm .= '<span>' . $apsa_admin_labels["html_code"] . '</span>' .
                '<span class="apsa-with-question" title="' . ucfirst($apsa_admin_labels["detailed_description"]) . '" data-apsa-message="' . $apsa_admin_labels["html_code_desc"] . '"></span>' .
                '<div class="apsa-input-block apsa-code-button">' .
                '<input type="button" class="button apsa-type-code" value="' . $apsa_admin_labels["type_code"] . '" />' .
                '<textarea class="apsa-hold-element-content apsa-hold-code-content apsa-hidden-textarea" name="element_content">' . (isset($element_options['element_content']) ? $element_options['element_content'] : "" ) . '</textarea>' .
                '</div>' .
                '<span class="apsa-input-message"></span>';
    endif;
    $htm .= '</li>';
    if ($campaign_type == 'background') {
        if ($element_type == 'image') {
            $htm .= '<li class="apsa-form-item apsa-element-option-select apsa-child-option">'
                    . '<span>' . $apsa_admin_labels["bg_img_type"] . '</span>'
                    . '<span class="apsa-with-question" title="' . ucfirst($apsa_admin_labels["detailed_description"]) . '" data-apsa-message="' . $apsa_admin_labels["bg_img_type_desc"] . '"></span>'
                    . '<div>'
                    . '<select name="background_type">'
                    . '<option value="cover_bg"' . ($bg_type == 'cover_bg' ? ' selected="selected"' : "" ) . '>' . $apsa_admin_labels["cover"] . '</option>'
                    . '<option value="repeat_bg"' . ($bg_type == 'repeat_bg' ? ' selected="selected"' : "" ) . '>' . $apsa_admin_labels["repeat"] . '</option>'
                    . '<option value="cover_bg_parallax"' . ($bg_type == 'cover_bg_parallax' ? ' selected="selected"' : "" ) . '>' . $apsa_admin_labels["cover"] . ' (Parallax)' . '</option>'
                    . '<option value="repeat_bg_parallax"' . ($bg_type == 'repeat_bg_parallax' ? ' selected="selected"' : "" ) . '>' . $apsa_admin_labels["repeat"] . ' (Parallax)' . '</option>'
                    . '</select>'
                    . '</div>'
                    . '</li>';
        }
    }
    if ($campaign_type == 'popup') {
        if ($element_type == 'image') {
            $htm .= '<li class="apsa-form-item apsa-element-option-select apsa-child-option">'
                    . '<span>' . $apsa_admin_labels["bg_img_type"] . '</span>'
                    . '<span class="apsa-with-question" title="' . ucfirst($apsa_admin_labels["detailed_description"]) . '" data-apsa-message="' . $apsa_admin_labels["bg_img_type_desc"] . '"></span>'
                    . '<div>'
                    . '<select name="background_type">'
                    . '<option value="contain"' . ($bg_type == 'contain' ? ' selected="selected"' : "" ) . '>' . $apsa_admin_labels["contain"] . '</option>'
                    . '<option value="cover"' . ($bg_type == 'cover' ? ' selected="selected"' : "" ) . '>' . $apsa_admin_labels["cover"] . '</option>'
                    . '</select>'
                    . '</div>'
                    . '</li>';
        }
        if ($element_type == 'video') {
            $htm .= '<li class="apsa-form-item apsa-element-option-select apsa-child-option">'
                    . '<span>' . $apsa_admin_labels["auto_play_video"] . '</span>'
                    . '<span class="apsa-with-question" title=" ' . ucfirst($apsa_admin_labels["detailed_description"]) . '" data-apsa-message="' . $apsa_admin_labels["auto_play_video_desc"] . '"></span>'
                    . '<div>'
                    . '<input type="checkbox" ' . (!empty($auto_play_video) ? ' checked' : "") . '/>'
                    . '<input type="hidden" class="apsa-hold-checkbox" name="auto_play_video"' . (!empty($auto_play_video) ? ' value="on"' : "") . '>'
                    . '</div>'
                    . '</li>';
        }
    }
    if ($campaign_type == 'embed') {
        if ($element_type == 'image') {
            $htm .= '<li class="apsa-form-item apsa-element-option-select apsa-child-option">'
                    . '<span>' . $apsa_admin_labels["bg_img_type"] . '</span>'
                    . '<span class="apsa-with-question" title="' . ucfirst($apsa_admin_labels["detailed_description"]) . '" data-apsa-message="' . $apsa_admin_labels["bg_img_type_desc"] . '"></span>'
                    . '<div>'
                    . '<select name="background_type">'
                    . '<option value="contain"' . ($bg_type == 'contain' ? ' selected="selected"' : "" ) . '>' . $apsa_admin_labels["contain"] . '</option>'
                    . '<option value="cover"' . ($bg_type == 'cover' ? ' selected="selected"' : "" ) . '>' . $apsa_admin_labels["cover"] . '</option>'
                    . '</select>'
                    . '</div>'
                    . '</li>';
        }
        if ($element_type == 'video') {
            $htm .= '<li class="apsa-form-item apsa-element-option-select apsa-child-option">'
                    . '<span>' . $apsa_admin_labels["auto_play_video"] . '</span>'
                    . '<span class="apsa-with-question" title=" ' . ucfirst($apsa_admin_labels["detailed_description"]) . '" data-apsa-message="' . $apsa_admin_labels["auto_play_video_desc"] . '"></span>'
                    . '<div>'
                    . '<input type="checkbox" ' . (!empty($auto_play_video) ? ' checked' : "") . '/>'
                    . '<input type="hidden" class="apsa-hold-checkbox" name="auto_play_video"' . (!empty($auto_play_video) ? ' value="on"' : "") . '>'
                    . '</div>'
                    . '</li>';
        }
    }
    return $htm;
}

/**
 * Get campaign elements from databse with customm order
 * 
 * @global {object} $wpdb
 * @param {int} $campaign_id
 * @param {str} $order_by
 * @param {str} $order
 * @param {boolean} $non_empty
 * @return {array}
 */
function apsa_get_campaign_elements($campaign_id, $order_by = 'priority', $order = 'ASC', $non_empty = FALSE) {

    /** Get elements from wp_apsa_elements  table */
    global $wpdb;

    $elements_table = $wpdb->prefix . 'apsa_elements';
    $element_options_table = $wpdb->prefix . 'apsa_element_options';

    $order_clause = '';

    if (!empty($order_by) && !empty($order)) {
        $order_clause = ' ORDER BY ' . (($non_empty) ? $elements_table . '.' : '') . $order_by . ' ' . $order;
    }

    if ($non_empty) {
        $campaign_elements = $wpdb->get_results('SELECT ' . $elements_table . '.* FROM ' . $elements_table . ' INNER JOIN ' . $element_options_table . ' ON ' . $elements_table . '.id = ' . $element_options_table . '.element_id WHERE ' . $elements_table . '.campaign_id = ' . $campaign_id . ' GROUP BY ' . $elements_table . '.id' . $order_clause, ARRAY_A);
    } else {
        $campaign_elements = $wpdb->get_results('SELECT * FROM ' . $elements_table . ' WHERE campaign_id = ' . $campaign_id . $order_clause, ARRAY_A);
    }

    return $campaign_elements;
}

/**
 * Get element option value or all options 
 * 
 * @global object $wpdb
 * @param int $element_id
 * @param str $option_name
 * @return array
 */
function apsa_get_element_options($element_id, $option_name = 'all') {

    /** Get options from wp_apsa_element_options table */
    global $wpdb;

    $element_options_table = $wpdb->prefix . 'apsa_element_options';

    if ($option_name == "all") {
        $name_condition = '';
    } else {
        $name_condition = ' AND option_name = "' . $option_name . '"';
    }

    $element_options = $wpdb->get_results('SELECT * FROM ' . $element_options_table . ' WHERE element_id = "' . $element_id . '"' . $name_condition, ARRAY_A);

    if ($option_name == "all") {
        return $element_options;
    } elseif (empty($element_options)) {
        return '';
    } else {
        return $element_options[0]['option_value'];
    }
}

/**
 * Update add options
 * 
 * @global object $wpdb
 * @param int $element_id
 * @param array $options
 * @return string
 */
function apsa_update_element_options($element_id, $options) {


    /** Check if wrong argument return error message */
    if (!is_array($options)) {
        trigger_error('undefined variable', E_USER_NOTICE);
        return false;
    }

    global $wpdb;

    $element_options_table = $wpdb->prefix . 'apsa_element_options';

    $insert_values = '';
    $counter = 0;

    foreach ($options as $key => $option) {
        $counter ++;

        $insert_values .= "('" . $element_id . "', '" . $key . "', '" . $option . "')";
        if ($counter != count($options)) {

            $insert_values .= ', ';
        }
    }

    $query = $wpdb->query('INSERT INTO ' . $element_options_table . ' (element_id, option_name, option_value) VALUES ' . $insert_values . ' ON DUPLICATE KEY UPDATE option_value = VALUES(option_value)');

    return $query;
}

/**
 * Insert new element
 * 
 * @global object $wpdb
 * @param str $title
 * @param str $type
 * @return int
 */
function apsa_insert_element($campaign_id, $title = '', $type = '', $status = "active", $priority = 0) {

    global $wpdb;
    global $apsa_admin_labels;

    $elements_table = $wpdb->prefix . 'apsa_elements';

    if (empty($title)) {

        switch ($type) {
            case 'image':
                $title = $apsa_admin_labels["element_name_image"];
                break;
            case 'video':
                $title = $apsa_admin_labels["element_name_video"];
                break;
            case 'flash':
                $title = $apsa_admin_labels["element_name_flash"];
                break;
            case 'code':
                $title = $apsa_admin_labels["element_name_code"];
                break;
            case 'iframe':
                $title = $apsa_admin_labels["element_name_iframe"];
                break;
            default:
                $title = '';
                break;
        }

        $title = $title . " - (" . date_i18n(get_option('date_format'), current_time('timestamp')) . ")";
    }

    /** Increment elements priority */
    $wpdb->query('UPDATE ' . $elements_table . ' SET priority = priority+1 WHERE priority >= "' . $priority . '" AND campaign_id = "' . $campaign_id . '"');

    $wpdb->insert(
            $elements_table, array(
        'campaign_id' => $campaign_id,
        'title' => $title,
        'type' => $type,
        'status' => $status,
        'priority' => $priority,
        'creation_date' => date('Y-m-d H:i:s', current_time('timestamp')),
            )
    );

    $new_element = array();
    $new_element['element_id'] = $wpdb->insert_id;
    $new_element['creation_date'] = date_i18n(get_option('date_format'), current_time('timestamp'));

    return $new_element;
}

/**
 * Update element
 * 
 * @global object $wpdb
 * @param int $element_id
 * @param str $title
 * @param str $type
 */
function apsa_update_element($element_id, $title = '', $type = '', $priority = '', $status = '') {


    if ($title == '' && $type == '' && $priority == '' && $status == '') {
        trigger_error('undefined variable', E_USER_NOTICE);
        return false;
    }

    global $wpdb;

    $elements_table = $wpdb->prefix . 'apsa_elements';

    $data_array = array();
    $data_array['title'] = $title;
    $data_array['type'] = $type;
    $data_array['priority'] = $priority;
    $data_array['status'] = $status;

    $set_query = '';
    $not_first = FALSE;
    foreach ($data_array as $key => $value) {
        if (!empty($value) || $value == "0") {
            if ($not_first == FALSE) {
                $set_query .= 'SET ' . $key . '="' . $value . '"';
                $not_first = TRUE;
            } else {
                $set_query .= ', ' . $key . '="' . $value . '"';
            }
        }
    }

    $query = $wpdb->query('UPDATE ' . $elements_table . ' ' . $set_query . ' WHERE id = "' . $element_id . '"');

    return $query;
}

/**
 * Delete element and its options 
 * 
 * @global object $wpdb
 * @param int $element_id
 */
function apsa_delete_element($element_id) {

    global $wpdb;

    $elements_table = $wpdb->prefix . 'apsa_elements';
    $element_options_table = $wpdb->prefix . 'apsa_element_options';
    $statistics_table = $wpdb->prefix . 'apsa_element_statistics';

    /** Get element priority and campaign id */
    $priority = apsa_get_element_data($element_id, "priority");
    $campaign_id = apsa_get_element_data($element_id, "campaign_id");

    // Delete element from elements table
    $delete_element = $wpdb->delete($elements_table, array('id' => $element_id));

    /** Decrement elements priority */
    $update_priority = $wpdb->query('UPDATE ' . $elements_table . ' SET priority = priority-1 WHERE priority > "' . $priority . '" AND campaign_id = "' . $campaign_id . '"');

    // Delete element options
    $delete_options = $wpdb->delete($element_options_table, array('element_id' => $element_id));

    // Delete element statistics
    $delete_stat = $wpdb->delete($statistics_table, array('element_id' => $element_id));

    if ($delete_element === FALSE || $update_priority === FALSE || $delete_options === FALSE || $delete_stat === FALSE) {
        return FALSE;
    } else {
        return TRUE;
    }
}

/*
 * delete element option
 */

function apsa_delete_element_option($element_id, $option_name) {
    global $wpdb;
    $element_options_table = $wpdb->prefix . 'apsa_element_options';
    $delete_option = $wpdb->delete($element_options_table, array('element_id' => $element_id, 'option_name' => $option_name));
}

/**
 * Check if element enable or disable
 * 
 * @param int $element_id
 * @return boolean
 */
function apsa_is_enable_element($element_id) {
    if (apsa_get_element_options($element_id, "disable") == "on") {
        return FALSE;
    } else {
        return TRUE;
    }
}

/**
 * Returns element or specific element data
 * 
 * @global object $wpdb
 * @param int $element id
 * @param str $data_name
 * @return array | str
 */
function apsa_get_element_data($element_id, $data_name = FALSE) {

    global $wpdb;

    $elements_table = $wpdb->prefix . 'apsa_elements';

    if (empty($data_name)) {
        $data = $wpdb->get_results('SELECT * FROM ' . $elements_table . ' WHERE id = "' . $element_id . '"', ARRAY_A);
        $data = isset($data[0]) ? $data[0] : "";
    } else {
        $data = $wpdb->get_results('SELECT ' . $data_name . ' FROM ' . $elements_table . ' WHERE id = "' . $element_id . '"', ARRAY_A);
        $data = isset($data[0][$data_name]) ? $data[0][$data_name] : "";
    }

    return $data;
}

/**
 * Returne campaign element by priority
 * 
 * @global object $wpdb
 * @param int $campaign_id
 * @param int $priority
 * If not set return element by priority 0
 * @return array
 */
function apsa_get_element_by_priority($campaign_id, $priority = 0) {

    global $wpdb;

    $elements_table = $wpdb->prefix . 'apsa_elements';

    $element = $wpdb->get_results('SELECT * FROM ' . $elements_table . ' WHERE campaign_id = "' . $campaign_id . '" AND priority = "' . $priority . '"', ARRAY_A);

    return $element[0];
}

/**
 * Get campaign elements count
 * 
 * @global object $wpdb
 * @param int $campaign_id
 * @return int
 */
function apsa_get_campaign_elements_count($campaign_id, $element_status = NULL) {

    global $wpdb;

    $elements_table = $wpdb->prefix . 'apsa_elements';

    if (isset($element_status)) {
        $elements_count = $wpdb->get_var("SELECT COUNT(*) FROM " . $elements_table . " WHERE campaign_id = '" . $campaign_id . "' AND status = '" . $element_status . "'");
    } else {
        $elements_count = $wpdb->get_var("SELECT COUNT(*) FROM " . $elements_table . " WHERE campaign_id = '" . $campaign_id . "'");
    }

    return $elements_count;
}

/**
 * Get elements by ids
 */
function apsa_get_elements($element_ids = 'all') {
    /** determin request type and return result */
    if (is_array($element_ids)) {
        foreach ($element_ids as $key => $value) {
            if ($key == 0) {
                $where_clause = " WHERE id = " . $value;
            } else {
                $where_clause .= " OR id = " . $value;
            }
        }
    } elseif (is_int($element_ids)) {
        $where_clause = " WHERE id = " . $element_ids;
    } elseif ($element_ids == 'all') {
        $where_clause = '';
    } else {
        trigger_error('undefined variable', E_USER_NOTICE);
        return false;
    }

    /** Get from db wp_apsa_elements table */
    global $wpdb;

    $elements_table = $wpdb->prefix . 'apsa_elements';

    $get_elements = $wpdb->get_results('SELECT * FROM `' . $elements_table . '`' . $where_clause . ' ORDER BY priority ASC', ARRAY_A);

    return $get_elements;
}

/**
 * Get all elements all options
 */
function apsa_get_all_element_options($element_ids = NULL) {
    global $wpdb;

    $element_options_table = $wpdb->prefix . 'apsa_element_options';

    if (!isset($element_ids)) {
        $get_element_options = $wpdb->get_results('SELECT * FROM `' . $element_options_table . '`', ARRAY_A);
    } elseif (is_array($element_ids)) {
        $element_ids_str = implode(',', $element_ids);

        $get_element_options = $wpdb->get_results('SELECT * FROM `' . $element_options_table . '` WHERE element_id IN(' . $element_ids_str . ')', ARRAY_A);
    } else {
        $get_element_options = FALSE;
    }

    return $get_element_options;
}

// updating child options
function apsa_update_child_element_options($elements) {
    global $apsa_admin_labels;
    foreach ($elements as $element) {
        // Check if element name set, else set default name
        if (empty($element['element_info']['title'])) {
            $element_type = apsa_get_element_data($element['element_info']['element_id'], "type");

            switch ($element_type) {
                case 'image':
                    $title = $apsa_admin_labels["element_name_image"];
                    break;
                case 'video':
                    $title = $apsa_admin_labels["element_name_video"];
                    break;
                case 'flash':
                    $title = $apsa_admin_labels["element_name_flash"];
                    break;
                case 'code':
                    $title = $apsa_admin_labels["element_name_code"];
                    break;
                case 'iframe':
                    $title = $apsa_admin_labels["element_name_iframe"];
                    break;
                default:
                    $title = '';
                    break;
            }

            $element_date = apsa_get_element_data($element['element_info']['element_id'], "creation_date");
            $element_date = date_i18n(get_option('date_format'), strtotime($element_date));

            $title .= " - (" . $element_date . ")";
        }

        /** Check which action must call, and call */
        $update_element = apsa_update_element($element['element_info']['element_id'], $element['element_info']['title'], $element['element_info']['type'], $element['element_info']['priority']);
        $update_element_opt = apsa_update_element_options($element['element_info']['element_id'], $element['element_options']);

        if ($update_element === FALSE || $update_element_opt === FALSE) {
            return false;
        }
    }
    return true;
}

// returning embed campaings child elements html 
function apsa_get_child_embed_content($element, $element_options, $camp_options) {

    if (empty($camp_options['link_color'])) {
        $camp_options['link_color'] = "#ffffff";
    }

    if (empty($camp_options['link_type'])) {
        $camp_options['link_type'] = "_blank";
    }

    $emb_element_html = '';
    if ($element["type"] == "image") {

        if (empty($element_options["background_type"])) {
            $element_options["background_type"] = "contain";
        }

        if (!empty($element_options["link_to"])) {
            $emb_element_html = '<div data-apsa-link-target="' . $camp_options["link_type"] . '" data-apsa-link="' . $element_options["link_to"] . '" style="background-size: ' . $element_options["background_type"] . '; background-image: url(' . $element_options["element_content"] . ')" class="apsa-element-link apsa-child-content"></div>';
        } else {
            $emb_element_html = '<div style="background-size: ' . $element_options["background_type"] . '; background-image: url(' . $element_options["element_content"] . ')" class="apsa-child-content"></div>';
        }
    } elseif ($element["type"] == "video") {

        if (isset($element_options["auto_play_video"]) && $element_options["auto_play_video"] == "on") {
            $element_options["auto_play_video"] = 1;
        } else {
            $element_options["auto_play_video"] = 0;
        }

        /** Convert youtube or vimeo url to embed */
        $url_data = json_decode($element_options["element_content"], true);
        $parsed_url = $url_data['parsed'];

        /** Convert youtube or vimeo url to embed */
        if ($parsed_url['provider'] == "youtube") {

            $start_time = (isset($parsed_url['params']['start']) ? '&start=' . $parsed_url['params']['start'] : "");
            $emb_element_html = '<iframe class="apsa-child-content" style="width:100%;" src="https://www.youtube.com/embed/' . $parsed_url['id'] . '?rel=0&autoplay=' . $element_options['auto_play_video'] . $start_time . '" frameborder="0" allowfullscreen></iframe>';
        } else if ($parsed_url['provider'] == "vimeo") {

            $start_time = (isset($parsed_url['params']['start']) ? '#t=' . $parsed_url['params']['start'] . 's' : "");
            $emb_element_html = '<iframe class="apsa-child-content" src="http://player.vimeo.com/video/' . $parsed_url['id'] . '?autoplay=' . $element_options['auto_play_video'] . $start_time . '" style="width:100%;" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>';
        }
    } elseif ($element["type"] == "flash") {
        $emb_element_html = '<object class="apsa-child-content" type="application/x-shockwave-flash" data="' . $element_options["element_content"] . '" style="width:100%;"></object>';
    } elseif ($element["type"] == "code") {
        $emb_element_html = '<div class="apsa-child-content">' . $element_options["element_content"] . '</div>';
        $emb_element_html = do_shortcode($emb_element_html);
    } elseif ($element["type"] == "iframe") {
        $emb_element_html = '<iframe class="apsa-child-content" src="' . $element_options["element_content"] . '" style="width:100%;"></iframe>';
    }

    $element_link = '';

    if (!empty($element_options["link_to"]) && !empty($camp_options["show_link"])) {
        $element_link = '<style type="text/css">.apsa-embed-cont[data-apsa-campaign-id="' . $element['campaign_id'] . '"]{margin-bottom: 15px;}</style>';
        $element_link .= '<span data-apsa-link-target="' . $camp_options["link_type"] . '" style="color: ' . $camp_options["link_color"] . '" class="apsa-element-link" data-apsa-link="' . $element_options["link_to"] . '">' . $element_options["link_to"] . '</span>';
    }

    $response = array(
        'html' => $emb_element_html . $element_link,
    );
    return $response;
}

// checking child element visibility for front 
function apsa_check_child_visibility($campaign, $camp_options, $campaign_element, $element_options, $element_stat) {

    global $apsa_plugin_data;

    // Get restrict parameters
    $element_restrict_visits = isset($element_options["restrict_visits"]) ? $element_options["restrict_visits"] : "";
    $element_content = isset($element_options["element_content"]) ? $element_options["element_content"] : "";
    $element_visits = isset($element_stat[$apsa_plugin_data['event_name']]) ? $element_stat[$apsa_plugin_data['event_name']] : 0;

    $response = true;
    if (empty($element_content) || $campaign_element['status'] == "suspended" || (!empty($element_restrict_visits) && $element_visits >= $element_restrict_visits)) {
        $response = false;
    }
    return $response;
}

// creating element content and returning with other options
function apsa_get_child_popup_options($element_option, $pop_element, $camp_options) {

    if (empty($camp_options['link_color'])) {
        $camp_options['link_color'] = "#ffffff";
    }

    if (empty($camp_options['link_type'])) {
        $camp_options['link_type'] = "_blank";
    }

    $pop_element_html = '';
    $response = array();
    if ($pop_element["type"] == "image") {
        $response["pop_backgroud_type"] = $element_option['background_type'];
        if (!empty($element_option["link_to"])) {
            $pop_element_html = '<div data-apsa-link-target="' . $camp_options["link_type"] . '" data-apsa-link="' . $element_option["link_to"] . '" class="apsa-element-link apsa-child-content" style="background-size: ' . $element_option['background_type'] . '; background-image: url(' . $element_option["element_content"] . ')"></div>';
        } else {
            $pop_element_html = '<div style="background-size: ' . $element_option['background_type'] . '; background-image: url(' . $element_option["element_content"] . ')" class="apsa-child-content"></div>';
        }
    } elseif ($pop_element["type"] == "video") {

        if (isset($element_option['auto_play_video']) && $element_option['auto_play_video'] == "on") {
            $element_option['auto_play_video'] = 1;
        } else {
            $element_option['auto_play_video'] = 0;
        }
        $response["pop_auto_play_video"] = $element_option['auto_play_video'];

        $url_data = json_decode($element_option["element_content"], true);
        $parsed_url = $url_data['parsed'];

        /** Convert youtube or vimeo url to embed */
        if ($parsed_url['provider'] == "youtube") {

            $start_time = (isset($parsed_url['params']['start']) ? '&start=' . $parsed_url['params']['start'] : "");
            $pop_element_html = '<iframe class="apsa-child-content" style="width:100%; height:100%;" src="https://www.youtube.com/embed/' . $parsed_url['id'] . '?rel=0&autoplay=' . $element_option['auto_play_video'] . $start_time . '" frameborder="0" allowfullscreen></iframe>';
        } else if ($parsed_url['provider'] == "vimeo") {

            $start_time = (isset($parsed_url['params']['start']) ? '#t=' . $parsed_url['params']['start'] . 's' : "");
            $pop_element_html = '<iframe class="apsa-child-content" src="http://player.vimeo.com/video/' . $parsed_url['id'] . '?autoplay=' . $element_option['auto_play_video'] . $start_time . '" style="width:100%; height:100%;" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>';
        }
    } elseif ($pop_element["type"] == "flash") {
        $pop_element_html = '<object class="apsa-child-content" type="application/x-shockwave-flash" data="' . $element_option["element_content"] . '" style="width:100%; height:100%;"></object>';
    } elseif ($pop_element["type"] == "code") {
        $pop_element_html = '<div class="apsa-child-content">' . $element_option["element_content"] . '</div>';
        $pop_element_html = do_shortcode($pop_element_html);
    } elseif ($pop_element["type"] == "iframe") {
        $pop_element_html = '<iframe class="apsa-child-content" src="' . $element_option["element_content"] . '" style="width:100%; height:100%;"></iframe>';
    }
    if ($camp_options['show_link'] != '' && $element_option["link_to"] != '') {
        $link = '<span style="color: ' . $camp_options["link_color"] . '" data-apsa-link="' . $element_option["link_to"] . '" data-apsa-link-target="' . $camp_options["link_type"] . '" class="apsa-element-link">' . $element_option["link_to"] . '</span>';
        $pop_element_html = $link . $pop_element_html;
    }
    $response["pop_link_to"] = $element_option["link_to"];
    $response["pop_element_content"] = $element_option["element_content"];
    $response["pop_element_html"] = $pop_element_html;
    $response["pop_element_type"] = $pop_element["type"];
    $response["pop_link_color"] = $camp_options['link_color'];
    $response["pop_show_link"] = $camp_options['show_link'];
    $response["pop_link_type"] = $camp_options['link_type'];

    return $response;
}

// returning background campaign element options
function apsa_get_child_bg_options($element_options, $element, $camp_options) {

    global $apsa_effects;
    $apsa_background_patterns = $apsa_effects['patterns'];

    if (empty($element_options["background_type"])) {
        $element_options["background_type"] = "cover";
    }

    if (empty($camp_options["link_type"])) {
        $camp_options["link_type"] = "_blank";
    }

    if (empty($camp_options['background_pattern'])) {
        $camp_options['background_pattern'] = "none";
    }

    $response = array();

    $response["bg_link_type"] = $camp_options["link_type"];
    if ($camp_options["background_pattern"] == 'none') {
        $response["background_pattern"] = $camp_options["background_pattern"];
    } else {
        $response["background_pattern"] = $apsa_background_patterns[$camp_options["background_pattern"]];
    }

    $response["bg_background_type"] = $element_options["background_type"];
    $response["bg_link_to"] = $element_options["link_to"];
//    $response["bg_restrict_views"] = $element_options["restrict_views"];
//    $response["bg_restrict_visits"] = $element_options["restrict_visits"];
    $response["bg_element_content"] = $element_options["element_content"];

    // set background type
    $webkit_background_size = '';
    $background_size = '';
    $background_repeat = '';
    $background_position = '';
    $background_attachment = '';
    $height = '';
    $background_image = 'url("' . $element_options["element_content"] . '")';

    if ($element_options["background_type"] == "cover_bg") {
        $webkit_background_size = 'cover !important';
        $background_size = 'cover !important';
        $background_repeat = 'no-repeat !important';
        $background_position = 'center !important';
        $background_attachment = '';
        $height = '';
    } else if ($element_options["background_type"] == "repeat_bg") {
        $webkit_background_size = '';
        $background_size = '';
        $background_repeat = 'repeat !important';
        $background_position = '';
        $background_attachment = '';
        $height = '';
    } else if ($element_options["background_type"] == "cover_bg_parallax") {
        $webkit_background_size = 'cover !important';
        $background_size = 'cover !important';
        $background_repeat = 'no-repeat !important';
        $background_position = 'center !important';
        $background_attachment = 'fixed !important';
        $height = '100% !important';
    } else if ($element_options["background_type"] == "repeat_bg_parallax") {
        $webkit_background_size = '';
        $background_size = '';
        $background_repeat = 'repeat !important';
        $background_position = '';
        $background_attachment = 'fixed !important';
        $height = '100% !important';
    }

    // set background pattern
    if ($response["background_pattern"] != "none") {
        $webkit_background_size = 'auto' . ($webkit_background_size != '' ? ', ' . $webkit_background_size : '');
        $background_size = 'auto' . ($background_size != '' ? ', ' . $background_size : '');
        $background_repeat = 'repeat' . ($background_repeat != '' ? ', ' . $background_repeat : '');
        $background_position = 'center' . ($background_position != '' ? ', ' . $background_position : '');
        $background_attachment = $background_attachment;
        $height = $height;
        $background_image = 'url("' . plugin_dir_url(__FILE__) . '../../framework/view/front/images/patterns/' . $response["background_pattern"] . '"), ' . $background_image;
    }

    if ($webkit_background_size != '')
        $webkit_background_size = ' -webkit-background-size: ' . $webkit_background_size . ';';
    if ($background_size != '')
        $background_size = ' background-size: ' . $background_size . ';';
    if ($background_repeat != '')
        $background_repeat = ' background-repeat: ' . $background_repeat . ';';
    if ($background_position != '')
        $background_position = ' background-position: ' . $background_position . ';';
    if ($background_attachment != '')
        $background_attachment = ' background-attachment: ' . $background_attachment . ';';
    if ($height != '')
        $height = 'height: ' . $height . ';';
    if ($background_image != '')
        $background_image = ' background-image: ' . $background_image . ' !important;';

    $style = '{' . $webkit_background_size . $background_size . $background_repeat . $background_position . $background_attachment . $height . $background_image . '}';

    $response["bg_element_style"] = $style;
    return $response;
}

// return child campaign options html
function apsa_child_get_campaign_options($camp_options, $camp_type) {
    global $apsa_effects;
    $apsa_popup_effects = $apsa_effects['popup'];
    $apsa_embed_effects = $apsa_effects['embed'];
    $apsa_overlay_patterns = $apsa_effects['patterns'];
    global $apsa_admin_labels;

    if ($camp_type == 'background') {
        ?>
        <li class="apsa-form-item">
            <span><?php echo $apsa_admin_labels["background_pattern"]; ?></span>
            <span class="apsa-with-question" title="<?php echo ucfirst($apsa_admin_labels["detailed_description"]); ?>" data-apsa-message="<?php echo $apsa_admin_labels["background_pattern_desc"]; ?>"></span>
            <?php $background_pattern = isset($camp_options['background_pattern']) ? $camp_options['background_pattern'] : "" ?>
            <div class="apsa-input-block">
                <select name="background_pattern">
                    <option value="none"<?php if ('none' == $background_pattern): ?> selected="selected"<?php endif; ?>>none</option>
                    <?php foreach ($apsa_overlay_patterns as $key => $value): ?>                                                
                        <option value="<?php echo $key; ?>"<?php if ($key == $background_pattern): ?> selected="selected"<?php endif; ?>><?php echo $key; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </li>
        <li class="apsa-form-item">
            <span><?php echo $apsa_admin_labels["open_link_type"]; ?></span>
            <span class="apsa-with-question" title="<?php echo ucfirst($apsa_admin_labels["detailed_description"]); ?>" data-apsa-message="<?php echo $apsa_admin_labels["open_link_type_desc"]; ?>"></span>
            <div class="apsa-input-block">
                <?php $link_type = isset($camp_options['link_type']) ? $camp_options['link_type'] : ""; ?>
                <select name="link_type">                                               
                    <option value="_blank"<?php if ($link_type == '_blank'): ?> selected="selected"<?php endif; ?>><?php echo $apsa_admin_labels["open_link_type_blank"]; ?></option>
                    <option value="_self"<?php if ($link_type == '_self'): ?> selected="selected"<?php endif; ?>><?php echo $apsa_admin_labels["open_link_type_self"]; ?></option>
                    <option value="_window"<?php if ($link_type == '_window'): ?> selected="selected"<?php endif; ?>><?php echo $apsa_admin_labels["open_link_type_window"]; ?></option>
                </select>
            </div>
        </li>
        <?PHP
    }
    if ($camp_type == 'popup') {
        ?>
        <li class="apsa-form-item">
            <span><?php echo $apsa_admin_labels["open_link_type"]; ?></span>
            <span class="apsa-with-question" title="<?php echo ucfirst($apsa_admin_labels["detailed_description"]); ?>" data-apsa-message="<?php echo $apsa_admin_labels["open_link_type_desc"]; ?>"></span>
            <div class="apsa-input-block">
                <?php $link_type = isset($camp_options['link_type']) ? $camp_options['link_type'] : ""; ?>
                <select name="link_type">                                               
                    <option value="_blank"<?php if ($link_type == '_blank'): ?> selected="selected"<?php endif; ?>><?php echo $apsa_admin_labels["open_link_type_blank"]; ?></option>
                    <option value="_self"<?php if ($link_type == '_self'): ?> selected="selected"<?php endif; ?>><?php echo $apsa_admin_labels["open_link_type_self"]; ?></option>
                    <option value="_window"<?php if ($link_type == '_window'): ?> selected="selected"<?php endif; ?>><?php echo $apsa_admin_labels["open_link_type_window"]; ?></option>
                </select>
            </div>
        </li>
        <li class="apsa-form-item">
            <?php $show_link = isset($camp_options['show_link']) ? $camp_options['show_link'] : "on"; ?>
            <?php $link_color = isset($camp_options['link_color']) ? $camp_options['link_color'] : "#ffffff"; ?>
            <div class="apsa-input-block">
                <span><?php echo $apsa_admin_labels["show_link"]; ?></span>
                <input type="checkbox" class="apsa-show-link" <?php if (!empty($show_link)): ?> checked<?php endif; ?>/>
                <input type="hidden" class="apsa-hold-checkbox" name="show_link"<?php if (!empty($show_link)): ?> value="on"<?php endif; ?>>
                <span class="apsa-with-question" title="<?php echo ucfirst($apsa_admin_labels["detailed_description"]); ?>" data-apsa-message="<?php echo $apsa_admin_labels["show_link_desc"]; ?>"></span>
            </div>
        </li>
        <li class="apsa-form-item">
            <?php $show_link = isset($camp_options['show_link']) ? $camp_options['show_link'] : "on"; ?>
            <?php $link_color = isset($camp_options['link_color']) ? $camp_options['link_color'] : "#ffffff"; ?>
            <span><?php echo $apsa_admin_labels["link_color"]; ?></span>
            <span class="apsa-with-question" title="<?php echo ucfirst($apsa_admin_labels["detailed_description"]); ?>" data-apsa-message="<?php echo $apsa_admin_labels["link_color_desc"]; ?>"></span>
            <div class="apsa-input-block">
                <input type="text" name="link_color" class="apsa-extra-small-input apsa-colorpicker" data-default-color="#ffffff" value="<?php echo $link_color; ?>">
            </div>
            <span class="apsa-input-message"><?php echo $apsa_admin_labels['default']; ?> #ffffff</span>
        </li>
        <?PHP
    }
    if ($camp_type == 'embed') {
        ?>
        <li class="apsa-form-item">
            <span><?php echo $apsa_admin_labels["open_link_type"]; ?></span>
            <span class="apsa-with-question" title="<?php echo ucfirst($apsa_admin_labels["detailed_description"]); ?>" data-apsa-message="<?php echo $apsa_admin_labels["open_link_type_desc"]; ?>"></span>
            <div class="apsa-input-block">
                <?php $link_type = isset($camp_options['link_type']) ? $camp_options['link_type'] : ""; ?>
                <select name="link_type">                                               
                    <option value="_blank"<?php if ($link_type == '_blank'): ?> selected="selected"<?php endif; ?>><?php echo $apsa_admin_labels["open_link_type_blank"]; ?></option>
                    <option value="_self"<?php if ($link_type == '_self'): ?> selected="selected"<?php endif; ?>><?php echo $apsa_admin_labels["open_link_type_self"]; ?></option>
                    <option value="_window"<?php if ($link_type == '_window'): ?> selected="selected"<?php endif; ?>><?php echo $apsa_admin_labels["open_link_type_window"]; ?></option>
                </select>
            </div>
        </li>
        <li class="apsa-form-item">
            <?php $show_link = isset($camp_options['show_link']) ? $camp_options['show_link'] : "on"; ?>
            <?php $link_color = isset($camp_options['link_color']) ? $camp_options['link_color'] : "#808080"; ?>
            <div class="apsa-input-block">
                <span><?php echo $apsa_admin_labels["show_link"]; ?></span>
                <input type="checkbox" class="apsa-show-link" <?php if (!empty($show_link)): ?> checked<?php endif; ?>/>
                <input type="hidden" class="apsa-hold-checkbox" name="show_link"<?php if (!empty($show_link)): ?> value="on"<?php endif; ?>>
                <span class="apsa-with-question" title="<?php echo ucfirst($apsa_admin_labels["detailed_description"]); ?>" data-apsa-message="<?php echo $apsa_admin_labels["show_link_desc"]; ?>"></span>
            </div>
        </li>
        <li class="apsa-form-item">
            <?php $show_link = isset($camp_options['show_link']) ? $camp_options['show_link'] : "on"; ?>
            <?php $link_color = isset($camp_options['link_color']) ? $camp_options['link_color'] : "#808080"; ?>
            <span><?php echo $apsa_admin_labels["link_color"]; ?></span>
            <span class="apsa-with-question" title="<?php echo ucfirst($apsa_admin_labels["detailed_description"]); ?>" data-apsa-message="<?php echo $apsa_admin_labels["link_color_desc"]; ?>"></span>
            <div class="apsa-input-block">
                <input type="text" name="link_color" class="apsa-extra-small-input apsa-colorpicker" data-default-color="#808080" value="<?php echo $link_color; ?>">
            </div>
            <span class="apsa-input-message"><?php echo $apsa_admin_labels['default']; ?> #808080</span>
        </li>
        <?PHP
    }
}
