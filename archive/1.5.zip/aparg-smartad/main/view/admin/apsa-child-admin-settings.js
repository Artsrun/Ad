/**
 * Show a prompt before the user leaves the current page
 */
jQuery(window).load(function () {
    jQuery(document).on('change', 'input, textarea, select', function () {
        apsa_leave_page(false);
    });
});

// desable apsa-new class 
if (typeof apsa_new != 'undefined' && apsa_new == false) {
    jQuery('.apsa-new').each(function () {
        jQuery(this).addClass('apsa-new-hide');
    });
}

jQuery(document).ready(function (jQuery) {
    /*
     * set CodeMirror textareas values
     */
    var code_areas = document.getElementsByClassName("apsa-code-area");
    var myCodeMirrors = {};
    myCodeMirrors.warningText = CodeMirror.fromTextArea(code_areas[0], {
        lineNumbers: true,
        mode: "htmlmixed",
    });

    myCodeMirrors.warningText.setValue(jQuery('#apsa-warning-text-value').val());

    myCodeMirrors.warningText.on('change', function (){
        apsa_leave_page(false);
    });
    
    

    /*
     *  save extra options 
     */
    jQuery(document).on("click", "#apsa-update-child-settings", function () {
        apsa_leave_page(true);
    });

    /**
     * Close popup
     */
    jQuery(document).on('click', '#apsa-managing-overlay, .apsa-close-popup', function () {
        jQuery('.apsa-popup').attr('data-apsa-open', "false");
        jQuery('body').removeClass('modal-open');
        jQuery('#apsa-managing-overlay').fadeOut(150);
    });

    /**
     * close anticache notice
     */
    jQuery(document).on("click", ".apsa-dismissible", function () {
        jQuery(this).parent('div').hide();
        apsa_set_cookie('apsa_anticache_notice', 'no');
    });
});
    