<?php
defined('ABSPATH') or die('No script kiddies please!');
/**
 * The base configurations of the SmartAd.
 */

// Aparg site link
define("SA_APARG_LINK", "http://aparg.com");