<?php

/**
  Plugin Name: Aparg SmartAd
  Description: The only one of a kind WordPress plugin for managing ads with smart controlling.
  Version:     1.0
  Author:      Aparg
  Author URI:  http://aparg.com/
  Text Domain: aparg-smartad
  Domain Path: /languages/
  License:     GPL2

  This plugin is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as active by
  the Free Software Foundation, either version 2 of the License, or
  any later version.

  This plugin is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this plugin. If not, see https://wordpress.org/about/gpl/.
 */
defined('ABSPATH') or die('No script kiddies please!');

global $sa_db_version;
$sa_db_version = '1.0';

/**
 * Setup when installing 
 */
function aparg_sa_install() {
    /**
     * Create database tables for storage SmartAd plugin data
     */
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

    global $wpdb;
    $wpdb->show_errors();
    /**
     * Create database tables for storage SmartAd plugin data
     */
    $charset_collate = $wpdb->get_charset_collate();

    /** Create sa_campaigns table */
    $table_name = $wpdb->prefix . "sa_campaigns";

    $sql = "CREATE TABLE $table_name (
            id int(11) NOT NULL AUTO_INCREMENT,
            name varchar(200) NOT NULL,
            type varchar(20) NOT NULL,
            status varchar(20) NOT NULL,
            creation_date date NOT NULL,
            KEY type (type),
            KEY status (status),
            UNIQUE KEY id (id)
          ) $charset_collate;";

    dbDelta($sql);

    /** Create sa_campaign_options table */
    $table_name = $wpdb->prefix . "sa_campaign_options";

    $sql = "CREATE TABLE $table_name (
            id int(11) NOT NULL AUTO_INCREMENT,
            campaign_id int(11) NOT NULL,
            option_name varchar(50) NOT NULL,
            option_value varchar(255) NOT NULL,
            KEY campaign_id (campaign_id),
            KEY option_name (option_name),
            UNIQUE KEY id (id),
            UNIQUE KEY unique_camp_option (campaign_id,option_name)
          ) $charset_collate;";

    dbDelta($sql);

    /** Create sa_ads table */
    $table_name = $wpdb->prefix . "sa_ads";

    $sql = "CREATE TABLE $table_name (
            id int(11) NOT NULL AUTO_INCREMENT,
            campaign_id int(11) NOT NULL,
            title varchar(255) NOT NULL,
            type varchar(20) NOT NULL,
            priority smallint(5) NOT NULL,
            creation_date date NOT NULL,
            status varchar(20) NOT NULL,
            KEY campaign_id (campaign_id),
            KEY priority (priority),
            UNIQUE KEY id (id)
          ) $charset_collate;";

    dbDelta($sql);

    /** Create sa_campaign_options table */
    $table_name = $wpdb->prefix . "sa_ad_options";

    $sql = "CREATE TABLE $table_name (
            id int(11) NOT NULL AUTO_INCREMENT,
            ad_id int(11) NOT NULL,
            option_name varchar(50) NOT NULL,
            option_value longtext NOT NULL,
            KEY ad_id (ad_id),
            KEY option_name (option_name),
            UNIQUE KEY id (id),
            UNIQUE KEY unique_ad_option (ad_id,option_name)
          ) $charset_collate;";

    dbDelta($sql);

    /** Create statistics table */
    $table_name = $wpdb->prefix . "sa_ad_statistics";

    $sql = "CREATE TABLE $table_name (
            ad_id int(11) NOT NULL,
            type varchar(20) NOT NULL,
            count int(11) NOT NULL,
            date date NOT NULL,
            UNIQUE KEY unique_stat (ad_id,type,date)
          ) $charset_collate;";

    dbDelta($sql);

    global $sa_db_version;
    update_option('sa_db_version', $sa_db_version);
}

register_activation_hook(__FILE__, 'aparg_sa_install');

/**
 * Db tabels updates write here
 */
function sa_update_db_check() {
    global $sa_db_version;
    if (get_site_option('sa_db_version') != $sa_db_version) {
        
    }
}

add_action('plugins_loaded', 'sa_update_db_check');

/**
 * Include scripts and styles in admin
 */
function sa_load_style_script_admin($admin_page) {

    if (strpos($admin_page, "manage-campaigns") === FALSE) {
        return;
    }

    wp_register_style('admin-styles', plugin_dir_url(__FILE__) . 'view/admin/sa-admin-styles.css');
    wp_enqueue_style('admin-styles');

    wp_register_style('admin-mobile-styles', plugin_dir_url(__FILE__) . 'view/admin/sa-admin-mobile.css');
    wp_enqueue_style('admin-mobile-styles');

    wp_register_style('jquery-ui-styles', plugin_dir_url(__FILE__) . 'view/admin/jquery-ui/jquery-ui.min.css');
    wp_enqueue_style('jquery-ui-styles');

    wp_enqueue_script('jquery');

    wp_enqueue_script('jquery-ui-sortable');

    wp_enqueue_script('jquery-ui-datepicker');

    wp_enqueue_media();


    wp_register_script('admin-scripts', plugin_dir_url(__FILE__) . 'view/admin/sa-admin-scripts.js');
    wp_enqueue_script('admin-scripts');

    // localize ajax url in admin-scripts
    wp_localize_script('admin-scripts', 'ajax_url', admin_url('admin-ajax.php'));

    /** localize admin labels in admin-scripts */
    $sa_admin_labels = array();
    $sa_admin_labels["camp_ads_count"] = __('Ads', 'aparg-smartad');
    $sa_admin_labels["camp_views_count"] = __('Views', 'aparg-smartad');
    $sa_admin_labels["camp_clicks_count"] = __('Clicks', 'aparg-smartad');
    $sa_admin_labels["camp_ads"] = __('Ads', 'aparg-smartad');
    $sa_admin_labels["filter_ad_all"] = __('All', 'aparg-smartad');
    $sa_admin_labels["filter_ad_active"] = __('Active', 'aparg-smartad');
    $sa_admin_labels["filter_ad_suspended"] = __('Suspended', 'aparg-smartad');
    $sa_admin_labels["add_new_ad"] = __('Add New', 'aparg-smartad');
    $sa_admin_labels["activate_ad"] = __('Activate', 'aparg-smartad');
    $sa_admin_labels["suspend_ad"] = __('Suspend', 'aparg-smartad');
    $sa_admin_labels["delete_ad"] = __('Delete', 'aparg-smartad');
    $sa_admin_labels["ad_views_count"] = __('Views', 'aparg-smartad');
    $sa_admin_labels["ad_clicks_count"] = __('Clicks', 'aparg-smartad');
    $sa_admin_labels["ad_ctr"] = __('CTR', 'aparg-smartad');
    $sa_admin_labels["link_to"] = __('Link To', 'aparg-smartad');
    $sa_admin_labels["detailed_description"] = __('Detailed description', 'aparg-smartad');
    $sa_admin_labels["link_to_desc"] = __('URL to customer’s website', 'aparg-smartad');
    $sa_admin_labels["deadline"] = __('Deadline', 'aparg-smartad');
    $sa_admin_labels["deadline_desc"] = __('Date after which the ad will be automatically suspended', 'aparg-smartad');
    $sa_admin_labels["deadline_def"] = __('no deadline', 'aparg-smartad');
    $sa_admin_labels["max_views"] = __('Max Views', 'aparg-smartad');
    $sa_admin_labels["max_views_desc"] = __('Number of views after which the ad will be automatically suspended', 'aparg-smartad');
    $sa_admin_labels["max_views_def"] = __('no restrict', 'aparg-smartad');
    $sa_admin_labels["max_clicks"] = __('Max Clicks', 'aparg-smartad');
    $sa_admin_labels["max_clicks_desc"] = __('Number of clicks after which the ad will be automatically suspended', 'aparg-smartad');
    $sa_admin_labels["max_clicks_def"] = __('no restrict', 'aparg-smartad');
    $sa_admin_labels["image_file"] = __('Image file', 'aparg-smartad');
    $sa_admin_labels["image_file_desc"] = __('Path to image', 'aparg-smartad');
    $sa_admin_labels["choose_img_file"] = __('Choose', 'aparg-smartad');
    $sa_admin_labels["swf_file"] = __('SWF File', 'aparg-smartad');
    $sa_admin_labels["swf_file_desc"] = __('Path to SWF file', 'aparg-smartad');
    $sa_admin_labels["choose_swf_file"] = __('Choose', 'aparg-smartad');
    $sa_admin_labels["video_url"] = __('Youtube/Vimeo URL', 'aparg-smartad');
    $sa_admin_labels["video_url_desc"] = __('URL of Youtube or Vimeo video', 'aparg-smartad');
    $sa_admin_labels["source_url"] = __('Source URL', 'aparg-smartad');
    $sa_admin_labels["source_url_desc"] = __('URL of website to load', 'aparg-smartad');
    $sa_admin_labels["html_code"] = __('HTML code', 'aparg-smartad');
    $sa_admin_labels["html_code_desc"] = __('Custom code', 'aparg-smartad');
    $sa_admin_labels["type_code"] = __('Enter', 'aparg-smartad');
    $sa_admin_labels["include"] = __('Include', 'aparg-smartad');
    $sa_admin_labels["include_ad_desc"] = __('Specify posts, pages, tags or categories where ad must be shown', 'aparg-smartad');
    $sa_admin_labels["specify_tag"] = __('Tag', 'aparg-smartad');
    $sa_admin_labels["specify_category"] = __('Category', 'aparg-smartad');
    $sa_admin_labels["specify_post"] = __('Post', 'aparg-smartad');
    $sa_admin_labels["specify_page"] = __('Page', 'aparg-smartad');
    $sa_admin_labels["yellow"] = __('Yellow', 'aparg-smartad');
    $sa_admin_labels["blue"] = __('Blue', 'aparg-smartad');
    $sa_admin_labels["red"] = __('Red', 'aparg-smartad');
    $sa_admin_labels["green"] = __('Green', 'aparg-smartad');
    $sa_admin_labels["exclude"] = __('Exclude', 'aparg-smartad');
    $sa_admin_labels["exclude_ad_desc"] = __('Specify posts, pages, tags or categories where ad must be hidden', 'aparg-smartad');
    $sa_admin_labels["Statistics_ad"] = __('Statistics', 'aparg-smartad');
    $sa_admin_labels["stat_from_place"] = __('From', 'aparg-smartad');
    $sa_admin_labels["stat_to_place"] = __('To', 'aparg-smartad');
    $sa_admin_labels["stat_show"] = __('Show', 'aparg-smartad');
    $sa_admin_labels["export_stats"] = __('Export stats', 'aparg-smartad');
    $sa_admin_labels["general"] = __('General', 'aparg-smartad');
    $sa_admin_labels["shortcode"] = __('Shortcode', 'aparg-smartad');
    $sa_admin_labels["activate_camp"] = __('Activate', 'aparg-smartad');
    $sa_admin_labels["suspend_camp"] = __('Suspend', 'aparg-smartad');
    $sa_admin_labels["export_campaign_Stats"] = __('Export Campaign Stats', 'aparg-smartad');
    $sa_admin_labels["delete_camp"] = __('Delete', 'aparg-smartad');
    $sa_admin_labels["include_camp_desc"] = __('Specify posts, pages, tags or categories where campaign must be shown', 'aparg-smartad');
    $sa_admin_labels["exclude_camp_desc"] = __('Specify posts, pages, tags or categories where campaign must be hidden', 'aparg-smartad');
    $sa_admin_labels["options"] = __('Options', 'aparg-smartad');
    $sa_admin_labels["change_interval"] = __('Change Interval', 'aparg-smartad');
    $sa_admin_labels["change_interval_desc"] = __('Interval between changing ads of the current campaign measured in seconds', 'aparg-smartad');
    $sa_admin_labels["change_interval_def"] = __('each reload', 'aparg-smartad');
    $sa_admin_labels["bg_selector"] = __('Background Selector', 'aparg-smartad');
    $sa_admin_labels["bg_selector_desc"] = __('CSS selector of the element to which background ad will be applied to', 'aparg-smartad');
    $sa_admin_labels["bg_img_type"] = __('Background Image Type', 'aparg-smartad');
    $sa_admin_labels["bg_img_type_desc"] = __('Type of the background image', 'aparg-smartad');
    $sa_admin_labels["show_interval"] = __('Show Interval', 'aparg-smartad');
    $sa_admin_labels["show_interval_desc"] = __('Interval by the end of which the next ad will be shown measured in seconds', 'aparg-smartad');
    $sa_admin_labels["show_interval_def"] = __('each reload', 'aparg-smartad');
    $sa_admin_labels["popup_direction"] = __('Popup Direction', 'aparg-smartad');
    $sa_admin_labels["popup_direction_desc"] = __('Direction of popup ad animation', 'aparg-smartad');
    $sa_admin_labels["width"] = __('Width', 'aparg-smartad');
    $sa_admin_labels["width_desc"] = __('Width of the ad container element measured in both px and %', 'aparg-smartad');
    $sa_admin_labels["default"] = __('Default:', 'aparg-smartad');
    $sa_admin_labels["height"] = __('Height', 'aparg-smartad');
    $sa_admin_labels["height_desc"] = __('Height of the ad container element measured in both px and %', 'aparg-smartad');
    $sa_admin_labels["popup_show_delay"] = __('Popup Show Delay', 'aparg-smartad');
    $sa_admin_labels["popup_show_delay_desc"] = __('Delay of showing ad popup after page loaded measured in seconds', 'aparg-smartad');
    $sa_admin_labels["popup_autoclose"] = __('Popup Autoclose', 'aparg-smartad');
    $sa_admin_labels["popup_autoclose_desc"] = __('Automatically close popup after given period of time measured in seconds', 'aparg-smartad');
    $sa_admin_labels["popup_autoclose_def"] = __('no autoclose', 'aparg-smartad');
    $sa_admin_labels["put_in_frame"] = __('Put In Frame', 'aparg-smartad');
    $sa_admin_labels["put_in_frame_desc"] = __('Choose whether to wrap or not the ad popup into frame and select frame color in HTML Hex format', 'aparg-smartad');
    $sa_admin_labels["link_color"] = __('Link Color', 'aparg-smartad');
    $sa_admin_labels["link_color_desc"] = __('Choose whether to show or not the ad link and select link color in HTML Hex format', 'aparg-smartad');
    $sa_admin_labels["close_button_delay"] = __('Close Button Delay', 'aparg-smartad');
    $sa_admin_labels["close_button_delay_desc"] = __('Delay of showing close button after showing popup measured in seconds', 'aparg-smartad');
    $sa_admin_labels["auto_play_video"] = __('Auto Play Video', 'aparg-smartad');
    $sa_admin_labels["auto_play_video_desc"] = __('Choose whether to automatically play ad video or not', 'aparg-smartad');
    $sa_admin_labels["gray_background"] = __('Gray Background', 'aparg-smartad');
    $sa_admin_labels["gray_background_desc"] = __('Choose whether to add fullscreen gray overlay under the ad popup or not', 'aparg-smartad');
    $sa_admin_labels["contain"] = __('Contain', 'aparg-smartad');
    $sa_admin_labels["cover"] = __('Cover', 'aparg-smartad');
    $sa_admin_labels["repeat"] = __('Repeat', 'aparg-smartad');
    $sa_admin_labels["statistics_camp"] = __('Statistics', 'aparg-smartad');
    $sa_admin_labels["ad_stat_title"] = __('Ad Statistics', 'aparg-smartad');
    $sa_admin_labels["camp_stat_title"] = __('Full Statistics', 'aparg-smartad');
    $sa_admin_labels["stat_view"] = __('Views', 'aparg-smartad');
    $sa_admin_labels["stat_visit"] = __('Clicks', 'aparg-smartad');
    $sa_admin_labels["ad_type_image"] = __('Image', 'aparg-smartad');
    $sa_admin_labels["ad_type_video"] = __('Video', 'aparg-smartad');
    $sa_admin_labels["ad_type_flash"] = __('Flash', 'aparg-smartad');
    $sa_admin_labels["ad_type_html"] = __('Code', 'aparg-smartad');
    $sa_admin_labels["ad_type_iframe"] = __('Iframe', 'aparg-smartad');
    $sa_admin_labels["camp_type_bg"] = __('Background', 'aparg-smartad');
    $sa_admin_labels["camp_type_popup"] = __('Popup', 'aparg-smartad');
    $sa_admin_labels["camp_type_embed"] = __('Embed', 'aparg-smartad');
    $sa_admin_labels["sort-mover-tile"] = __('Drag & Drop', 'aparg-smartad');
    $sa_admin_labels["unsaved_reload"] = __('The changes you made will be lost if you navigate away from this page.', 'aparg-smartad');
    $sa_admin_labels["second"] = __('s', 'aparg-smartad');
    $sa_admin_labels["required_filed_error"] = __('Fill required field in', 'aparg-smartad');
    $sa_admin_labels["valid_url_error"] = __('Enter valid url', 'aparg-smartad');
    $sa_admin_labels["positive_int_error"] = __('Enter positive integer', 'aparg-smartad');
    $sa_admin_labels["cant_get_stat_msg"] = __('Failed to get statistics', 'aparg-smartad');
    $sa_admin_labels["unc_type_of_file_msg"] = __('Incorrect type of file, choose correct type', 'aparg-smartad');
    $sa_admin_labels["camp_choose_type_msg"] = __('Failed to create, you must choose type for new campaign', 'aparg-smartad');
    $sa_admin_labels["created_new_camp_msg"] = __('Created new campaign', 'aparg-smartad');
    $sa_admin_labels["cant_add_camp_msg"] = __('Can not add campaign', 'aparg-smartad');
    $sa_admin_labels["check_form_req_msg"] = __('Check forms’ requirements', 'aparg-smartad');
    $sa_admin_labels["camp_saved_msg"] = __('Campaign saved', 'aparg-smartad');
    $sa_admin_labels["camp_not_saved_msg"] = __('Campaign not saved', 'aparg-smartad');
    $sa_admin_labels["ad_choose_type_msg"] = __('Failed to create, you must choose type for new ad', 'aparg-smartad');
    $sa_admin_labels["created_new_ad_msg"] = __('Created new ad', 'aparg-smartad');
    $sa_admin_labels["cant_add_ad_msg"] = __('Can not create the ad', 'aparg-smartad');
    $sa_admin_labels["camp_deleted_msg"] = __('Campaign deleted', 'aparg-smartad');
    $sa_admin_labels["camp_active_msg"] = __('Campaign activated', 'aparg-smartad');
    $sa_admin_labels["camp_suspend_msg"] = __('Campaign suspended', 'aparg-smartad');
    $sa_admin_labels["camp_action_err_msg"] = __('Can not perform the action', 'aparg-smartad');
    $sa_admin_labels["general_err_msg"] = __('Can not perform the action', 'aparg-smartad');
    $sa_admin_labels["ad_del_msg"] = __('Ad deleted', 'aparg-smartad');
    $sa_admin_labels["ad_del_err_msg"] = __('Can not delete the ad', 'aparg-smartad');
    $sa_admin_labels["ad_active_msg"] = __('Ad activated', 'aparg-smartad');
    $sa_admin_labels["ad_suspend_msg"] = __('Ad suspended', 'aparg-smartad');
    $sa_admin_labels["ad_action_err_msg"] = __('Can not perform the action', 'aparg-smartad');
    $sa_admin_labels["no_camp_stat_msg"] = __('There are no campaigns to get statistics for', 'aparg-smartad');
    $sa_admin_labels["camps_updated_msg"] = __('Campaigns updated', 'aparg-smartad');
    $sa_admin_labels["confirm_del_camp"] = __('Do you want to delete the campaign?', 'aparg-smartad');
    $sa_admin_labels["confirm_del_camp_title"] = __('Delete Campaign', 'aparg-smartad');
    $sa_admin_labels["confirm_del_ad"] = __('Do you want to delete the ad?', 'aparg-smartad');
    $sa_admin_labels["confirm_del_ad_title"] = __('Delete The Ad', 'aparg-smartad');
    $sa_admin_labels["tagsinput_post_tag"] = __('Tag', 'aparg-smartad');
    $sa_admin_labels["tagsinput_category"] = __('Category', 'aparg-smartad');
    $sa_admin_labels["tagsinput_page"] = __('Page', 'aparg-smartad');
    $sa_admin_labels["tagsinput_post"] = __('Post', 'aparg-smartad');
    $sa_admin_labels["status_active"] = __('Active', 'aparg-smartad');
    $sa_admin_labels["status_suspended"] = __('Suspended', 'aparg-smartad');
    $sa_admin_labels["creation_date"] = __('Date:', 'aparg-smartad');
    $sa_admin_labels["stat_count"] = __('Count', 'aparg-smartad');
    $sa_admin_labels["no_result"] = __('No result', 'aparg-smartad');
    $sa_admin_labels["confirm_yes"] = __('Yes', 'aparg-smartad');
    $sa_admin_labels["confirm_cancel"] = __('Cancel', 'aparg-smartad');
    $sa_admin_labels["update_camp"] = __('Update', 'aparg-smartad');
    $sa_admin_labels["popup_dir_center"] = __('Center', 'aparg-smartad');
    $sa_admin_labels["popup_dir_top"] = __('From top', 'aparg-smartad');
    $sa_admin_labels["popup_dir_right"] = __('From right', 'aparg-smartad');
    $sa_admin_labels["popup_dir_bottom"] = __('From bottom', 'aparg-smartad');
    $sa_admin_labels["popup_dir_left"] = __('From left', 'aparg-smartad');
    $sa_admin_labels["camp_name_background"] = __('Background campaign', 'aparg-smartad');
    $sa_admin_labels["camp_name_popup"] = __('Popup campaign', 'aparg-smartad');
    $sa_admin_labels["camp_name_embed"] = __('Embed campaign', 'aparg-smartad');
    $sa_admin_labels["ad_name_image"] = __('Image', 'aparg-smartad');
    $sa_admin_labels["ad_name_video"] = __('Video', 'aparg-smartad');
    $sa_admin_labels["ad_name_flash"] = __('Flash', 'aparg-smartad');
    $sa_admin_labels["ad_name_html"] = __('Code', 'aparg-smartad');
    $sa_admin_labels["ad_name_iframe"] = __('Iframe', 'aparg-smartad');
    $sa_admin_labels["success_update_msg"] = __('Successfully updated', 'aparg-smartad');
    $sa_admin_labels["update_failed_msg"] = __('Update failed', 'aparg-smartad');
    $sa_admin_labels["update_browser"] = __('Please update your browser', 'aparg-smartad');

    wp_localize_script('admin-scripts', 'sa_admin_labels', $sa_admin_labels);

    /** Localize month names and day names */
    $dyn_month_names = array();
    $month_names = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
    foreach ($month_names as $month_name) {
        $dyn_month_names[] = date_i18n('F', strtotime($month_name));
    }

    $dyn_day_names = array();
    $day_names = array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
    foreach ($day_names as $day_name) {
        $dyn_day_names[] = date_i18n('l', strtotime($day_name));
    }

    $dyn_month_short_names = array();
    $month_names = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
    foreach ($month_names as $month_name) {
        $dyn_month_short_names[] = date_i18n('M', strtotime($month_name));
    }

    $dyn_day_short_names = array();
    $day_names = array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
    foreach ($day_names as $day_name) {
        $dyn_day_short_names[] = date_i18n('D', strtotime($day_name));
    }

    wp_localize_script('admin-scripts', 'sa_month_names', $dyn_month_names);
    wp_localize_script('admin-scripts', 'sa_day_names', $dyn_day_names);
    wp_localize_script('admin-scripts', 'sa_month_short_names', $dyn_month_short_names);
    wp_localize_script('admin-scripts', 'sa_day_short_names', $dyn_day_short_names);

    /** Localize start of week */
    $start_of_week = get_option('start_of_week');

    wp_localize_script('admin-scripts', 'sa_start_of_week', $start_of_week);

    //convert wp date format to jquery
    $date_format_options = array(
        // Day
        'd' => 'dd',
        'D' => 'D',
        'j' => 'd',
        'l' => 'DD',
        'N' => '',
        'S' => '',
        'w' => '',
        'z' => 'o',
        // Week
        'W' => '',
        // Month
        'F' => 'MM',
        'm' => 'mm',
        'M' => 'M',
        'n' => 'm',
        't' => '',
        // Year
        'L' => '',
        'o' => '',
        'Y' => 'yy',
        'y' => 'y',
        // Time
        'a' => '',
        'A' => '',
        'B' => '',
        'g' => '',
        'G' => '',
        'h' => '',
        'H' => '',
        'i' => '',
        's' => '',
        'u' => ''
    );

    /** Localize date format */
    wp_localize_script('admin-scripts', 'sa_date_format', str_replace(array_keys($date_format_options), array_values($date_format_options), get_option('date_format')));

    wp_register_script('highcharts-scripts', plugin_dir_url(__FILE__) . 'view/admin/highcharts/highcharts.min.js');
    wp_enqueue_script('highcharts-scripts');

    wp_register_script('highcharts-export', plugin_dir_url(__FILE__) . 'view/admin/highcharts/exporting.min.js');
    wp_enqueue_script('highcharts-export');

    wp_register_script('highcharts-export', plugin_dir_url(__FILE__) . 'view/admin/highcharts/offline-exporting.min.js');
    wp_enqueue_script('highcharts-export');

    wp_register_script('jspdf', plugin_dir_url(__FILE__) . 'view/admin/highcharts/jspdf.min.js');
    wp_enqueue_script('jspdf');

    wp_register_script('rgbcolor', plugin_dir_url(__FILE__) . 'view/admin/highcharts/rgbcolor.min.js');
    wp_enqueue_script('rgbcolor');

    wp_register_script('canvg', plugin_dir_url(__FILE__) . 'view/admin/highcharts/canvg.js');
    wp_enqueue_script('canvg');

    /** Include Codemirror */
    wp_register_script('codemirror-scripts', plugin_dir_url(__FILE__) . 'view/admin/codemirror/lib/codemirror.js');
    wp_enqueue_script('codemirror-scripts');

    wp_register_style('codemirror-styles', plugin_dir_url(__FILE__) . 'view/admin/codemirror/lib/codemirror.css');
    wp_enqueue_style('codemirror-styles');

    wp_register_script('codemirror-mode-htmlmixed', plugin_dir_url(__FILE__) . 'view/admin/codemirror/mode/htmlmixed/htmlmixed.js');
    wp_enqueue_script('codemirror-mode-htmlmixed');

    wp_register_script('codemirror-mode-javascript', plugin_dir_url(__FILE__) . 'view/admin/codemirror/mode/javascript/javascript.js');
    wp_enqueue_script('codemirror-mode-javascript');

    wp_register_script('codemirror-mode-css', plugin_dir_url(__FILE__) . 'view/admin/codemirror/mode/css/css.js');
    wp_enqueue_script('codemirror-mode-css');

    wp_register_script('codemirror-mode-xml', plugin_dir_url(__FILE__) . 'view/admin/codemirror/mode/xml/xml.js');
    wp_enqueue_script('codemirror-mode-xml');

    /** Include Tagsinput */
    wp_register_style('bootstrap-css', plugin_dir_url(__FILE__) . 'view/admin/bootstrap-tagsinput/bootstrap-styles.css');
    wp_enqueue_style('bootstrap-css');

    wp_register_style('bootstrap-tagsinput-css', plugin_dir_url(__FILE__) . 'view/admin/bootstrap-tagsinput/dist/bootstrap-tagsinput.css');
    wp_enqueue_style('bootstrap-tagsinput-css');

    wp_register_style('bootstrap-app-css', plugin_dir_url(__FILE__) . 'view/admin/bootstrap-tagsinput/tagsinput-app.css');
    wp_enqueue_style('bootstrap-app-css');

    wp_register_script('bootstrap-js', plugin_dir_url(__FILE__) . 'view/admin/bootstrap-tagsinput/bootstrap-scripts.js');
    wp_enqueue_script('bootstrap-js');

    wp_register_script('typeahead-js', plugin_dir_url(__FILE__) . 'view/admin/bootstrap-tagsinput/typeahead-scripts.js');
    wp_enqueue_script('typeahead-js');

    wp_register_script('bootstrap-tagsinput-js', plugin_dir_url(__FILE__) . 'view/admin/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js');
    wp_enqueue_script('bootstrap-tagsinput-js');

    wp_localize_script('apps-js', 'ajax_url', admin_url('admin-ajax.php'));

    /** Include url parser */
    wp_register_script('url-parser-js', plugin_dir_url(__FILE__) . 'view/admin/video-url-parser/jsVideoUrlParser.min.js');
    wp_enqueue_script('url-parser-js');

    /** Include colorpicker */
    wp_register_style('colorpicker-styles', plugin_dir_url(__FILE__) . 'view/admin/colorpicker/colorpicker.css');
    wp_enqueue_style('colorpicker-styles');

    wp_register_script('colorpicker-scripts', plugin_dir_url(__FILE__) . 'view/admin/colorpicker/colorpicker.js');
    wp_enqueue_script('colorpicker-scripts');
}

add_action('admin_enqueue_scripts', 'sa_load_style_script_admin');

/*
 * Include scripts and styles in view
 */

function sa_load_style_script_view() {

    wp_enqueue_script('jquery');

    // Ad styles 
    wp_register_style('sa-ad-styles', plugin_dir_url(__FILE__) . 'view/front/sa-ad-styles.css');
    wp_enqueue_style('sa-ad-styles');

    // Add custom styles
    $custom_css = get_option('sa_custom_css');
    wp_add_inline_style('sa-ad-styles', $custom_css);

    // Ad scripts
    wp_register_script('sa-ad-scripts', plugin_dir_url(__FILE__) . 'view/front/sa-ad-scripts.js');
    wp_enqueue_script('sa-ad-scripts');

    // localize ajax url in admin-scripts
    wp_localize_script('sa-ad-scripts', 'ajax_url', admin_url('admin-ajax.php'));

    // localize wp_nonce field in ad-scripts
    wp_localize_script('sa-ad-scripts', 'sa_wp_nonce', wp_create_nonce('sa-stats'));
}

add_action('wp_enqueue_scripts', 'sa_load_style_script_view');

/** Include functions parts */
// Include configurations
include 'includes/smartad-config.php';

// Include functions for creating campaigns managing menu page in admin section
include 'view/admin/manage-campains.php';

// Include actions file
include 'includes/smartad-functions.php';

// Include embed widget creation file
include 'view/front/campaign-embed/sa-embed-widget.php';

// Include embed shortcode creation file
include 'view/front/campaign-embed/sa-embed-shortcode.php';

// Include popup maker
include 'view/front/campaign-popup/sa-popup-maker.php';

// Include bg maker
include 'view/front/campaign-bg/sa-bg-maker.php';

/**
 * Load text domain
 */
function aparg_smartad_text_domain() {
    load_plugin_textdomain('aparg-smartad', dirname(__FILE__) . '/languages/', basename(dirname(__FILE__)) . '/languages/');
}

add_action('init', 'aparg_smartad_text_domain');

/**
 * Ajax handler for add new campaign
 */
function sa_ajax_new_campaign() {

    $success = 1;

    $type = $_POST['type'];

    $defaults = array();

    if ($type == "popup") {
        $defaults = array(
            'put_in_frame' => 'on',
            'frame_color' => '#ffffff',
            'gray_background' => 'on',
            'show_link' => 'on',
            'link_color' => '#ffffff'
        );
    } elseif ($type == "embed") {
        $defaults = array(
            'show_link' => 'on',
            'link_color' => '#808080'
        );
    }

    $new_campaign = sa_add_campaign($type, "", "suspended", $defaults);

    if (empty($new_campaign['campaign_id'])) {
        $success = 0;
    }

    $response = array('success' => $success, 'campaign_id' => $new_campaign['campaign_id'], 'creation_date' => $new_campaign['creation_date']);
    echo json_encode($response);

    wp_die();
}

add_action('wp_ajax_sa_ajax_new_campaign', 'sa_ajax_new_campaign');

/**
 * Ajax handler for update campaign options
 */
function sa_ajax_update_campaign_options() {

    $success = 1;

    $campaign_name = $_POST['campaign_name'];
    $campaign_id = $_POST['campaign_id'];
    $campaign_options = $_POST['campaign_options'];
    $options = array();

    foreach ($campaign_options as $key => $campaign_option) {

        $options[$campaign_option['name']] = $campaign_option['value'];
    }

    /** Update campaign basic data */
    // Check if compaign name set, else set default name
    if (empty($campaign_name)) {
        $campaign_type = sa_get_campaign_data($campaign_id, "type");

        switch ($campaign_type) {
            case 'background':
                $campaign_name = __('Background campaign', 'aparg-smartad');
                break;
            case 'popup':
                $campaign_name = __('Popup campaign', 'aparg-smartad');
                break;
            case 'embed':
                $campaign_name = __('Embed campaign', 'aparg-smartad');
                break;
            default:
                $campaign_name = '';
                break;
        }

        $campaign_date = sa_get_campaign_data($campaign_id, "creation_date");
        $campaign_date = date_i18n(get_option('date_format'), strtotime($campaign_date));
        $campaign_name .= " - (" . $campaign_date . ")";
    }

    $update_camp = sa_update_campaign($campaign_id, $campaign_name);
    $update_camp_opt = sa_update_campaign_options($campaign_id, $options);

    if ($update_camp === FALSE || $update_camp_opt === FALSE) {
        $success = 0;
    } else {
        if (isset($_POST['campaign_ads'])) {

            $ads = $_POST['campaign_ads'];

            foreach ($ads as $key => $ad) {
                $campaign_id = $ad[1]['value'];
                $priority = $ad[2]['value'];
                $ad_id = $ad[3]['value'];
                $type = $ad[4]['value'];
                $title = $ad[5]['value'];
                $link_to = $ad[6]['value'];
                $deadline = $ad[7]['value'];
                $restrict_views = $ad[8]['value'];
                $restrict_visits = $ad[9]['value'];
                $ad_content = $ad[10]['value'];
                $ad_include_tags = $ad[11]['value'];
                $ad_exclude_tags = $ad[12]['value'];

                // Check if ad name set, else set default name
                if (empty($title)) {
                    $ad_type = sa_get_ad_data($ad_id, "type");

                    switch ($ad_type) {
                        case 'image':
                            $title = __('Image', 'aparg-smartad');
                            break;
                        case 'video':
                            $title = __('Video', 'aparg-smartad');
                            break;
                        case 'flash':
                            $title = __('Flash', 'aparg-smartad');
                            break;
                        case 'html':
                            $title = __('Code', 'aparg-smartad');
                            break;
                        case 'iframe':
                            $title = __('Iframe', 'aparg-smartad');
                            break;
                        default:
                            $title = '';
                            break;
                    }

                    $ad_date = sa_get_ad_data($ad_id, "creation_date");
                    $ad_date = date_i18n(get_option('date_format'), strtotime($ad_date));

                    $title .= " - (" . $ad_date . ")";
                }

                $ad_options = array(
                    'link_to' => $link_to,
                    'deadline' => $deadline,
                    'restrict_views' => $restrict_views,
                    'restrict_visits' => $restrict_visits,
                    'ad_content' => $ad_content,
                    'ad_include_tags' => $ad_include_tags,
                    'ad_exclude_tags' => $ad_exclude_tags
                );

                /** Check which action must call, and call */
                $update_ad = sa_update_ad($ad_id, $title, $type, $priority);
                $update_ad_opt = sa_update_ad_options($ad_id, $ad_options);

                if ($update_ad === FALSE || $update_ad_opt === FALSE) {
                    $success = 0;
                    break;
                }
            }
        }
    }

    $response = array('success' => $success);
    echo json_encode($response);

    wp_die();
}

add_action('wp_ajax_sa_ajax_update_campaign_options', 'sa_ajax_update_campaign_options');

/**
 * Ajax handler for add new ad
 */
function sa_ajax_add_ad() {

    $success = 1;

    $campaign_id = $_POST['campaign_id'];
    $type = $_POST['type'];

    $new_ad = sa_insert_ad($campaign_id, '', $type);

    if ($new_ad['ad_id'] === FALSE) {
        $success = 0;
    }

    $response = array('success' => $success, 'ad_id' => $new_ad['ad_id'], 'creation_date' => $new_ad['creation_date']);
    echo json_encode($response);

    wp_die();
}

add_action('wp_ajax_sa_ajax_add_ad', 'sa_ajax_add_ad');

/**
 *  allow upload flash
 */
function pixert_allow_flash($mimes) {

    $mimes['swf'] = 'application/x-shockwave-flash';

    return $mimes;
}

add_filter('upload_mimes', 'pixert_allow_flash');

/**
 * Ajax handler for update campaign status or delete
 */
function sa_ajax_update_campaign_status() {

    $success = 1;

    $campaign_id = $_POST['campaign_id'];
    $campaign_action = $_POST['campaign_action'];
    $campaign_type = $_POST['campaign_type'];

    if ($campaign_action == "delete") {
        $action = sa_delete_campaign($campaign_id);
    } else {
        $action = sa_update_campaign($campaign_id, '', $campaign_type, $campaign_action);
    }

    if ($action === FALSE) {
        $success = 0;
    }

    $response = array('success' => $success);
    echo json_encode($response);

    wp_die();
}

add_action('wp_ajax_sa_ajax_update_campaign_status', 'sa_ajax_update_campaign_status');

/**
 * Ajax handler for delete ad
 */
function sa_ajax_delete_ad() {

    $success = 1;

    $ad_id = $_POST['ad_id'];

    if (sa_delete_ad($ad_id) === FALSE) {
        $success = 0;
    }

    $response = array('success' => $success);
    echo json_encode($response);

    wp_die();
}

add_action('wp_ajax_sa_ajax_delete_ad', 'sa_ajax_delete_ad');

/**
 * Ajax handler for update ad statisitcs
 */
function sa_ajax_update_ad_statistics() {
    check_ajax_referer('sa-stats', 'sa_wp_nonce');

    $success = 1;

    $ad_id = $_POST["ad_id"];
    $type = $_POST["type"];

    if (sa_update_ad_statistics($ad_id, $type) === FALSE) {
        $success = 0;
    }

    $response = array('success' => $success);
    echo json_encode($response);

    wp_die();
}

add_action('wp_ajax_sa_ajax_update_ad_statistics', 'sa_ajax_update_ad_statistics');
add_action('wp_ajax_nopriv_sa_ajax_update_ad_statistics', 'sa_ajax_update_ad_statistics');

/**
 * Ajax handler for update ad statisitcs
 */
function sa_ajax_get_ad_statistics() {

    $from = $_POST["from"];
    if (empty($from)) {
        $from = FALSE;
    }

    $to = $_POST["to"];
    if (empty($to)) {
        $to = FALSE;
    }

    $ad_id = $_POST["ad_id"];

    $statistics = sa_get_ad_statistics($ad_id, $from, $to);

    echo json_encode($statistics);

    wp_die();
}

add_action('wp_ajax_sa_ajax_get_ad_statistics', 'sa_ajax_get_ad_statistics');

/**
 * Ajax handler for get campaign statisitcs
 */
function sa_ajax_get_camp_statistics() {

    $from = $_POST["from"];
    if (empty($from)) {
        $from = FALSE;
    }

    $to = $_POST["to"];
    if (empty($to)) {
        $to = FALSE;
    }

    $camp_id = $_POST["camp_id"];

    $statistics = sa_get_camp_statistics($camp_id, $from, $to);

    echo json_encode($statistics);

    wp_die();
}

add_action('wp_ajax_sa_ajax_get_camp_statistics', 'sa_ajax_get_camp_statistics');

/**
 * Ajax handler for update ad status
 */
function sa_ajax_update_ad_status() {

    $success = 1;

    $ad_id = $_POST['ad_id'];
    $status = $_POST['status'];

    if (sa_update_ad($ad_id, "", "", "", $status) === FALSE) {
        $success = 0;
    }

    $response = array('success' => $success);
    echo json_encode($response);

    wp_die();
}

add_action('wp_ajax_sa_ajax_update_ad_status', 'sa_ajax_update_ad_status');

/**
 * Ajax handler for autocomplete
 */
function sa_ajax_autocomplete() {

    if (isset($_GET["query"])) {
        $search_query = $_GET["query"];

        $all_taxonomies = get_taxonomies();
        unset($all_taxonomies["link_taxonomy"]);
        unset($all_taxonomies["post_format"]);

        $all_terms = get_terms($all_taxonomies, array(
            "hide_empty" => FALSE,
            "name__like" => $search_query,
            "offset" => 100
        ));

        $responce_array = array();

        foreach ($all_terms as $key => $term) {
            if ($term->taxonomy == "post_tag") {
                array_push($responce_array, array(
                    "value" => "post_tag%" . $term->term_id . "%" . $term->name . "%smartad%",
                    "text" => $term->name,
                    "type" => 'post_tag'
                ));
            } else {
                array_push($responce_array, array(
                    "value" => "category%" . $term->term_id . "%" . $term->name . "%smartad%",
                    "text" => $term->name,
                    "type" => 'category'
                ));
            }
        }

        // The Query
        add_filter('posts_where', 'sa_title_like_posts_where', 10, 2);

        function sa_title_like_posts_where($where, &$wp_query) {
            global $wpdb;
            if ($post_title_like = $wp_query->get('post_title_like')) {
                $wp_version = get_bloginfo('version');

                if ($wp_version < 4) {
                    $title_like = like_escape($post_title_like);
                    if ($wp_version < 3.6) {
                        $where .= " AND " . $wpdb->posts . ".post_title LIKE '%" . $wpdb->escape($title_like) . "%'";
                    } else {
                        $where .= " AND " . $wpdb->posts . ".post_title LIKE '%" . esc_sql($title_like) . "%'";
                    }
                } else {
                    $title_like = $wpdb->esc_like($post_title_like);
                    $where .= " AND " . $wpdb->posts . ".post_title LIKE '%" . esc_sql($title_like) . "%'";
                }
            }
            return $where;
        }

        $sa_posts_query = new WP_Query(array(
            'post_type' => 'any',
            'post_title_like' => $search_query,
            'posts_per_page' => 100
        ));

        // The Loop
        if ($sa_posts_query->have_posts()) {

            while ($sa_posts_query->have_posts()) {
                $sa_posts_query->the_post();

                if (get_post_type(get_the_ID()) == "page") {
                    array_push($responce_array, array(
                        "value" => "page%" . get_the_ID() . "%" . get_the_title() . "%smartad%",
                        "text" => get_the_title(),
                        "type" => 'page'
                    ));
                } else {
                    array_push($responce_array, array(
                        "value" => "post%" . get_the_ID() . "%" . get_the_title() . "%smartad%",
                        "text" => get_the_title(),
                        "type" => 'post'
                    ));
                }
            }
        }

        /* Restore original Post Data */
        wp_reset_postdata();

        echo json_encode($responce_array);
    }

    wp_die();
}

add_action('wp_ajax_sa_ajax_autocomplete', 'sa_ajax_autocomplete');

/**
 * Ajax handler for get ads stats
 */
function sa_ajax_get_ads_stat() {

    $from = $_POST["from"];
    if (empty($from)) {
        $from = FALSE;
    }

    $to = $_POST["to"];
    if (empty($to)) {
        $to = FALSE;
    }

    $camp_id = $_POST["camp_id"];

    $statistics = sa_get_ads_statistics($camp_id, $from, $to);

    echo json_encode($statistics);

    wp_die();
}

add_action('wp_ajax_sa_ajax_get_ads_stat', 'sa_ajax_get_ads_stat');

/**
 * Ajax handler for update all campaigns
 */
function sa_ajax_update_all_camps() {

    $all_camps = $_POST["all_camps"];

    $success = 1;

    foreach ($all_camps as $campaign_id => $camp) {

        /** Update campaign */
        $campaign_options = $camp[0];
        $options = array();

        foreach ($campaign_options as $key => $campaign_option) {
            if ($campaign_option['name'] == "campaign_name") {
                $campaign_name = $campaign_option['value'];
                continue;
            }
            $options[$campaign_option['name']] = $campaign_option['value'];
        }

        /** Update campaign basic data */
        // Check if compaign name set, else set default name
        if (empty($campaign_name)) {
            $campaign_type = sa_get_campaign_data($campaign_id, "type");

            switch ($campaign_type) {
                case 'background':
                    $campaign_name = __('Background campaign', 'aparg-smartad');
                    break;
                case 'popup':
                    $campaign_name = __('Popup campaign', 'aparg-smartad');
                    break;
                case 'embed':
                    $campaign_name = __('Embed campaign', 'aparg-smartad');
                    break;
                default:
                    $campaign_name = '';
                    break;
            }

            $campaign_date = sa_get_campaign_data($campaign_id, "creation_date");
            $campaign_date = date_i18n(get_option('date_format'), strtotime($campaign_date));
            $campaign_name .= " - (" . $campaign_date . ")";
        }

        $update_camp = sa_update_campaign($campaign_id, $campaign_name);
        $update_camp_opt = sa_update_campaign_options($campaign_id, $options);

        if ($update_camp === FALSE || $update_camp_opt === FALSE) {
            $success = 0;
            break;
        }

        /** Update campaign ads */
        if (isset($camp[1])) {
            $ads = $camp[1];

            foreach ($ads as $key => $ad) {
                $campaign_id = $ad[1]['value'];
                $priority = $ad[2]['value'];
                $ad_id = $ad[3]['value'];
                $type = $ad[4]['value'];
                $title = $ad[5]['value'];
                $link_to = $ad[6]['value'];
                $deadline = $ad[7]['value'];
                $restrict_views = $ad[8]['value'];
                $restrict_visits = $ad[9]['value'];
                $ad_content = $ad[10]['value'];
                $ad_include_tags = $ad[11]['value'];
                $ad_exclude_tags = $ad[12]['value'];

                // Check if ad name set, else set default name
                if (empty($title)) {
                    $ad_type = sa_get_ad_data($ad_id, "type");

                    switch ($ad_type) {
                        case 'image':
                            $title = __('Image', 'aparg-smartad');
                            break;
                        case 'video':
                            $title = __('Video', 'aparg-smartad');
                            break;
                        case 'flash':
                            $title = __('Flash', 'aparg-smartad');
                            break;
                        case 'html':
                            $title = __('Code', 'aparg-smartad');
                            break;
                        case 'iframe':
                            $title = __('Iframe', 'aparg-smartad');
                            break;
                        default:
                            $title = '';
                            break;
                    }

                    $ad_date = sa_get_ad_data($ad_id, "creation_date");
                    $ad_date = date_i18n(get_option('date_format'), strtotime($ad_date));

                    $title .= " - (" . $ad_date . ")";
                }

                $ad_options = array(
                    'link_to' => $link_to,
                    'deadline' => $deadline,
                    'restrict_views' => $restrict_views,
                    'restrict_visits' => $restrict_visits,
                    'ad_content' => $ad_content,
                    'ad_include_tags' => $ad_include_tags,
                    'ad_exclude_tags' => $ad_exclude_tags
                );

                /** Check which action must call, and call */
                $update_ad = sa_update_ad($ad_id, $title, $type, $priority);
                $update_ad_opt = sa_update_ad_options($ad_id, $ad_options);

                if ($update_ad === FALSE || $update_ad_opt === FALSE) {
                    $success = 0;
                    break;
                }
            }
        }
    }

    $response = array('success' => $success);
    echo json_encode($response);

    wp_die();
}

add_action('wp_ajax_sa_ajax_update_all_camps', 'sa_ajax_update_all_camps');

/**
 * Ajax handler for get custom css
 */
function sa_ajax_update_custom_css() {

    $success = 1;

    $custom_css = $_POST['custom_css'];

    $update_css = update_option('sa_custom_css', $custom_css);

    if ($update_css === FALSE && $custom_css != get_option('sa_custom_css')) {
        $success = 0;
    }

    $response = array('success' => $success);
    echo json_encode($response);

    wp_die();
}

add_action('wp_ajax_sa_ajax_update_custom_css', 'sa_ajax_update_custom_css');
