<?php
defined('ABSPATH') or die('No script kiddies please!');
//if uninstall not called from WordPress exit
if (!defined('WP_UNINSTALL_PLUGIN'))
    exit();

/** Drop SmartAd options from wp_options */
delete_option('widget_sa_campaign');
delete_option('sa_db_version');
delete_option('sa_custom_css');

/** Drop SmartAd db tables */
global $wpdb;
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}sa_campaigns");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}sa_campaign_options");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}sa_ads");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}sa_ad_options");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}sa_ad_statistics");
