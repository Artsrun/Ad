<?php
defined('ABSPATH') or die('No script kiddies please!');

function sa_bg_before_page_template_load() {

    // Check if admin side scren return
    if (is_admin()) {
        return;
    }

    // Get active campaign
    $campaign = sa_get_active_campaign("background");

    if (empty($campaign)) {
        return;
    }

    // Get campaign ads    
    $get_campaign_ads = sa_get_campaign_ads($campaign['id'], "priority");
    
    $campaign_ads = array();
    $ads_by_priority = array();
    
    if (!empty($get_campaign_ads)) {
        foreach ($get_campaign_ads as $ad_data) {
            $campaign_ads[$ad_data['id']] = $ad_data;
            $ads_by_priority[$ad_data['priority']] = $ad_data;
        }
    }
    
    $ad_ids = array_keys($campaign_ads);

    // Check whether campaign exists
    if (empty($campaign) || empty($campaign_ads)) {
        return;
    }

    // Get campaign options
    $get_camp_options = sa_get_campaign_options($campaign['id']);
    $camp_options = array();

    if (!empty($get_camp_options)) {
        foreach ($get_camp_options as $camp_option) {
            $camp_options[$camp_option['option_name']] = $camp_option['option_value'];
        }
    }

    // Get campaign ads options
    $get_ads_options = sa_get_all_ad_options($ad_ids);
    $ads_options = array();

    if (!empty($get_ads_options)) {
        foreach ($get_ads_options as $ad_option) {
            $ads_options[$ad_option['ad_id']][$ad_option['option_name']] = $ad_option['option_value'];
        }
    }

    // Get campaign ads statistics 
    $get_ads_stat = sa_get_ad_stat_counts($ad_ids);
    $ads_stat = array();
    if (!empty($get_ads_stat)) {
        foreach ($get_ads_stat as $get_ad_stat) {
            $ads_stat[$get_ad_stat['ad_id']][$get_ad_stat['type']] = $get_ad_stat['total_count'];
        }
    }

    /** Check some options which must have a value */
    if (empty($camp_options["change_interval"])) {
        $camp_options["change_interval"] = -1;
    }

    if (empty($camp_options["background_selector"])) {
        $camp_options["background_selector"] = "body";
    }

    if (empty($camp_options["background_type"])) {
        $camp_options["background_type"] = "cover";
    }

    /**
     * Check specifing campaign
     */
    $camp_include_tags = isset($camp_options["camp_include_tags"]) ? $camp_options["camp_include_tags"] : "";
    $camp_exclude_tags = isset($camp_options["camp_exclude_tags"]) ? $camp_options["camp_exclude_tags"] : "";

    $specify_ids['include']['category'] = array();
    $specify_ids['include']['post_tag'] = array();
    $specify_ids['include']['post'] = array();
    $specify_ids['include']['page'] = array();
    $specify_ids['exclude']['category'] = array();
    $specify_ids['exclude']['post_tag'] = array();
    $specify_ids['exclude']['post'] = array();
    $specify_ids['exclude']['page'] = array();

    if (!empty($camp_include_tags) || !empty($camp_exclude_tags)) {

        if (!empty($camp_include_tags)) {
            $camp_include_tags = explode("%smartad%,", $camp_include_tags);

            $tags_count = count($camp_include_tags);

            $exp_include_tags = explode("%smartad%", $camp_include_tags[$tags_count - 1]);
            $camp_include_tags[$tags_count - 1] = $exp_include_tags[0];

            foreach ($camp_include_tags as $key => $camp_include_tag) {
                $camp_include_tag = explode("%", $camp_include_tag);
                $camp_include_tags[$key] = $camp_include_tag;
            }

            foreach ($camp_include_tags as $key => $camp_include_tag) {
                if ($camp_include_tag[0] == "category") {
                    array_push($specify_ids['include']['category'], $camp_include_tag[1]);
                } elseif ($camp_include_tag[0] == "post_tag") {
                    array_push($specify_ids['include']['post_tag'], $camp_include_tag[1]);
                } elseif ($camp_include_tag[0] == "post") {
                    array_push($specify_ids['include']['post'], $camp_include_tag[1]);
                } elseif ($camp_include_tag[0] == "page") {
                    array_push($specify_ids['include']['page'], $camp_include_tag[1]);
                }
            }
        }

        if (!empty($camp_exclude_tags)) {
            $camp_exclude_tags = explode("%smartad%,", $camp_exclude_tags);

            $tags_count = count($camp_exclude_tags);

            $exp_exclude_tags = explode("%smartad%", $camp_exclude_tags[$tags_count - 1]);
            $camp_exclude_tags[$tags_count - 1] = $exp_exclude_tags[0];

            foreach ($camp_exclude_tags as $key => $camp_exclude_tag) {

                $camp_exclude_tag = explode("%", $camp_exclude_tag);

                $camp_exclude_tags[$key] = $camp_exclude_tag;
            }

            foreach ($camp_exclude_tags as $key => $camp_exclude_tag) {
                if ($camp_exclude_tag[0] == "category") {
                    array_push($specify_ids['exclude']['category'], $camp_exclude_tag[1]);
                } elseif ($camp_exclude_tag[0] == "post_tag") {
                    array_push($specify_ids['exclude']['post_tag'], $camp_exclude_tag[1]);
                } elseif ($camp_exclude_tag[0] == "post") {
                    array_push($specify_ids['exclude']['post'], $camp_exclude_tag[1]);
                } elseif ($camp_exclude_tag[0] == "page") {
                    array_push($specify_ids['exclude']['page'], $camp_exclude_tag[1]);
                }
            }
        }

        $camp_allow = TRUE;

        /** Check if current page included or excloded */
        if (is_archive()) {
            $term = get_queried_object();

            if (!empty($term)) {
                $term_id = $term->term_id;

                if (in_array($term_id, $specify_ids['include']['category']) || in_array($term_id, $specify_ids['include']['post_tag'])) {
                    $camp_allow = TRUE;
                } elseif (!empty($camp_include_tags)) {
                    $camp_allow = FALSE;
                }

                if (in_array($term_id, $specify_ids['exclude']['category']) || in_array($term_id, $specify_ids['exclude']['post_tag'])) {
                    $camp_allow = FALSE;
                }
            } elseif (!empty($camp_include_tags)) {
                $camp_allow = FALSE;
            }
        } elseif (is_page() || is_single()) {

            $post_terms_ids = array();
            $post_tag_ids = array();
            $post_id = get_the_ID();

            $all_taxonomies = get_taxonomies();
            unset($all_taxonomies["link_taxonomy"]);
            unset($all_taxonomies["post_format"]);
            unset($all_taxonomies["post_tag"]);

            $post_terms = wp_get_post_terms(get_the_ID(), $all_taxonomies, array('fields' => 'ids'));
            if (!empty($post_terms)) {
                $post_terms_ids = array_merge($post_terms_ids, $post_terms);
            }

            $post_tags = wp_get_post_terms(get_the_ID(), "post_tag", array('fields' => 'ids'));
            if (!empty($post_tags)) {
                $post_tag_ids = array_merge($post_tag_ids, $post_tags);
            }


            $inter_terms = array_intersect($specify_ids['include']['category'], $post_terms_ids);
            $inter_tags = array_intersect($specify_ids['include']['post_tag'], $post_tag_ids);
            if (in_array($post_id, $specify_ids['include']['post']) || in_array($post_id, $specify_ids['include']['page']) || !empty($inter_terms) || !empty($inter_tags)) {
                $camp_allow = TRUE;
            } elseif (!empty($camp_include_tags)) {
                $camp_allow = FALSE;
            }

            $inter_terms = array_intersect($specify_ids['exclude']['category'], $post_terms_ids);
            $inter_tags = array_intersect($specify_ids['exclude']['post_tag'], $post_tag_ids);
            if (in_array($post_id, $specify_ids['exclude']['post']) || in_array($post_id, $specify_ids['exclude']['page']) || !empty($inter_terms) || !empty($inter_tags)) {
                $camp_allow = FALSE;
            }
        } else {
            if (!empty($camp_include_tags)) {
                $camp_allow = FALSE;
            }
        }
    } else {
        $camp_allow = TRUE;
    }

    if ($camp_allow == FALSE) {
        return;
    }

    /** Separate enabled ads */
    foreach ($campaign_ads as $ad_id => $campaign_ad) {

        /** Check whether ad not expired or disabled */
        if (!empty($ads_options[$ad_id]["deadline"])) {
            $ads_options[$ad_id]["deadline"] = strtotime($ads_options[$ad_id]["deadline"]);
        }

        /**
         * Check specifing ad
         */
        $ad_include_tags = isset($ads_options[$ad_id]["ad_include_tags"]) ? $ads_options[$ad_id]["ad_include_tags"] : "";
        $ad_exclude_tags = isset($ads_options[$ad_id]["ad_exclude_tags"]) ? $ads_options[$ad_id]["ad_exclude_tags"] : "";

        $specify_ids['include']['category'] = array();
        $specify_ids['include']['post_tag'] = array();
        $specify_ids['include']['post'] = array();
        $specify_ids['include']['page'] = array();
        $specify_ids['exclude']['category'] = array();
        $specify_ids['exclude']['post_tag'] = array();
        $specify_ids['exclude']['post'] = array();
        $specify_ids['exclude']['page'] = array();

        if (!empty($ad_include_tags) || !empty($ad_exclude_tags)) {

            if (!empty($ad_include_tags)) {
                $ad_include_tags = explode("%smartad%,", $ad_include_tags);

                $tags_count = count($ad_include_tags);

                $exp_include_tags = explode("%smartad%", $ad_include_tags[$tags_count - 1]);
                $ad_include_tags[$tags_count - 1] = $exp_include_tags[0];

                foreach ($ad_include_tags as $key => $ad_include_tag) {
                    $ad_include_tag = explode("%", $ad_include_tag);
                    $ad_include_tags[$key] = $ad_include_tag;
                }

                foreach ($ad_include_tags as $key => $ad_include_tag) {
                    if ($ad_include_tag[0] == "category") {
                        array_push($specify_ids['include']['category'], $ad_include_tag[1]);
                    } elseif ($ad_include_tag[0] == "post_tag") {
                        array_push($specify_ids['include']['post_tag'], $ad_include_tag[1]);
                    } elseif ($ad_include_tag[0] == "post") {
                        array_push($specify_ids['include']['post'], $ad_include_tag[1]);
                    } elseif ($ad_include_tag[0] == "page") {
                        array_push($specify_ids['include']['page'], $ad_include_tag[1]);
                    }
                }
            }

            if (!empty($ad_exclude_tags)) {
                $ad_exclude_tags = explode("%smartad%,", $ad_exclude_tags);

                $tags_count = count($ad_exclude_tags);

                $exp_exclude_tags = explode("%smartad%", $ad_exclude_tags[$tags_count - 1]);
                $ad_exclude_tags[$tags_count - 1] = $exp_exclude_tags[0];

                foreach ($ad_exclude_tags as $key => $ad_exclude_tag) {

                    $ad_exclude_tag = explode("%", $ad_exclude_tag);

                    $ad_exclude_tags[$key] = $ad_exclude_tag;
                }

                foreach ($ad_exclude_tags as $key => $ad_exclude_tag) {
                    if ($ad_exclude_tag[0] == "category") {
                        array_push($specify_ids['exclude']['category'], $ad_exclude_tag[1]);
                    } elseif ($ad_exclude_tag[0] == "post_tag") {
                        array_push($specify_ids['exclude']['post_tag'], $ad_exclude_tag[1]);
                    } elseif ($ad_exclude_tag[0] == "post") {
                        array_push($specify_ids['exclude']['post'], $ad_exclude_tag[1]);
                    } elseif ($ad_exclude_tag[0] == "page") {
                        array_push($specify_ids['exclude']['page'], $ad_exclude_tag[1]);
                    }
                }
            }

            $ad_allow = TRUE;

            /** Check if current page included or excloded */
            if (is_archive()) {
                $term = get_queried_object();

                if (!empty($term)) {
                    $term_id = $term->term_id;

                    if (in_array($term_id, $specify_ids['include']['category']) || in_array($term_id, $specify_ids['include']['post_tag'])) {
                        $ad_allow = TRUE;
                    } elseif (!empty($ad_include_tags)) {
                        $ad_allow = FALSE;
                    }

                    if (in_array($term_id, $specify_ids['exclude']['category']) || in_array($term_id, $specify_ids['exclude']['post_tag'])) {
                        $ad_allow = FALSE;
                    }
                } elseif (!empty($ad_include_tags)) {
                    $ad_allow = FALSE;
                }
            } elseif (is_page() || is_single()) {

                $post_terms_ids = array();
                $post_tag_ids = array();
                $post_id = get_the_ID();

                $all_taxonomies = get_taxonomies();
                unset($all_taxonomies["link_taxonomy"]);
                unset($all_taxonomies["post_format"]);
                unset($all_taxonomies["post_tag"]);

                $post_terms = wp_get_post_terms(get_the_ID(), $all_taxonomies, array('fields' => 'ids'));
                if (!empty($post_terms)) {
                    $post_terms_ids = array_merge($post_terms_ids, $post_terms);
                }

                $post_tags = wp_get_post_terms(get_the_ID(), "post_tag", array('fields' => 'ids'));
                if (!empty($post_tags)) {
                    $post_tag_ids = array_merge($post_tag_ids, $post_tags);
                }


                $inter_terms = array_intersect($specify_ids['include']['category'], $post_terms_ids);
                $inter_tags = array_intersect($specify_ids['include']['post_tag'], $post_tag_ids);
                if (in_array($post_id, $specify_ids['include']['post']) || in_array($post_id, $specify_ids['include']['page']) || !empty($inter_terms) || !empty($inter_tags)) {
                    $ad_allow = TRUE;
                } elseif (!empty($ad_include_tags)) {
                    $ad_allow = FALSE;
                }

                $inter_terms = array_intersect($specify_ids['exclude']['category'], $post_terms_ids);
                $inter_tags = array_intersect($specify_ids['exclude']['post_tag'], $post_tag_ids);
                if (in_array($post_id, $specify_ids['exclude']['post']) || in_array($post_id, $specify_ids['exclude']['page']) || !empty($inter_terms) || !empty($inter_tags)) {
                    $ad_allow = FALSE;
                }
            } else {
                if (!empty($ad_include_tags)) {
                    $ad_allow = FALSE;
                }
            }
        } else {
            $ad_allow = TRUE;
        }

        // Get restrict parameters
        $ad_restrict_views = isset($ads_options[$ad_id]["restrict_views"]) ? $ads_options[$ad_id]["restrict_views"] : "";
        $ad_restrict_visits = isset($ads_options[$ad_id]["restrict_visits"]) ? $ads_options[$ad_id]["restrict_visits"] : "";
        $ad_content = isset($ads_options[$ad_id]["ad_content"]) ? $ads_options[$ad_id]["ad_content"] : "";
        $ad_deadline = isset($ads_options[$ad_id]["deadline"]) ? $ads_options[$ad_id]["deadline"] : "";
        $ad_views = isset($ads_stat[$ad_id]["view"]) ? $ads_stat[$ad_id]["view"] : 0;
        $ad_visits = isset($ads_stat[$ad_id]["visit"]) ? $ads_stat[$ad_id]["visit"] : 0;

        // get curent date
        $current_date = date('Y-m-d', current_time('timestamp'));

        if ($ad_allow == FALSE || empty($ad_content) || $campaign_ad["status"] == "suspended" || (!empty($ad_deadline) && strtotime($current_date) > $ad_deadline) || (!empty($ad_restrict_views) && $ad_views >= $ad_restrict_views) || (!empty($ad_restrict_visits) && $ad_visits >= $ad_restrict_visits)) {
            unset($campaign_ads[$ad_id]);
        }
    }

    // Check whether campaign has enable ads
    if (empty($campaign_ads)) {
        return;
    }

    // Get cookie for this campaign ads
    $sa_bg_info = isset($_COOKIE['sa_bg_info']) ? $_COOKIE['sa_bg_info'] : '';
    $sa_bg_info = json_decode(stripslashes($sa_bg_info), TRUE);

    // Check if cookie is set for this campaign ads
    if (!empty($sa_bg_info) && $sa_bg_info["campaign_id"] == $campaign['id']) {

        $lasts_priority = $sa_bg_info["last"];
        $last_id = isset($sa_bg_info["last_id"]) ? $sa_bg_info["last_id"] : FALSE;

        /** check if interval is valid display last else second by priority */
        $last_ad = isset($campaign_ads[$last_id]) ? $campaign_ads[$last_id] : FALSE;

        if (isset($_COOKIE['sa_bg_change_interval']) && $camp_options['change_interval'] !== -1 && !empty($last_ad) && in_array($last_ad, $campaign_ads)) {
            $bg_ad = $last_ad;

            $camp_options["change_interval"] = "during";
        } else {
            $ads_arr_vals = array_values($campaign_ads);

            $first_priority = $ads_arr_vals[0]["priority"];
            $last_priority = $ads_arr_vals[count($campaign_ads) - 1]["priority"];

            $ad_choosen = FALSE;

            while (empty($ad_choosen)) {
                $lasts_priority++;
                if ($lasts_priority > $last_priority) {
                    $lasts_priority = $first_priority;
                }

                $bg_ad = $ads_by_priority[$lasts_priority];
                
                if (!empty($bg_ad) && in_array($bg_ad, $campaign_ads)) {
                    $ad_choosen = TRUE;
                }
            }
        }
    } else {
        // Get first ad(enable) by priority and display        
        $ads_arr_vals = array_values($campaign_ads);

        $bg_ad = $ads_arr_vals[0];
    }

    // Check if ad exists
    if (empty($bg_ad)) {
        return;
    }

    /** Set options array for js */
    $bg_options["bg_selector"] = $camp_options["background_selector"];
    $bg_options["bg_change_interval"] = $camp_options["change_interval"];
    $bg_options["bg_background_type"] = $camp_options["background_type"];
    $bg_options["bg_link_to"] = $ads_options[$bg_ad['id']]["link_to"];
    $bg_options["bg_restrict_views"] = $ads_options[$bg_ad['id']]["restrict_views"];
    $bg_options["bg_restrict_visits"] = $ads_options[$bg_ad['id']]["restrict_visits"];
    $bg_options["bg_ad_content"] = $ads_options[$bg_ad['id']]["ad_content"];
    $bg_options["bg_ad_id"] = $bg_ad["id"];

    $sa_bg_info["campaign_id"] = $bg_ad["campaign_id"];
    $sa_bg_info["last"] = $bg_ad["priority"];
    $sa_bg_info["last_id"] = $bg_ad["id"];
    ?>
    <script>
        bg_options = <?php echo json_encode($bg_options); ?>;
        sa_bg_info = <?php echo json_encode($sa_bg_info); ?>;
    </script>
    <?php
}

add_action('wp_enqueue_scripts', 'sa_bg_before_page_template_load');
