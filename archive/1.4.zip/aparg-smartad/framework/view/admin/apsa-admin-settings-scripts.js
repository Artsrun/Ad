jQuery(document).ready(function ($) {
    /*
     * set CodeMirror textareas values
     */
    var code_areas = document.getElementsByClassName("apsa-code-area");
    var myCodeMirrors = {};
    myCodeMirrors.customCss = CodeMirror.fromTextArea(code_areas[0], {
        lineNumbers: true,
        mode: "htmlmixed",
    });
    myCodeMirrors.customCss.setValue($('#apsa-custom-css-value').val());

    /**
     * Display detailed description of field
     */
    $(document).on("click", ".apsa-with-question", function () {
        apsa_action_message("info", $(this).attr("data-apsa-message"));
    });

    /**
     * Close popup
     */
    $(document).on('click', '#apsa-managing-overlay, .apsa-close-popup', function () {
        $('.apsa-popup').attr('data-apsa-open', "false");
        jQuery('body').removeClass('modal-open');
        $('#apsa-managing-overlay').fadeOut(150);
    });

    /*
     *  save extra options 
     */
    $(document).on("click", "#apsa-update-settings", function () {
        enaableLeavepage = false;
    });

    /**
     * close anticache notice
     */
    $(document).on("click", ".apsa-dismissible", function () {
        $(this).parent('div').hide();
        apsa_set_cookie('apsa_anticache_notice', 'no');
    });

    /*
     * Show a prompt before the user leaves the current page
     */

    $(window).load(function () {
        $(document).on('change', 'input, textarea, select', function () {
            enaableLeavepage = true;
        });
    });

    $(window).bind('beforeunload', function () {
        if (typeof enaableLeavepage != 'undefined' && enaableLeavepage == true) {
            return apsa_admin_labels['unsaved_reload'];
        }
    });

    // desable apsa-new class 
    if (typeof apsa_new != 'undefined' && apsa_new == false) {
        $('.apsa-new').each(function () {
            $(this).addClass('apsa-new-hide');
        });
    }

});