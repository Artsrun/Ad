<?php
defined('ABSPATH') or die('No script kiddies please!');

/**
 * Create widget "plugin campaign"
 */
class APSA_Campaign_Embed extends WP_Widget {

    /**
     * Register widget with WordPress.
     */
    function __construct() {
        global $apsa_plugin_data;
        global $apsa_admin_labels;
        parent::__construct(
                'apsa_campaign', // Base ID
                $apsa_plugin_data['plugin_data']['name'], // Name
                array('description' => $apsa_admin_labels['widget_desc'] // Description
                ) // Args 
        );
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget($args, $instance) {
        global $apsa_plugin_data;
        echo $args['before_widget'];
        if (!empty($instance['campaign_id'])) {
            $embed_align = isset($instance["embed_align"]) ? $instance["embed_align"] : 'none';
            echo do_shortcode("[" . strtolower($apsa_plugin_data['plugin_data']['name']) . " id='{$instance["campaign_id"]}' widget='1' align='{$embed_align}']");
        }
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     */
    public function form($instance) {
        global $apsa_admin_labels;
        // Get campaigns
        $campaigns = apsa_get_campaigns();

        /** Separate campaigns type of embed */
        if (!empty($campaigns)) {
            foreach ($campaigns as $key => $campaign) {
                if ($campaign['type'] !== 'embed') {
                    unset($campaigns[$key]);
                }
            }
        }

        $campaign_id = !empty($instance['campaign_id']) ? $instance['campaign_id'] : 0;
        $embed_align = !empty($instance['embed_align']) ? $instance['embed_align'] : 0;
        ?>
        <?php if (!empty($campaigns)): ?>
            <p>
                <label for="<?php echo $this->get_field_id('campaign_id'); ?>"><?php echo $apsa_admin_labels["camp_name_embed"]; ?>:</label>
                <select class="widefat" id="<?php echo $this->get_field_id('campaign_id'); ?>" name="<?php echo $this->get_field_name('campaign_id'); ?>">
                    <option value="0"><?php echo $apsa_admin_labels["select_campaign"]; ?></option>
                    <?php
                    foreach ($campaigns as $key => $campaign) {
                        ?>
                        <option value="<?php echo $campaign['id']; ?>"<?php if ($campaign['id'] == esc_attr($campaign_id)): ?> selected="selected"<?php endif; ?>><?php echo!empty($campaign['name']) ? $campaign['name'] : "No tiltle (id is " . $campaign['id'] . ")"; ?></option>
                        <?php
                    }
                    ?>
                </select>
                <span><?php echo $apsa_admin_labels["select_embed_campaign"]; ?></span>
            </p>
            <p>    
                <label for="<?php echo $this->get_field_id('embed_align'); ?>"><?php echo $apsa_admin_labels["embed_alignment"]; ?>:</label>
                <select class="widefat" id="<?php echo $this->get_field_id('embed_align'); ?>" name="<?php echo $this->get_field_name('embed_align'); ?>"> 
                    <option value="none" <?php if ('none' == esc_attr($embed_align)): ?> selected="selected"<?php endif; ?>><?php echo $apsa_admin_labels["alignment_none"]; ?></option>
                    <option value="left" <?php if ('left' == esc_attr($embed_align)): ?> selected="selected"<?php endif; ?>><?php echo $apsa_admin_labels["alignment_left"]; ?></option>
                    <option value="center" <?php if ('center' == esc_attr($embed_align)): ?> selected="selected"<?php endif; ?>><?php echo $apsa_admin_labels["alignment_center"]; ?></option>
                    <option value="right" <?php if ('right' == esc_attr($embed_align)): ?> selected="selected"<?php endif; ?>><?php echo $apsa_admin_labels["alignment_right"]; ?></option>
                </select>
                <span><?php echo $apsa_admin_labels["select_embed_alignment"]; ?></span>
            </p>
        <?php else: ?>
            <p><?php echo $apsa_admin_labels["no_campaign_to_select"]; ?></p> 
        <?php endif; ?>
        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update($new_instance, $old_instance) {

        $instance = array();
        $instance['campaign_id'] = (!empty($new_instance['campaign_id']) ) ? strip_tags($new_instance['campaign_id']) : '';
        $instance['embed_align'] = (!empty($new_instance['embed_align']) ) ? strip_tags($new_instance['embed_align']) : '';
        return $instance;
    }

}

// register Foo_Widget widget
function register_apsa_campaign_embed() {
    register_widget('APSA_Campaign_Embed');
}

add_action('widgets_init', 'register_apsa_campaign_embed');
