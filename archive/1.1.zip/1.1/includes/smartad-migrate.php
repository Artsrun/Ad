<?php
defined('ABSPATH') or die('No script kiddies please!');

/* version 1.0 -> version 1.1*/

// migrate custom css
$sa_custom_css = get_option('sa_custom_css');
$sa_extra_options = get_option('sa_extra_options');
if($sa_custom_css !== FALSE && $sa_extra_options !== FALSE){
    $sa_extra_options['sa_custom_css'] = stripslashes($sa_custom_css);
    update_option('sa_extra_options', $sa_extra_options);
    delete_option('sa_custom_css');
}

// migrate embad campaigns height option, set int value
$sa_campaigns = sa_get_campaigns();
if(!empty($sa_campaigns)){
    foreach ($sa_campaigns as $sa_campaign){
        if($sa_campaign['type'] == 'embed'){
            $sa_height_option_name = 'height';
            $height = sa_get_campaign_options($sa_campaign['id'],$sa_height_option_name);
            if($height != ''){
                $find = array("px","%");
                $replace = array("");
                $height = str_replace($find, $replace, $height);
                $sa_height_option = array($sa_height_option_name => $height);
                sa_update_campaign_options($sa_campaign['id'],$sa_height_option);
            }
        }
    }
}

/**
 * Db tabels updates write here
 */
global $sa_db_version;
if (get_site_option('sa_db_version') != $sa_db_version) {

}

