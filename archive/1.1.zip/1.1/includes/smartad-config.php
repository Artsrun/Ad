<?php
defined('ABSPATH') or die('No script kiddies please!');
/**
 * The base configurations of the SmartAd.
 */

// Aparg site link
define("SA_APARG_LINK", "http://aparg.com");

// smartad db version
global $sa_db_version;
$sa_db_version = '1.0';

// tables and options names for Smartad
global $sa_uninstall;
$sa_uninstall = array(
    'sa_tables' =>  array(
        'sa_campaigns',
        'sa_campaign_options',
        'sa_ads',
        'sa_ad_options',
        'sa_ad_statistics'
    ),
    'sa_options' => array(
        'widget_sa_campaign',
        'sa_db_version',
        'sa_extra_options',
    ) 
);