<?php

defined('ABSPATH') or die('No script kiddies please!');

/**
 * Adds new row in wp_sa_campaigns table
 * 
 * @global object $wpdb
 * @param str $name
 * @param str $type
 * @param str $status
 * @param array $defaults
 * @return int
 */
function sa_add_campaign($type, $name = '', $status = "suspended", $defaults = array()) {
    global $wpdb;

    if (empty($name)) {
        switch ($type) {
            case 'background':
                $name = __('Background campaign', 'aparg-smartad');
                break;
            case 'popup':
                $name = __('Popup campaign', 'aparg-smartad');
                break;
            case 'embed':
                $name = __('Embed campaign', 'aparg-smartad');
                break;
            default:
                $name = '';
                break;
        }

        $name = $name . " - (" . date_i18n(get_option('date_format'), current_time('timestamp')) . ")";
    }

    $wpdb->insert(
            $wpdb->prefix . 'sa_campaigns', array(
        'type' => $type,
        'name' => $name,
        'status' => $status,
        'creation_date' => date('Y-m-d', current_time('timestamp')),
            )
    );

    $campaign_id = $wpdb->insert_id;

    if (!empty($defaults)) {
        $camp_defaults = sa_update_campaign_options($campaign_id, $defaults);
    }

    if (!empty($defaults) && $camp_defaults === FALSE) {
        return FALSE;
    } else {
        $new_campaign = array();

        $new_campaign['campaign_id'] = $campaign_id;
        $new_campaign['creation_date'] = date_i18n(get_option('date_format'), current_time('timestamp'));

        return $new_campaign;
    }
}

/**
 * Get campaigns from database
 * 
 * @param array|int $campaign_ids
 * @return array
 */
function sa_get_campaigns($campaign_ids = 'all') {

    /** determin request type and retur result */
    if (is_array($campaign_ids)) {
        foreach ($campaign_ids as $key => $value) {
            if ($key == 0) {
                $where_clause = " WHERE id = " . $value;
            } else {
                $where_clause .= " OR id = " . $value;
            }
        }
    } elseif (is_int($campaign_ids)) {
        $where_clause = " WHERE id = " . $campaign_ids;
    } elseif ($campaign_ids == 'all') {
        $where_clause = '';
    } else {
        return 'Bad request!';
    }

    /** Get from db wp_sa_campaigns table */
    global $wpdb;

    $campaign_table = $wpdb->prefix . 'sa_campaigns';

    $campaigns = $wpdb->get_results('SELECT * FROM ' . $campaign_table . $where_clause . ' ORDER BY id DESC', ARRAY_A);

    return $campaigns;
}

/**
 * Get campaign ads from databse with customm order
 * 
 * @global object $wpdb
 * @param int $campaign_id
 * @param str $order_by
 * @param str $order
 * @return array
 */
function sa_get_campaign_ads($campaign_id, $order_by = 'priority', $order = 'ASC') {

    /** Get ads from wp_sa_ads  table */
    global $wpdb;

    $order_clause = '';

    if (!empty($order_by) && !empty($order)) {
        $order_clause = ' ORDER BY ' . $order_by . ' ' . $order;
    }

    $ads_table = $wpdb->prefix . 'sa_ads';

    $campaign_ads = $wpdb->get_results('SELECT * FROM ' . $ads_table . ' WHERE campaign_id = ' . $campaign_id . $order_clause, ARRAY_A);

    return $campaign_ads;
}

/**
 * Update campaign options
 * 
 * @global object $wpdb
 * @param int $campaign_id
 * @param array $options
 * @return none
 */
function sa_update_campaign_options($campaign_id, $options) {

    /** Check if wrong argument return error message */
    if (!is_array($options)) {
        return "Bad request!";
    }

    global $wpdb;

    $campaign_options_table = $wpdb->prefix . 'sa_campaign_options';

    $insert_values = '';
    $counter = 0;
    foreach ($options as $key => $option) {
        $counter ++;

        $insert_values .= '("' . $campaign_id . '", "' . $key . '", "' . $option . '")';
        if ($counter != count($options)) {

            $insert_values .= ', ';
        }
    }

    $query = $wpdb->query('INSERT INTO ' . $campaign_options_table . ' (campaign_id, option_name, option_value) VALUES ' . $insert_values . ' ON DUPLICATE KEY UPDATE option_value = VALUES(option_value)');

    return $query;
}

/**
 * Get campaign option value or all options 
 * 
 * @global object $wpdb
 * @param int $campaign_id
 * @param str $option_name
 * @return array
 */
function sa_get_campaign_options($campaign_id, $option_name = 'all') {

    /** Get options from wp_sa_campaign_options table */
    global $wpdb;

    $campaign_options_table = $wpdb->prefix . 'sa_campaign_options';

    if ($option_name == "all") {
        $name_condition = '';
    } else {
        $name_condition = ' AND option_name = "' . $option_name . '"';
    }

    $campaign_options = $wpdb->get_results('SELECT option_name, option_value FROM ' . $campaign_options_table . ' WHERE campaign_id = ' . $campaign_id . $name_condition, ARRAY_A);

    if ($option_name == "all") {
        return $campaign_options;
    } elseif (empty($campaign_options)) {
        return '';
    } else {
        return $campaign_options[0]['option_value'];
    }
}

/**
 * Get ad option value or all options 
 * 
 * @global object $wpdb
 * @param int $ad_id
 * @param str $option_name
 * @return array
 */
function sa_get_ad_options($ad_id, $option_name = 'all') {

    /** Get options from wp_sa_ad_options table */
    global $wpdb;

    $ad_options_table = $wpdb->prefix . 'sa_ad_options';

    if ($option_name == "all") {
        $name_condition = '';
    } else {
        $name_condition = ' AND option_name = "' . $option_name . '"';
    }

    $ad_options = $wpdb->get_results('SELECT * FROM ' . $ad_options_table . ' WHERE ad_id = "' . $ad_id . '"' . $name_condition, ARRAY_A);

    if ($option_name == "all") {
        return $ad_options;
    } elseif (empty($ad_options)) {
        return '';
    } else {
        return $ad_options[0]['option_value'];
    }
}

/**
 * Update add options
 * 
 * @global object $wpdb
 * @param int $ad_id
 * @param array $options
 * @return string
 */
function sa_update_ad_options($ad_id, $options) {


    /** Check if wrong argument return error message */
    if (!is_array($options)) {
        return "Bad request!";
    }

    global $wpdb;

    $ad_options_table = $wpdb->prefix . 'sa_ad_options';

    $insert_values = '';
    $counter = 0;

    foreach ($options as $key => $option) {
        $counter ++;

        $insert_values .= '("' . $ad_id . '", "' . $key . '", "' . $option . '")';
        if ($counter != count($options)) {

            $insert_values .= ', ';
        }
    }

    $query = $wpdb->query('INSERT INTO ' . $ad_options_table . ' (ad_id, option_name, option_value) VALUES ' . $insert_values . ' ON DUPLICATE KEY UPDATE option_value = VALUES(option_value)');

    return $query;
}

/**
 * Insert new ad
 * 
 * @global object $wpdb
 * @param str $title
 * @param str $type
 * @return int
 */
function sa_insert_ad($campaign_id, $title = '', $type = '', $status = "active", $priority = 0) {

    global $wpdb;

    $ads_table = $wpdb->prefix . 'sa_ads';

    if (empty($title)) {

        switch ($type) {
            case 'image':
                $title = __('Image', 'aparg-smartad');
                break;
            case 'video':
                $title = __('Video', 'aparg-smartad');
                break;
            case 'flash':
                $title = __('Flash', 'aparg-smartad');
                break;
            case 'html':
                $title = __('Code', 'aparg-smartad');
                break;
            case 'iframe':
                $title = __('Iframe', 'aparg-smartad');
                break;
            default:
                $title = '';
                break;
        }

        $title = $title . " - (" . date_i18n(get_option('date_format'), current_time('timestamp')) . ")";
    }

    /** Increment ads priority */
    $wpdb->query('UPDATE ' . $ads_table . ' SET priority = priority+1 WHERE priority >= "' . $priority . '" AND campaign_id = "' . $campaign_id . '"');

    $wpdb->insert(
            $ads_table, array(
        'campaign_id' => $campaign_id,
        'title' => $title,
        'type' => $type,
        'status' => $status,
        'priority' => $priority,
        'creation_date' => date('Y-m-d', current_time('timestamp')),
            )
    );

    $new_ad = array();
    $new_ad['ad_id'] = $wpdb->insert_id;
    $new_ad['creation_date'] = date_i18n(get_option('date_format'), current_time('timestamp'));

    return $new_ad;
}

/**
 * Update ad 
 * 
 * @global object $wpdb
 * @param int $ad_id
 * @param str $title
 * @param str $type
 */
function sa_update_ad($ad_id, $title = '', $type = '', $priority = '', $status = '') {


    if ($title == '' && $type == '' && $priority == '' && $status == '') {
        return 'Bad request!';
    }

    global $wpdb;

    $ads_table = $wpdb->prefix . 'sa_ads';

    $data_array = array();
    $data_array['title'] = $title;
    $data_array['type'] = $type;
    $data_array['priority'] = $priority;
    $data_array['status'] = $status;

    $set_query = '';
    $not_first = FALSE;
    foreach ($data_array as $key => $value) {
        if (!empty($value) || $value == "0") {
            if ($not_first == FALSE) {
                $set_query .= 'SET ' . $key . '="' . $value . '"';
                $not_first = TRUE;
            } else {
                $set_query .= ', ' . $key . '="' . $value . '"';
            }
        }
    }

    $query = $wpdb->query('UPDATE ' . $ads_table . ' ' . $set_query . ' WHERE id = "' . $ad_id . '"');

    return $query;
}

/**
 * Delete ad and its options 
 * 
 * @global object $wpdb
 * @param int $ad_id
 */
function sa_delete_ad($ad_id) {

    global $wpdb;

    $ads_table = $wpdb->prefix . 'sa_ads';
    $ad_options_table = $wpdb->prefix . 'sa_ad_options';
    $statistics_table = $wpdb->prefix . 'sa_ad_statistics';

    /** Get ad priority and campaign id */
    $priority = sa_get_ad_data($ad_id, "priority");
    $campaign_id = sa_get_ad_data($ad_id, "campaign_id");

    // Delete ad from ads table
    $delete_ad = $wpdb->delete($ads_table, array('id' => $ad_id));

    /** Decrement ads priority */
    $update_priority = $wpdb->query('UPDATE ' . $ads_table . ' SET priority = priority-1 WHERE priority > "' . $priority . '" AND campaign_id = "' . $campaign_id . '"');

    // Delete Ad options
    $delete_options = $wpdb->delete($ad_options_table, array('ad_id' => $ad_id));

    // Delete ad statistics
    $delete_stat = $wpdb->delete($statistics_table, array('ad_id' => $ad_id));

    if ($delete_ad === FALSE || $update_priority === FALSE || $delete_options === FALSE || $delete_stat === FALSE) {
        return FALSE;
    } else {
        return TRUE;
    }
}

/**
 * Update campaign data
 * 
 * @global object $wpdb
 * @param int $campaign_id
 * @param str $name
 * @param str $type
 * @param str $status
 * @return str
 */
function sa_update_campaign($campaign_id, $name = '', $type = '', $status = '') {

    if ($name == '' && $type == '' && $status == '') {
        return 'Bad request!';
    }

    global $wpdb;

    $campaigns_table = $wpdb->prefix . 'sa_campaigns';

    $data_array = array();
    $data_array['name'] = $name;
    $data_array['type'] = $type;
    $data_array['status'] = $status;

    $set_query = '';
    $first = TRUE;
    foreach ($data_array as $key => $value) {
        if (!empty($value)) {
            if ($first == TRUE) {
                $set_query .= 'SET ' . $key . '="' . $value . '"';
                $first = FALSE;
            } else {
                $set_query .= ', ' . $key . '="' . $value . '"';
            }
        }
    }

    $update = $wpdb->query('UPDATE ' . $campaigns_table . ' ' . $set_query . ' WHERE id = "' . $campaign_id . '"');

    return $update;
}

/**
 * Get campaigns count with any status or all
 * 
 * @global object $wpdb
 * @param str $status
 * @return int
 */
function sa_get_campaigns_count($status = 'all') {

    global $wpdb;

    $campaigns_table = $wpdb->prefix . 'sa_campaigns';

    /** Set where clause */
    $where_clause = "";

    if ($status !== 'all') {
        $where_clause = " WHERE status = '" . $status . "'";
    }

    // Get count
    $campaigns_count = $wpdb->get_var("SELECT COUNT(*) FROM " . $campaigns_table . $where_clause);

    return $campaigns_count;
}

/**
 * Delete campaign and its options, ads and ads options
 * 
 * @global object $wpdb
 * @param int $campaign_id
 */
function sa_delete_campaign($campaign_id) {

    global $wpdb;

    $campaigns_table = $wpdb->prefix . 'sa_campaigns';
    $campaign_options_table = $wpdb->prefix . 'sa_campaign_options';
    $ads_table = $wpdb->prefix . 'sa_ads';

    // Delete campaign from campaigns table
    $delete_camp = $wpdb->delete($campaigns_table, array('id' => $campaign_id));

    // Delete campaign options
    $delete_options = $wpdb->delete($campaign_options_table, array('campaign_id' => $campaign_id));

    // Get deleted campaign ads
    $campaign_ads = $wpdb->get_results('SELECT id FROM ' . $ads_table . ' WHERE campaign_id = "' . $campaign_id . '"', ARRAY_A);

    $delete_ads = TRUE;
    if (!empty($campaign_ads)) {
        foreach ($campaign_ads as $ad) {
            if (sa_delete_ad($ad["id"]) === FALSE) {
                $delete_ads = FALSE;
            }
        }
    }

    if ($delete_camp === FALSE || $delete_options === FALSE || $delete_ads === FALSE) {
        return FALSE;
    } else {
        return TRUE;
    }
}

/**
 * Check if ad enable or disable
 * 
 * @param int $ad_id
 * @return boolean
 */
function sa_is_enable_ad($ad_id) {
    if (sa_get_ad_options($ad_id, "disable") == "on") {
        return FALSE;
    } else {
        return TRUE;
    }
}

/**
 * Returns ad or specific ad data
 * 
 * @global object $wpdb
 * @param int $ad_id
 * @param str $data_name
 * @return array | str
 */
function sa_get_ad_data($ad_id, $data_name = FALSE) {

    global $wpdb;

    $ads_table = $wpdb->prefix . 'sa_ads';

    if (empty($data_name)) {
        $data = $wpdb->get_results('SELECT * FROM ' . $ads_table . ' WHERE id = "' . $ad_id . '"', ARRAY_A);
        $data = isset($data[0]) ? $data[0] : "";
    } else {
        $data = $wpdb->get_results('SELECT ' . $data_name . ' FROM ' . $ads_table . ' WHERE id = "' . $ad_id . '"', ARRAY_A);
        $data = isset($data[0][$data_name]) ? $data[0][$data_name] : "";
    }

    return $data;
}

/**
 * Return campaigns by type, with additional clause: active or not
 * 
 * @global object $wpdb
 * @param str $campaign_type
 * @param boolean $active
 * @return int | array
 */
function sa_get_active_campaign($campaign_type) {

    if ($campaign_type !== "background" && $campaign_type !== "popup") {
        return FALSE;
    }

    global $wpdb;

    $campaigns_table = $wpdb->prefix . 'sa_campaigns';

    $campaign = $wpdb->get_row('SELECT * FROM ' . $campaigns_table . ' WHERE status = "active" AND type = "' . $campaign_type . '"', ARRAY_A);
    if (!empty($campaign)) {

        return $campaign;
    }
}

/**
 * Returne campaign ad by priority
 * 
 * @global object $wpdb
 * @param int $campaign_id
 * @param int $priority
 * If not set return ad by priority 0
 * @return array
 */
function sa_get_ad_by_priority($campaign_id, $priority = 0) {

    global $wpdb;

    $ads_table = $wpdb->prefix . 'sa_ads';

    $ad = $wpdb->get_results('SELECT * FROM ' . $ads_table . ' WHERE campaign_id = "' . $campaign_id . '" AND priority = "' . $priority . '"', ARRAY_A);

    return $ad[0];
}

/**
 * Return campaign data
 * 
 * @global object $wpdb
 * @param int $campaign_id
 * @param str $data_name
 * @return array | string
 */
function sa_get_campaign_data($campaign_id, $data_name = FALSE) {

    global $wpdb;

    $campaigns_table = $wpdb->prefix . 'sa_campaigns';

    if (empty($data_name)) {
        $data = $wpdb->get_results('SELECT * FROM ' . $campaigns_table . ' WHERE id = "' . $campaign_id . '"', ARRAY_A);
        $data = $data[0];
    } else {
        $data = $wpdb->get_results('SELECT ' . $data_name . ' FROM ' . $campaigns_table . ' WHERE id = "' . $campaign_id . '"', ARRAY_A);
        $data = $data[0][$data_name];
    }

    return $data;
}

/**
 * Inserts new view or visit on ad statistics table
 * 
 * @global object $wpdb
 * @param int $ad_id
 * @param str $type
 * @return int
 */
function sa_update_ad_statistics($ad_id, $type) {

    global $wpdb;

    $statistics_table = $wpdb->prefix . 'sa_ad_statistics';

    $update_stat = $wpdb->query('INSERT INTO `' . $statistics_table . '` (ad_id, type, date, count) VALUES ("' . $ad_id . '", "' . $type . '", "' . date('Y-m-d', current_time('timestamp')) . '", 1) ON DUPLICATE KEY UPDATE count=count+1');

    return $update_stat;
}

/**
 * Get campaign ads count
 * 
 * @global object $wpdb
 * @param int $campaign_id
 * @return int
 */
function sa_get_campaign_ads_count($campaign_id, $ad_status = NULL) {

    global $wpdb;

    $ads_table = $wpdb->prefix . 'sa_ads';

    if (isset($ad_status)) {
        $ads_count = $wpdb->get_var("SELECT COUNT(*) FROM " . $ads_table . " WHERE campaign_id = '" . $campaign_id . "' AND status = '" . $ad_status . "'");
    } else {
        $ads_count = $wpdb->get_var("SELECT COUNT(*) FROM " . $ads_table . " WHERE campaign_id = '" . $campaign_id . "'");
    }

    return $ads_count;
}

/**
 * Get campaign ads views total count
 * 
 * @global object $wpdb
 * @param type $campaign_id
 * @return type
 */
function sa_get_campaign_views_count($campaign_id) {

    global $wpdb;

    $statistics_table = $wpdb->prefix . 'sa_ad_statistics';

    $campaign_ads = (sa_get_campaign_ads($campaign_id));

    $views_count = 0;

    foreach ($campaign_ads as $key => $campaign_ad) {
        $ad_views_count = $wpdb->get_var("SELECT COUNT(*) FROM " . $statistics_table . " WHERE ad_id = '" . $campaign_ad['id'] . "' AND type = 'view'");
        $views_count += $ad_views_count;
    }

    return $views_count;
}

/**
 * Get campaign ads visits total count
 * 
 * @global object $wpdb
 * @param type $campaign_id
 * @return type
 */
function sa_get_campaign_visits_count($campaign_id) {

    global $wpdb;

    $statistics_table = $wpdb->prefix . 'sa_ad_statistics';

    $campaign_ads = (sa_get_campaign_ads($campaign_id));

    $visits_count = 0;

    foreach ($campaign_ads as $key => $campaign_ad) {
        $ad_vidits_count = $wpdb->get_var("SELECT COUNT(*) FROM " . $statistics_table . " WHERE ad_id = '" . $campaign_ad['id'] . "' AND type = 'visit'");
        $visits_count += $ad_vidits_count;
    }

    return $visits_count;
}

/**
 * Get ad views total count
 * 
 * @global object $wpdb
 * @param int $ad_id
 * @return int
 */
function sa_get_ad_views_count($ad_id, $from = NULL, $to = NULL) {

    global $wpdb;

    $statistics_table = $wpdb->prefix . 'sa_ad_statistics';

    $date_clause = "";

    $from = empty($from) ? date("0000-00-00") : $from;
    $to = empty($to) ? date("Y-m-d") : $to;

    $views_count = $wpdb->get_var("SELECT SUM(count) FROM " . $statistics_table . " WHERE ad_id = '" . $ad_id . "' AND type = 'view' AND (`date`>='$from' and `date`<='$to')");

    return $views_count;
}

/**
 * Get ad visits total count
 * 
 * @global object $wpdb
 * @param int $ad_id
 * @return int
 */
function sa_get_ad_visits_count($ad_id, $from = NULL, $to = NULL) {

    global $wpdb;

    $statistics_table = $wpdb->prefix . 'sa_ad_statistics';

    $date_clause = "";

    $from = empty($from) ? date("0000-00-00") : $from;
    $to = empty($to) ? date("Y-m-d") : $to;

    $visits_count = $wpdb->get_var("SELECT SUM(count) FROM " . $statistics_table . " WHERE ad_id = '" . $ad_id . "' AND type = 'visit' AND (`date`>='$from' and `date`<='$to')");

    return $visits_count;
}

/**
 * Calculate ad crt
 * 
 * @param int $ad_id
 * @return int
 */
function sa_get_ad_crt($ad_id) {

    $ads_stat_counts = sa_get_ad_stat_counts(array($ad_id));
    $views_count = 0;
    $visits_count = 0;
    foreach ($ads_stat_counts as $stat) {
        $views_count = ($views_count != 0) ? $views_count : (($stat['type'] == 'view') ? $stat['total_count'] : 0);
        $visits_count = ($visits_count != 0) ? $visits_count : (($stat['type'] == 'visit') ? $stat['total_count'] : 0);
    }
    if (empty($views_count)) {
        $crt = 0;
    } else {
        $crt = $visits_count / $views_count * 100;
        $crt = round($crt);
    }

    return $crt;
}

/**
 * Get campaign total statistics
 * 
 * @param int $camp_id
 * @return array
 */
function sa_get_camp_statistics($camp_id, $from = FALSE, $to = FALSE) {

    $from = empty($from) ? date("0000-00-00") : $from;
    $to = empty($to) ? date("Y-m-d") : $to;

    $camp_ads = sa_get_campaign_ads($camp_id, "title");
    $statistics["ads"] = array();
    $statistics["views"] = array();
    $statistics["visits"] = array();
    $ad_ids = array();

    if (!empty($camp_ads)) {

        foreach ($camp_ads as $camp_ad) {
            $ad_ids[] = $camp_ad["id"];
        }

        $ads_stat_counts = sa_get_ad_stat_counts($ad_ids, $from, $to);
        $stat_by_id = array();
        foreach ($ads_stat_counts as $stat) {
            $stat_by_id[$stat['ad_id']]['visit'] = (isset($stat_by_id[$stat['ad_id']]['visit']) && $stat_by_id[$stat['ad_id']]['visit'] != 0) ? $stat_by_id[$stat['ad_id']]['visit'] : (($stat['type'] == 'visit') ? $stat['total_count'] : 0);
            $stat_by_id[$stat['ad_id']]['view'] = (isset($stat_by_id[$stat['ad_id']]['view']) && $stat_by_id[$stat['ad_id']]['view'] != 0) ? $stat_by_id[$stat['ad_id']]['view'] : (($stat['type'] == 'view') ? $stat['total_count'] : 0);
        }

        foreach ($camp_ads as $camp_ad) {

            $statistics['ads'][] = $camp_ad["title"];
            $statistics['views'][] = intval(isset($stat_by_id[$camp_ad['id']]) ? $stat_by_id[$camp_ad['id']]['view'] : 0);
            $statistics['visits'][] = intval(isset($stat_by_id[$camp_ad['id']]) ? $stat_by_id[$camp_ad['id']]['visit'] : 0);
        }
    }

    return $statistics;
}

/**
 * Get ad statistics
 * 
 * @global object $wpdb
 * @param int $ad_id
 * @param date $from
 * @param date $to
 * @return array
 */
function sa_get_ad_statistics($ad_id, $from = FALSE, $to = FALSE) {

    global $wpdb;

    $statistics_table = $wpdb->prefix . 'sa_ad_statistics';

    $from = empty($from) ? date("0000-00-00") : $from;
    $to = empty($to) ? date("Y-m-d") : $to;

    $statistics_array = $wpdb->get_results("SELECT * FROM `$statistics_table` WHERE ad_id = $ad_id AND (`date`>='$from' and `date`<='$to') ORDER BY date ASC", ARRAY_A);
    $statistics["days"] = array();
    $statistics["views"] = array();
    $statistics["visits"] = array();

    if (!empty($statistics_array)) {

        $stat_by_day = array();
        foreach ($statistics_array as $data) {
            $stat_by_day[$data['date']]['visit'] = (isset($stat_by_day[$data['date']]['visit']) && $stat_by_day[$data['date']]['visit'] != 0) ? $stat_by_day[$data['date']]['visit'] : (($data['type'] == 'visit') ? $data['count'] : 0);
            $stat_by_day[$data['date']]['view'] = (isset($stat_by_day[$data['date']]['view']) && $stat_by_day[$data['date']]['view'] != 0) ? $stat_by_day[$data['date']]['view'] : (($data['type'] == 'view') ? $data['count'] : 0);
        }

        $first_day = strtotime($statistics_array[0]['date']);
        $last_day_key = count($statistics_array) - 1;
        $last_day = strtotime($statistics_array[$last_day_key]['date']);
        $stat_by_day_full = array();
        while ($first_day <= $last_day) {
            $day = date('Y-m-d', $first_day);
            $stat_by_day_full[$day] = isset($stat_by_day[$day]) ? $stat_by_day[$day] : array('visit' => 0, 'view' => 0);
            $first_day = $first_day + 86400;
        }

        foreach ($stat_by_day_full as $day => $value) {
            $statistics["days"][] = date_i18n(get_option('date_format'), strtotime($day));
            $statistics["views"][] = intval($value['view']);
            $statistics["visits"][] = intval($value['visit']);
        }
    }

    return $statistics;
}

/**
 * Get  all campaigns all options
 */
function sa_get_all_campaign_options() {
    global $wpdb;

    $campaign_options_table = $wpdb->prefix . 'sa_campaign_options';

    $get_campaign_options = $wpdb->get_results('SELECT * FROM `' . $campaign_options_table . '`', ARRAY_A);

    return $get_campaign_options;
}

/**
 * Get ads by ids
 */
function sa_get_ads($ad_ids = 'all') {
    /** determin request type and return result */
    if (is_array($ad_ids)) {
        foreach ($ad_ids as $key => $value) {
            if ($key == 0) {
                $where_clause = " WHERE id = " . $value;
            } else {
                $where_clause .= " OR id = " . $value;
            }
        }
    } elseif (is_int($ad_ids)) {
        $where_clause = " WHERE id = " . $ad_ids;
    } elseif ($ad_ids == 'all') {
        $where_clause = '';
    } else {
        return 'Bad request!';
    }

    /** Get from db wp_sa_ads table */
    global $wpdb;

    $ads_table = $wpdb->prefix . 'sa_ads';

    $get_ads = $wpdb->get_results('SELECT * FROM `' . $ads_table . '`' . $where_clause . ' ORDER BY priority ASC', ARRAY_A);

    return $get_ads;
}

/**
 * Get all ads all options
 */
function sa_get_all_ad_options($ad_ids = NULL) {
    global $wpdb;

    $ad_options_table = $wpdb->prefix . 'sa_ad_options';

    if (!isset($ad_ids)) {
        $get_ad_options = $wpdb->get_results('SELECT * FROM `' . $ad_options_table . '`', ARRAY_A);
    } elseif (is_array($ad_ids)) {
        $ad_ids_str = implode(',', $ad_ids);

        $get_ad_options = $wpdb->get_results('SELECT * FROM `' . $ad_options_table . '` WHERE ad_id IN(' . $ad_ids_str . ')', ARRAY_A);
    } else {
        $get_ad_options = FALSE;
    }

    return $get_ad_options;
}

/**
 * Get all ads statistics count
 */
function sa_get_ad_stat_counts($ad_ids = NULL, $from = FALSE, $to = FALSE) {

    $from = empty($from) ? date("0000-00-00") : $from;
    $to = empty($to) ? date("Y-m-d") : $to;

    global $wpdb;

    $ad_stats_table = $wpdb->prefix . 'sa_ad_statistics';

    if (isset($ad_ids)) {
        $ad_ids_str = implode(',', $ad_ids);

        $get_ads_stat = $wpdb->get_results("SELECT ad_id, type, SUM(count) AS total_count FROM `$ad_stats_table` WHERE ad_id IN($ad_ids_str) AND (`date`>='$from' and `date`<='$to') group by type,ad_id", ARRAY_A);
    } else {
        $get_ads_stat = $wpdb->get_results("SELECT ad_id, type, SUM(count) AS total_count FROM `$ad_stats_table` WHERE (`date`>='$from' and `date`<='$to') group by type,ad_id", ARRAY_A);
    }

    return $get_ads_stat;
}

/**
 * Get ads statistics
 */
function sa_get_ads_statistics($camp_id = NULL, $from = FALSE, $to = FALSE) {

    $camps_ads_stats = array();

    if (!empty($camp_id)) {
        $camp_ads = sa_get_campaign_ads($camp_id);

        $camp_stat = sa_get_camp_statistics($camp_id, $from, $to);

        $camps_ads_stats[$camp_id]['camp_stat'] = $camp_stat;

        if (!empty($camp_ads)) {
            foreach ($camp_ads as $camp_ad) {
                $camps_ads_stats[$camp_id]['ads_stats'][$camp_ad['id']] = sa_get_ad_statistics($camp_ad['id'], $from, $to);
            }
        }
    } else {
        $camps = sa_get_campaigns();
        if (!empty($camps)) {
            foreach ($camps as $camp) {
                $camp_ads = sa_get_campaign_ads($camp['id']);

                $camp_stat = sa_get_camp_statistics($camp['id'], $from, $to);

                $camps_ads_stats[$camp['id']]['camp_stat'] = $camp_stat;

                if (!empty($camp_ads)) {
                    foreach ($camp_ads as $camp_ad) {
                        $camps_ads_stats[$camp['id']]['ads_stats'][$camp_ad['id']] = sa_get_ad_statistics($camp_ad['id'], $from, $to);
                    }
                }
            }
        }
    }

    return $camps_ads_stats;
}
