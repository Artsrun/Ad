<?php
defined('ABSPATH') or die('No script kiddies please!');
function sa_pop_before_page_template_load($cache = null, $sa_page_info = null) {

    if(empty($sa_page_info)){
        $sa_page_info['sa_is_page'] = is_page();
        $sa_page_info['sa_is_single'] = is_single();
        $sa_page_info['sa_is_archive'] = is_archive();
        $get_queried_object = get_queried_object();
        if(!empty($get_queried_object))
            $sa_page_info['sa_get_queried_object'] = get_object_vars($get_queried_object);
        else
            $sa_page_info['sa_get_queried_object'] = array();
        $sa_page_info['sa_get_the_ID'] = get_the_ID();
        $sa_page_info['sa_get_taxonomies'] = get_taxonomies();
    }

    // Get active campaign
    $campaign = sa_get_active_campaign("popup");

    if (empty($campaign)) {
        return;
    }

    // Get campaign ads    
    $get_campaign_ads = sa_get_campaign_ads($campaign['id'], "priority");
    
    $campaign_ads = array();
    $ads_by_priority = array();
    
    if (!empty($get_campaign_ads)) {
        foreach ($get_campaign_ads as $ad_data) {
            $campaign_ads[$ad_data['id']] = $ad_data;
            $ads_by_priority[$ad_data['priority']] = $ad_data;
        }
    }

    $ad_ids = array_keys($campaign_ads);

    // Check whether campaign exists
    if (empty($campaign) || empty($campaign_ads)) {
        return;
    }

    // Get campaign options
    $get_camp_options = sa_get_campaign_options($campaign['id']);
    $camp_options = array();

    if (!empty($get_camp_options)) {
        foreach ($get_camp_options as $camp_option) {
            $camp_options[$camp_option['option_name']] = $camp_option['option_value'];
        }
    }

    // Get campaign ads options
    $get_ads_options = sa_get_all_ad_options($ad_ids);
    $ads_options = array();

    if (!empty($get_ads_options)) {
        foreach ($get_ads_options as $ad_option) {
            $ads_options[$ad_option['ad_id']][$ad_option['option_name']] = $ad_option['option_value'];
        }
    }

    // Get campaign ads statistics 
    $get_ads_stat = sa_get_ad_stat_counts($ad_ids);
    $ads_stat = array();
    if (!empty($get_ads_stat)) {
        foreach ($get_ads_stat as $get_ad_stat) {
            $ads_stat[$get_ad_stat['ad_id']][$get_ad_stat['type']] = $get_ad_stat['total_count'];
        }
    }

    /** Check some options which must have a value */
    if (empty($camp_options['change_interval'])) {
        $camp_options['change_interval'] = -1;
    }

    if (empty($camp_options['view_interval'])) {
        $camp_options['view_interval'] = -1;
    }

    if (empty($camp_options['width'])) {
        $camp_options['width'] = "600px";
    }

    if (empty($camp_options['height'])) {
        $camp_options['height'] = "500px";
    }

    if (empty($camp_options['view_after'])) {
        $camp_options['view_after'] = "0";
    }

    if (empty($camp_options['show_close_after'])) {
        $camp_options['show_close_after'] = "0";
    }

    if (empty($camp_options['hide_ad_after'])) {
        $camp_options['hide_ad_after'] = "-1";
    }

    if (empty($camp_options['frame_color'])) {
        $camp_options['frame_color'] = "#ffffff";
    }

    if (empty($camp_options['link_color'])) {
        $camp_options['link_color'] = "#ffffff";
    }
    
    if (empty($camp_options['link_type'])) {
        $camp_options['link_type'] = "_blank";
    }

    if (isset($camp_options['auto_play_video']) && $camp_options['auto_play_video'] == "on") {
        $camp_options['auto_play_video'] = 1;
    } else {
        $camp_options['auto_play_video'] = 0;
    }

    /**
     * Check specifing campaign
     */
    $camp_include_tags = isset($camp_options["camp_include_tags"]) ? $camp_options["camp_include_tags"] : "";
    $camp_exclude_tags = isset($camp_options["camp_exclude_tags"]) ? $camp_options["camp_exclude_tags"] : "";

    $specify_ids['include']['category'] = array();
    $specify_ids['include']['post_tag'] = array();
    $specify_ids['include']['post'] = array();
    $specify_ids['include']['page'] = array();
    $specify_ids['exclude']['category'] = array();
    $specify_ids['exclude']['post_tag'] = array();
    $specify_ids['exclude']['post'] = array();
    $specify_ids['exclude']['page'] = array();

    if (!empty($camp_include_tags) || !empty($camp_exclude_tags)) {

        if (!empty($camp_include_tags)) {
            $camp_include_tags = explode("%smartad%,", $camp_include_tags);

            $tags_count = count($camp_include_tags);

            $exp_include_tags = explode("%smartad%", $camp_include_tags[$tags_count - 1]);
            $camp_include_tags[$tags_count - 1] = $exp_include_tags[0];

            foreach ($camp_include_tags as $key => $camp_include_tag) {
                $camp_include_tag = explode("%", $camp_include_tag);
                $camp_include_tags[$key] = $camp_include_tag;
            }

            foreach ($camp_include_tags as $key => $camp_include_tag) {
                if ($camp_include_tag[0] == "category") {
                    array_push($specify_ids['include']['category'], $camp_include_tag[1]);
                } elseif ($camp_include_tag[0] == "post_tag") {
                    array_push($specify_ids['include']['post_tag'], $camp_include_tag[1]);
                } elseif ($camp_include_tag[0] == "post") {
                    array_push($specify_ids['include']['post'], $camp_include_tag[1]);
                } elseif ($camp_include_tag[0] == "page") {
                    array_push($specify_ids['include']['page'], $camp_include_tag[1]);
                }
            }
        }

        if (!empty($camp_exclude_tags)) {
            $camp_exclude_tags = explode("%smartad%,", $camp_exclude_tags);

            $tags_count = count($camp_exclude_tags);

            $exp_exclude_tags = explode("%smartad%", $camp_exclude_tags[$tags_count - 1]);
            $camp_exclude_tags[$tags_count - 1] = $exp_exclude_tags[0];

            foreach ($camp_exclude_tags as $key => $camp_exclude_tag) {

                $camp_exclude_tag = explode("%", $camp_exclude_tag);

                $camp_exclude_tags[$key] = $camp_exclude_tag;
            }

            foreach ($camp_exclude_tags as $key => $camp_exclude_tag) {
                if ($camp_exclude_tag[0] == "category") {
                    array_push($specify_ids['exclude']['category'], $camp_exclude_tag[1]);
                } elseif ($camp_exclude_tag[0] == "post_tag") {
                    array_push($specify_ids['exclude']['post_tag'], $camp_exclude_tag[1]);
                } elseif ($camp_exclude_tag[0] == "post") {
                    array_push($specify_ids['exclude']['post'], $camp_exclude_tag[1]);
                } elseif ($camp_exclude_tag[0] == "page") {
                    array_push($specify_ids['exclude']['page'], $camp_exclude_tag[1]);
                }
            }
        }

        $camp_allow = TRUE;
        
        /** Check if current page included or excloded */
        if ($sa_page_info['sa_is_archive']) {
            $term = $sa_page_info['sa_get_queried_object'];
            
            if (!empty($term)) {
                $term_id = $term['term_id'];

                if (in_array($term_id, $specify_ids['include']['category']) || in_array($term_id, $specify_ids['include']['post_tag'])) {
                    $camp_allow = TRUE;
                } elseif (!empty($camp_include_tags)) {
                    $camp_allow = FALSE;
                }

                if (in_array($term_id, $specify_ids['exclude']['category']) || in_array($term_id, $specify_ids['exclude']['post_tag'])) {
                    $camp_allow = FALSE;
                }
            } elseif (!empty($camp_include_tags)) {
                $camp_allow = FALSE;
            }
        } elseif ($sa_page_info['sa_is_page'] || $sa_page_info['sa_is_single']) {
            
            $post_terms_ids = array();
            $post_tag_ids = array();
            $post_id = $sa_page_info['sa_get_the_ID'];
            
            $all_taxonomies = $sa_page_info['sa_get_taxonomies'];
            unset($all_taxonomies["link_taxonomy"]);
            unset($all_taxonomies["post_format"]);
            unset($all_taxonomies["post_tag"]);

            $post_terms = wp_get_post_terms($sa_page_info['sa_get_the_ID'], $all_taxonomies, array('fields' => 'ids'));
            if (!empty($post_terms)) {
                $post_terms_ids = array_merge($post_terms_ids, $post_terms);
            }

            $post_tags = wp_get_post_terms($sa_page_info['sa_get_the_ID'], "post_tag", array('fields' => 'ids'));
            if (!empty($post_tags)) {
                $post_tag_ids = array_merge($post_tag_ids, $post_tags);
            }

            
            $inter_terms = array_intersect($specify_ids['include']['category'], $post_terms_ids);
            $inter_tags = array_intersect($specify_ids['include']['post_tag'], $post_tag_ids);
            if (in_array($post_id, $specify_ids['include']['post']) || in_array($post_id, $specify_ids['include']['page']) || !empty($inter_terms) || !empty($inter_tags)) {
                $camp_allow = TRUE;
            } elseif (!empty($camp_include_tags)) {
                $camp_allow = FALSE;
            }

            $inter_terms = array_intersect($specify_ids['exclude']['category'], $post_terms_ids);
            $inter_tags = array_intersect($specify_ids['exclude']['post_tag'], $post_tag_ids);
            if (in_array($post_id, $specify_ids['exclude']['post']) || in_array($post_id, $specify_ids['exclude']['page']) || !empty($inter_terms) || !empty($inter_tags)) {
                $camp_allow = FALSE;
            }
        } else {
            if (!empty($camp_include_tags)) {
                $camp_allow = FALSE;
            }
        }
    } else {
        $camp_allow = TRUE;
    }

    if ($camp_allow == FALSE) {
        return;
    }

    /** Separate enabled ads */
    foreach ($campaign_ads as $ad_id => $campaign_ad) {

        /** Check whether ad not expired or disabled */
        if (!empty($ads_options[$ad_id]["deadline"])) {
            $ads_options[$ad_id]["deadline"] = strtotime($ads_options[$ad_id]["deadline"]);
        }

        /**
         * Check specifing ad
         */
        $ad_include_tags = isset($ads_options[$ad_id]["ad_include_tags"]) ? $ads_options[$ad_id]["ad_include_tags"] : "";
        $ad_exclude_tags = isset($ads_options[$ad_id]["ad_exclude_tags"]) ? $ads_options[$ad_id]["ad_exclude_tags"] : "";

        $specify_ids['include']['category'] = array();
        $specify_ids['include']['post_tag'] = array();
        $specify_ids['include']['post'] = array();
        $specify_ids['include']['page'] = array();
        $specify_ids['exclude']['category'] = array();
        $specify_ids['exclude']['post_tag'] = array();
        $specify_ids['exclude']['post'] = array();
        $specify_ids['exclude']['page'] = array();

        if (!empty($ad_include_tags) || !empty($ad_exclude_tags)) {

            if (!empty($ad_include_tags)) {
                $ad_include_tags = explode("%smartad%,", $ad_include_tags);

                $tags_count = count($ad_include_tags);

                $exp_include_tags = explode("%smartad%", $ad_include_tags[$tags_count - 1]);
                $ad_include_tags[$tags_count - 1] = $exp_include_tags[0];

                foreach ($ad_include_tags as $key => $ad_include_tag) {
                    $ad_include_tag = explode("%", $ad_include_tag);
                    $ad_include_tags[$key] = $ad_include_tag;
                }

                foreach ($ad_include_tags as $key => $ad_include_tag) {
                    if ($ad_include_tag[0] == "category") {
                        array_push($specify_ids['include']['category'], $ad_include_tag[1]);
                    } elseif ($ad_include_tag[0] == "post_tag") {
                        array_push($specify_ids['include']['post_tag'], $ad_include_tag[1]);
                    } elseif ($ad_include_tag[0] == "post") {
                        array_push($specify_ids['include']['post'], $ad_include_tag[1]);
                    } elseif ($ad_include_tag[0] == "page") {
                        array_push($specify_ids['include']['page'], $ad_include_tag[1]);
                    }
                }
            }

            if (!empty($ad_exclude_tags)) {
                $ad_exclude_tags = explode("%smartad%,", $ad_exclude_tags);

                $tags_count = count($ad_exclude_tags);

                $exp_exclude_tags = explode("%smartad%", $ad_exclude_tags[$tags_count - 1]);
                $ad_exclude_tags[$tags_count - 1] = $exp_exclude_tags[0];

                foreach ($ad_exclude_tags as $key => $ad_exclude_tag) {

                    $ad_exclude_tag = explode("%", $ad_exclude_tag);

                    $ad_exclude_tags[$key] = $ad_exclude_tag;
                }

                foreach ($ad_exclude_tags as $key => $ad_exclude_tag) {
                    if ($ad_exclude_tag[0] == "category") {
                        array_push($specify_ids['exclude']['category'], $ad_exclude_tag[1]);
                    } elseif ($ad_exclude_tag[0] == "post_tag") {
                        array_push($specify_ids['exclude']['post_tag'], $ad_exclude_tag[1]);
                    } elseif ($ad_exclude_tag[0] == "post") {
                        array_push($specify_ids['exclude']['post'], $ad_exclude_tag[1]);
                    } elseif ($ad_exclude_tag[0] == "page") {
                        array_push($specify_ids['exclude']['page'], $ad_exclude_tag[1]);
                    }
                }
            }

            $ad_allow = TRUE;

            /** Check if current page included or excloded */
            if ($sa_page_info['sa_is_archive']) {
                $term = $sa_page_info['sa_get_queried_object'];

                if (!empty($term)) {
                    $term_id = $term['term_id'];

                    if (in_array($term_id, $specify_ids['include']['category']) || in_array($term_id, $specify_ids['include']['post_tag'])) {
                        $ad_allow = TRUE;
                    } elseif (!empty($ad_include_tags)) {
                        $ad_allow = FALSE;
                    }

                    if (in_array($term_id, $specify_ids['exclude']['category']) || in_array($term_id, $specify_ids['exclude']['post_tag'])) {
                        $ad_allow = FALSE;
                    }
                } elseif (!empty($ad_include_tags)) {
                    $ad_allow = FALSE;
                }
            } elseif ($sa_page_info['sa_is_page'] || $sa_page_info['sa_is_single']) {

                $post_terms_ids = array();
                $post_tag_ids = array();
                $post_id = $sa_page_info['sa_get_the_ID'];

                $all_taxonomies = $sa_page_info['sa_get_taxonomies'];
                unset($all_taxonomies["link_taxonomy"]);
                unset($all_taxonomies["post_format"]);
                unset($all_taxonomies["post_tag"]);

                $post_terms = wp_get_post_terms($sa_page_info['sa_get_the_ID'], $all_taxonomies, array('fields' => 'ids'));

                if (!empty($post_terms)) {
                    $post_terms_ids = array_merge($post_terms_ids, $post_terms);
                }

                $post_tags = wp_get_post_terms($sa_page_info['sa_get_the_ID'], "post_tag", array('fields' => 'ids'));
                if (!empty($post_tags)) {
                    $post_tag_ids = array_merge($post_tag_ids, $post_tags);
                }


                $inter_terms = array_intersect($specify_ids['include']['category'], $post_terms_ids);
                $inter_tags = array_intersect($specify_ids['include']['post_tag'], $post_tag_ids);
                if (in_array($post_id, $specify_ids['include']['post']) || in_array($post_id, $specify_ids['include']['page']) || !empty($inter_terms) || !empty($inter_tags)) {
                    $ad_allow = TRUE;
                } elseif (!empty($ad_include_tags)) {
                    $ad_allow = FALSE;
                }

                $inter_terms = array_intersect($specify_ids['exclude']['category'], $post_terms_ids);
                $inter_tags = array_intersect($specify_ids['exclude']['post_tag'], $post_tag_ids);
                if (in_array($post_id, $specify_ids['exclude']['post']) || in_array($post_id, $specify_ids['exclude']['page']) || !empty($inter_terms) || !empty($inter_tags)) {
                    $ad_allow = FALSE;
                }
            } else {
                if (!empty($ad_include_tags)) {
                    $ad_allow = FALSE;
                }
            }
        } else {
            $ad_allow = TRUE;
        }

        // Get restrict parameters
        $ad_restrict_views = isset($ads_options[$ad_id]["restrict_views"]) ? $ads_options[$ad_id]["restrict_views"] : "";
        $ad_restrict_visits = isset($ads_options[$ad_id]["restrict_visits"]) ? $ads_options[$ad_id]["restrict_visits"] : "";
        $ad_content = isset($ads_options[$ad_id]["ad_content"]) ? $ads_options[$ad_id]["ad_content"] : "";
        $ad_deadline = isset($ads_options[$ad_id]["deadline"]) ? $ads_options[$ad_id]["deadline"] : "";
        $ad_views = isset($ads_stat[$ad_id]["view"]) ? $ads_stat[$ad_id]["view"] : 0;
        $ad_visits = isset($ads_stat[$ad_id]["visit"]) ? $ads_stat[$ad_id]["visit"] : 0;

        // get curent date
        $current_date = date('Y-m-d', current_time('timestamp'));

        if ($ad_allow == FALSE || empty($ad_content) || $campaign_ad["status"] == "suspended" || (!empty($ad_deadline) && strtotime($current_date) > $ad_deadline) || (!empty($ad_restrict_views) && $ad_views >= $ad_restrict_views) || (!empty($ad_restrict_visits) && $ad_visits >= $ad_restrict_visits)) {
            unset($campaign_ads[$ad_id]);
        }
    }

    // Check whether campaign has enable ads
    if (empty($campaign_ads)) {
        return;
    }

    // Get cookie for this campaign ads
    $sa_popup_info = isset($_COOKIE['sa_popup_info']) ? $_COOKIE['sa_popup_info'] : '';
    $sa_popup_info = json_decode(stripslashes($sa_popup_info), TRUE);

    // Check if cookie is set for this campaign ads
    if (!empty($sa_popup_info) && $sa_popup_info["campaign_id"] == $campaign['id']) {

        $lasts_priority = $sa_popup_info["last"];
        $last_id = isset($sa_popup_info["last_id"]) ? $sa_popup_info["last_id"] : FALSE;

        $last_ad = isset($campaign_ads[$last_id]) ? $campaign_ads[$last_id] : FALSE;

        if (isset($_COOKIE['sa_pop_view_interval']) && $camp_options['view_interval'] !== -1 && !empty($last_ad) && in_array($last_ad, $campaign_ads)) {
            $pop_ad = FALSE;
        } else if (isset($_COOKIE['sa_pop_change_interval']) && $camp_options['change_interval'] !== -1 && !empty($last_ad) && in_array($last_ad, $campaign_ads)) {
            $pop_ad = $last_ad;

            $camp_options['change_interval'] = "during";
        } else {
            $ads_arr_vals = array_values($campaign_ads);

            $first_priority = $ads_arr_vals[0]["priority"];
            $last_priority = $ads_arr_vals[count($campaign_ads) - 1]["priority"];

            $ad_choosen = FALSE;
            while (empty($ad_choosen)) {
                $lasts_priority++;
                if ($lasts_priority > $last_priority) {
                    $lasts_priority = $first_priority;
                }

                $pop_ad = $ads_by_priority[$lasts_priority];
                if (!empty($pop_ad) && in_array($pop_ad, $campaign_ads)) {
                    $ad_choosen = TRUE;
                }
            }
        }
    } else {
        // Get first ad(enable) by priority and display
        $ads_arr_vals = array_values($campaign_ads);

        $pop_ad = $ads_arr_vals[0];
    }

    // Check if ad exists
    if (empty($pop_ad)) {
        return;
    }

    /** Determine popup content type and make html content for display into popup */
    $pop_ad_html = "";

    if ($pop_ad["type"] == "image") {
        if (!empty($ads_options[$pop_ad['id']]["link_to"])) {
            $pop_ad_html = '<div data-sa-link-target="'.$camp_options["link_type"].'" data-sa-link="' . $ads_options[$pop_ad['id']]["link_to"] . '" data-sa-ad-id="' . $pop_ad["id"] . '" class="sa-ad-link sa-popup-image" style="background-size: ' . $camp_options['background_type'] . '; background-image: url(' . $ads_options[$pop_ad['id']]["ad_content"] . ')"></div>';
        } else {
            $pop_ad_html = '<div style="background-size: ' . $camp_options['background_type'] . '; background-image: url(' . $ads_options[$pop_ad['id']]["ad_content"] . ')" class="sa-popup-image"></div>';
        }
    } elseif ($pop_ad["type"] == "video") {
        $url_data = json_decode($ads_options[$pop_ad['id']]["ad_content"]);
        $parsed_url = $url_data->parsed;

        /** Convert youtube or vimeo url to embed */
        if ($parsed_url->provider == "youtube") {

            $start_time = (isset($parsed_url->params->start) ? '&start=' . $parsed_url->params->start : "");
            $pop_ad_html = '<iframe class="sa-popup-iframe" width="100%" height="100%" src="https://www.youtube.com/embed/' . $parsed_url->id . '?rel=0&autoplay=' . $camp_options['auto_play_video'] . $start_time . '" frameborder="0" allowfullscreen></iframe>';
        } else if ($parsed_url->provider == "vimeo") {

            $start_time = (isset($parsed_url->params->start) ? '#t=' . $parsed_url->params->start . 's' : "");
            $pop_ad_html = '<iframe class="sa-popup-iframe" src="http://player.vimeo.com/video/' . $parsed_url->id . '?autoplay=' . $camp_options['auto_play_video'] . $start_time . '" width="100%" height="100%" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>';
        }
    } elseif ($pop_ad["type"] == "flash") {
        $pop_ad_html = '<embed src="' . $ads_options[$pop_ad['id']]["ad_content"] . '" width="100%" height="100%">';
    } elseif ($pop_ad["type"] == "html") {
        $pop_ad_html = $ads_options[$pop_ad['id']]["ad_content"];
        $pop_ad_html = apply_filters('the_content', $pop_ad_html);
    } elseif ($pop_ad["type"] == "iframe") {
        $pop_ad_html = '<iframe class="sa-popup-iframe" src="' . $ads_options[$pop_ad['id']]["ad_content"] . '" height="100%" width="100%" sandbox></iframe>';
    }

    /** Set options array for js */
    $pop_options["pop_change_interval"] = $camp_options['change_interval'];
    $pop_options["pop_view_interval"] = $camp_options['view_interval'];
    $pop_options["pop_gray_background"] = $camp_options['gray_background'];
    $pop_options["pop_popup_direction"] = $camp_options['popup_direction'];
    $pop_options["pop_view_after"] = $camp_options['view_after'];
    $pop_options["pop_show_close_after"] = $camp_options['show_close_after'];
    $pop_options["pop_hide_ad_after"] = $camp_options['hide_ad_after'];
    $pop_options["pop_background_type"] = $camp_options['background_type'];
    $pop_options["pop_put_in_frame"] = $camp_options['put_in_frame'];
    $pop_options["pop_frame_color"] = $camp_options['frame_color'];
    $pop_options["pop_show_link"] = $camp_options['show_link'];
    $pop_options["pop_link_color"] = $camp_options['link_color'];
    $pop_options["pop_auto_play_video"] = $camp_options['auto_play_video'];
    $pop_options["pop_link_type"] = $camp_options['link_type'];
    $pop_options["pop_link_to"] = $ads_options[$pop_ad['id']]["link_to"];
    $pop_options["pop_ad_content"] = $ads_options[$pop_ad['id']]["ad_content"];
    $pop_options["pop_ad_html"] = $pop_ad_html;
    $pop_options["pop_ad_type"] = $pop_ad["type"];
    $pop_options["pop_width"] = $camp_options['width'];
    $pop_options["pop_height"] = $camp_options['height'];
    $pop_options["pop_ad_id"] = $pop_ad["id"];

    $sa_popup_info["campaign_id"] = $pop_ad["campaign_id"];
    $sa_popup_info["last"] = $pop_ad["priority"];
    $sa_popup_info["last_id"] = $pop_ad["id"];
    
    if($cache == 'true'){
        $res['pop_options'] = $pop_options;
        $res['sa_popup_info'] = $sa_popup_info;
        return $res;
    }
    
    ?>
    <script>
        pop_options = <?php echo json_encode($pop_options); ?>;
        sa_popup_info = <?php echo json_encode($sa_popup_info); ?>;
    </script>
    <?php
}

//$cache = get_option('sa_cache_enabled');
$sa_extra_options = get_option('sa_extra_options');
$cache = $sa_extra_options['sa_cache_enabled'];

/*
 * when anti-cache enabled ajax handler for get popup campain options
 */
if($cache == 'true'){
    add_action('wp_ajax_sa_call_pop_before_page_template_load', 'sa_call_pop_before_page_template_load');
    add_action('wp_ajax_nopriv_sa_call_pop_before_page_template_load', 'sa_call_pop_before_page_template_load');
}
else
    add_action('wp_enqueue_scripts', 'sa_pop_before_page_template_load');

function sa_call_pop_before_page_template_load(){
    global $cache;
    $sa_page_info = $_POST['sa_page_info'];

    $response = sa_pop_before_page_template_load($cache, $sa_page_info);
    echo json_encode($response);
    die();
}