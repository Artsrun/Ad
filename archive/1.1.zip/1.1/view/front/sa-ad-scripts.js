/**
 * Set coockie function
 * 
 * @param str cname
 * @param str cvalue
 * @param int exseconds
 * @returns {undefined}
 */
function saSetCookie(cname, cvalue, exseconds) {
    var d = new Date();
    d.setTime(d.getTime() + (exseconds * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires + "; path=/";
}

/**
 * Get coockie function
 * 
 * @param str cname
 * @returns {String}
 */
function saGetCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ')
            c = c.substring(1);
        if (c.indexOf(name) == 0)
            return c.substring(name.length, c.length);
    }
    return "";
}

/**
 * Detect IE version
 * 
 * @returns {Boolean}
 */
function saIeVersion() {
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");
    if (msie > 0)  // If Internet Explorer, return version number
    {
        return parseInt(ua.substring(msie + 5, ua.indexOf(".", msie)));
    } else if (!!navigator.userAgent.match(/Trident.*rv\:11\./)) {
        return 11;
    }

    return false;
}

function canRunAds(){
    
    jQuery('body').append('<div class="afs_ads ad-top ad-banner google-sponsored google-ad sa-can-run-ads" style="position:fixed !important; top:-9999px !important;left:-9999px !important;visibility:hidden !important;width:1px !important;height:1px !important;"></div>');
    var canRunAds = !(jQuery('.sa-can-run-ads').css('display') == 'none');
    jQuery('.sa-can-run-ads').remove();
    return canRunAds;    
}

/** Document ready actions */
jQuery(document).ready(function ($) {

    var ie_version = saIeVersion();

    /*
     * when add-blocker active show warning message 
     */

    function saShowWarning(warText,warEnabled) {

        if (canRunAds() == false && warEnabled == 'true' && saGetCookie('sa-warning-text') != 'no') {
            $('.sa-warning-message').remove();
            if( warText == '' ){
                warText = sa_warning_default;
            }
            var warningDiv = '<div class="sa-warning-message"><div class="sa-warning-content">' + warText + '</div><div class="sa-war-close"><span class="sa-warning-close"></span></div></div>';
            $('body').append(warningDiv);
        }
        //close warning message
        $('.sa-warning-close').on('click', function () {
            $('.sa-warning-message').remove();
            saSetCookie('sa-warning-text', 'no');
            $(window).trigger('resize');
        });
    }

    /*
     *  when anti-cache enabled add custom css
     */
    function saAddCustomCss(customCss) {
        $('body').append('<style id="sa-ad-styles-inline-css" type="text/css">' + customCss + '</style>');
    }

    /*
     * when anti-cache enabled send ajax request for get background and popup options
     */
    if (sa_extra_options.sa_cache_enabled == 'true') {

        /*
         * ajax for get background options
         */
        $.ajax({
            type: "POST",
            url: ajax_url,
            dataType: "json",
            data: {
                action: "sa_call_bg_before_page_template_load",
                type: "view",
                sa_page_info: sa_page_info
            },
            success: function (res) {
                if (res) {
                    var bg_options = res.bg_options;
                    var sa_bg_info = res.sa_bg_info;
                    setBG(bg_options, sa_bg_info);
                }
            },
        });

        /*
         * ajax for get popup options 
         */
        var ajax_pop_options;
        var ajax_sa_popup_info;
        var canShowPopup = false;
        var warningTextReady = false;
        $.ajax({
            type: "POST",
            url: ajax_url,
            dataType: "json",
            data: {
                action: "sa_call_pop_before_page_template_load",
                type: "view",
                sa_page_info: sa_page_info
            },
            success: function (res) {
                if (res) {
                    ajax_pop_options = res.pop_options;
                    ajax_sa_popup_info = res.sa_popup_info;
                    canShowPopup = true;
                    if (warningTextReady) {
                        setPOP(ajax_pop_options, ajax_sa_popup_info);
                        canShowPopup = false;
                    }
                }
            },
        });

        /*
         * ajax for get extra options
         */
        $.ajax({
            type: "POST",
            url: ajax_url,
            dataType: "json",
            data: {
                action: "sa_get_extra_options",
                type: "view",
            },
            success: function (res) {
                if (res) {
                    // add custom css
                    var custom_css = res.sa_custom_css;
                    saAddCustomCss(custom_css);
                    // add warning message
                    saShowWarning(res.sa_warning_text,res.sa_warning_text_enabled);
                    warningTextReady = true;
                    if (canShowPopup) {
                        setPOP(ajax_pop_options, ajax_sa_popup_info);
                        warningTextReady = false;
                    }
                }
            },
        });

        /*
         * ajax for get embed campain content
         */
        $(".sa-embed-cont").each(function () {
            var saEmbedCont = $(this);
            var parentSection = saEmbedCont.parent('section');
            var saWidgetId = 0;
            if (parentSection.hasClass('widget_sa_campaign')) {
                saWidgetId = parentSection.attr('id').replace(/\D/g, '');
            }
            var info_array = saEmbedCont.find('.sa-embed-info').serializeArray();
            if (info_array.length)
                var campaign_id = info_array[0]["value"];
            else
                var campaign_id = saEmbedCont.attr('id');
            $.ajax({
                type: "POST",
                url: ajax_url,
                dataType: "json",
                data: {
                    action: "sa_call_embed_campaign_func",
                    type: "view",
                    sa_page_info: sa_page_info,
                    shortcode_id: campaign_id,
                    sa_widget_id: saWidgetId
                },
                success: function (res) {
                    if (res) {
                        saEmbedCont.replaceWith(res[campaign_id])
                        saSetEmbedCookie();
                    }
                },
            });

        });

    } else {
        saShowWarning(sa_extra_options.sa_warning_text,sa_extra_options.sa_warning_text_enabled);
        if (typeof bg_options !== "undefined" && sa_bg_info !== undefined && sa_bg_info !== "")
            setBG(bg_options, sa_bg_info);
        if (typeof pop_options !== "undefined" && sa_popup_info !== undefined && sa_popup_info !== "")
            setPOP(pop_options, sa_popup_info);
        saSetEmbedCookie();
    }

    /*
     * Background ad scripts 
     */
    function setBG(option, info) {
        var bg_options = option;
        var sa_bg_info = info;
        if (typeof bg_options !== "undefined") {
            // Update ad statistics
            $.ajax({
                type: "POST",
                url: ajax_url,
                data: {
                    action: "sa_ajax_update_ad_statistics",
                    ad_id: bg_options["bg_ad_id"],
                    type: "view",
                }
            });

            if (typeof bg_options["bg_selector"] == "string" && bg_options["bg_selector"] !== "") {
                $(bg_options["bg_selector"]).css("background-image", "url(" + bg_options["bg_ad_content"] + ")");

                if (bg_options["bg_background_type"] == "cover_bg") {
                    $(bg_options["bg_selector"]).addClass("sa-bg-cover-ad");
                } else if (bg_options["bg_background_type"] == "repeat_bg") {
                    $(bg_options["bg_selector"]).addClass("sa-bg-repeat-ad");
                }

                if (typeof bg_options["bg_link_to"] == "string" && bg_options["bg_link_to"] !== "") {

                    $(bg_options["bg_selector"]).addClass("sa-ad-link");
                    $(bg_options["bg_selector"]).attr("data-sa-ad-id", bg_options["bg_ad_id"]);
                    $(bg_options["bg_selector"]).attr("data-sa-link", bg_options["bg_link_to"]);
                    $(bg_options["bg_selector"]).attr("data-sa-link-target", bg_options["bg_link_type"]);
                }
            }

            /** Set campaign info coockie */
            if (sa_bg_info !== undefined && sa_bg_info !== "") {
                var sa_bg_info_str = JSON.stringify(sa_bg_info);
                saSetCookie("sa_bg_info", sa_bg_info_str, 30 * 86400);
            }

            if (bg_options["bg_change_interval"] != "during") {
                saSetCookie("sa_bg_change_interval", bg_options["bg_change_intervall"], parseInt(bg_options["bg_change_interval"]));
            }
        }
    }


    /*
     * Popup ad scripts
     */
    function setPOP(option, info) {

        //  when set popup window scroll hidden
        $('html, body').addClass("sa-hide-scroll");

        var pop_options = option;
        var sa_popup_info = info;
        if (typeof pop_options !== "undefined") {
            if (pop_options["pop_ad_type"] == "image") {
                $("body").prepend('<img id="sa-pop-hidden-img" src="' + pop_options["pop_ad_content"] + '" />');
            }

            /** Set campaign info coockie */
            if (sa_popup_info !== undefined && sa_popup_info !== "") {
                var sa_popup_info_str = JSON.stringify(sa_popup_info);
                saSetCookie("sa_popup_info", sa_popup_info_str, 30 * 86400);
            }

            /** Append overlay popup */
            $("body").append('<div id="sa-popup-overlay"' + ((pop_options["pop_gray_background"] == "on") ? ' class="sa-pop-dark-overlay sa-suspense-hidden"' : "") + '></div>');

            /** Append popup block */
            var popup_class = "sa-pop-" + pop_options['pop_popup_direction'];

            $("body").append('<div id="sa-popup-cont" style="width: ' + pop_options['pop_width'] + '; height: ' + pop_options['pop_height'] + '" class="' + popup_class + ' sa-suspense-hidden sa_reset_style"><div id="sa-popup-header">\n\
                               <span class="sa-close-popup sa-pop-hidden-close" style="color: ' + pop_options["pop_link_color"] + '"></span>\n\
                               <div id="sa-hide-text" class="sa-hide-text-hidden"><span class="sa-hide-settlement" style="color: ' + pop_options["pop_link_color"] + ';">' + ((pop_options["pop_hide_ad_after"] !== "-1") ? pop_options["pop_hide_ad_after"] : "") + '</span></div>\n\
                               <div id="sa-close-text"><span class="sa-close-settlement"' + ' style="color: ' + pop_options["pop_link_color"] + ';"' + '>' + ((pop_options["pop_show_close_after"] !== "0") ? pop_options["pop_show_close_after"] : "") + '</span></div>\n\
                               </div><div id="sa-popup-ad"' + ((pop_options["pop_put_in_frame"] == "on") ? ' style="background-color: ' + pop_options["pop_frame_color"] + '; border: solid 6px ' + pop_options["pop_frame_color"] + '"' : "") + '></div></div>');

            /** Determine and set ad content position */
            saSetPopupCorrection(pop_options, true);
            var pop_width = $("#sa-popup-cont").width();
            var pop_height = $("#sa-popup-cont").height();
            var warningDivHeight = $('.sa-warning-message').height() != undefined ? $('.sa-warning-message').height() : 0;

            /** Set content ad */
            $("#sa-popup-ad").append(pop_options["pop_ad_html"]);

            function saShowPopup() {
                setTimeout(function () {

                    $("#sa-popup-cont").removeClass("sa-suspense-hidden");
                    $("#sa-popup-overlay").removeClass("sa-suspense-hidden");

                    $("#sa-popup-cont")[0].offsetHeight;

                    if (pop_options['pop_popup_direction'] == "left" || pop_options['pop_popup_direction'] == "right") {
                        var pos_left = window.innerWidth / 2 - pop_width / 2;

                        if (ie_version && ie_version <= 9) {
                            $("#sa-popup-cont").animate({left: pos_left}, 800);
                        } else {
                            $("#sa-popup-cont").css({"left": pos_left});
                        }
                    } else if (pop_options['pop_popup_direction'] == "top" || pop_options['pop_popup_direction'] == "bottom") {
                        var pos_top = window.innerHeight / 2 - pop_height / 2 + warningDivHeight / 2;
                        if (window.innerWidth < 782)
                            pos_top = warningDivHeight;
                        if (ie_version && ie_version <= 9) {
                            $("#sa-popup-cont").animate({top: pos_top}, 800);
                        } else {
                            $("#sa-popup-cont").css({"top": pos_top});
                        }
                    } else if (pop_options['pop_popup_direction'] == "center") {

                        if (ie_version && ie_version <= 9) {
                            $("#sa-popup-cont").animate({opacity: "1"}, 800);
                        } else {
                            $("#sa-popup-cont").css("opacity", "1");
                        }
                    }

                    // Append link also
                    if (pop_options["pop_link_to"] !== "" && pop_options["pop_show_link"] != "") {
                        $("#sa-popup-header").prepend('<span style="color: ' + pop_options["pop_link_color"] + '" data-sa-ad-id="' + pop_options["pop_ad_id"] + '" data-sa-link="' + pop_options["pop_link_to"] + '" data-sa-link-target="' + pop_options["pop_link_type"] + '" class="sa-pop-link sa-ad-link">' + pop_options["pop_link_to"] + '</span>');
                    }

                    var show_close_after = pop_options['pop_show_close_after'];
                    var hide_ad_after = pop_options['pop_hide_ad_after'];

                    if (show_close_after !== 0) {
                        var close_after = setInterval(function () {
                            if (show_close_after == 1) {
                                clearInterval(close_after);
                                if (hide_ad_after !== "-1") {
                                    $("#sa-hide-text").removeClass("sa-hide-text-hidden");
                                }
                            }

                            show_close_after = show_close_after - 1;
                            $(".sa-close-settlement").text(show_close_after)
                        }, 1000);
                    }

                    if (hide_ad_after !== "-1") {
                        if (show_close_after == 0) {
                            $("#sa-hide-text").removeClass("sa-hide-text-hidden");
                        }
                        var hide_after = setInterval(function () {
                            if (hide_ad_after == 0) {
                                clearInterval(hide_after);
                            }

                            hide_ad_after = hide_ad_after - 1;
                            $(".sa-hide-settlement").text(hide_ad_after)
                        }, 1000);
                    }

                    // set popup content after warning-text
                    var saId;
                    $(window).resize(function () {
                        clearTimeout(saId);
                        saId = setTimeout(function () {
                            saSetPopupCorrection(pop_options);
                        }, 100);
                    });

                    // Display close popup button
                    setTimeout(function () {
                        $("#sa-close-text").remove();
                        $(".sa-close-popup").removeClass("sa-pop-hidden-close");
                    }, pop_options['pop_show_close_after'] * 1000);

                    // Hide ad if set appropriate option
                    if (pop_options["pop_hide_ad_after"] !== '-1') {
                        setTimeout(function () {
                            $("#sa-popup-cont").remove();
                            $("#sa-popup-overlay").remove();
                            //when close popup window scroll is show
                            $('html, body').removeClass("sa-hide-scroll");
                        }, pop_options['pop_hide_ad_after'] * 1000);
                    }

                    // Update ad statistics
                    $.ajax({
                        type: "POST",
                        url: ajax_url,
                        data: {
                            action: "sa_ajax_update_ad_statistics",
                            ad_id: pop_options["pop_ad_id"],
                            type: "view",
                        }
                    });
                }, pop_options['pop_view_after'] * 1000);
            }

            if (pop_options["pop_ad_type"] == "image") {
                $("#sa-pop-hidden-img").on('load', function () {
                    saShowPopup();
                });
            } else {
                saShowPopup();
            }

            saSetCookie("sa_pop_view_interval", pop_options["pop_view_interval"], parseInt(pop_options["pop_view_interval"]));

            if (pop_options["pop_change_interval"] != "during") {
                saSetCookie("sa_pop_change_interval", pop_options["pop_change_interval"], parseInt(pop_options["pop_change_interval"]));
            }
        }
    }



    /** Closes popup ad */
    $(document).on("click", ".sa-close-popup, #sa-popup-overlay", function (e) {

        if (!$(".sa-close-popup").hasClass("sa-pop-hidden-close")) {
            $("#sa-popup-cont").remove();
            $("#sa-popup-overlay").remove();

            //when close popup window scroll is show
            $('html, body').removeClass("sa-hide-scroll");
        }
    });

    /** Close popup with escape key press */
    $(document).on('keyup', function (e) {

        if (!$(".sa-close-popup").hasClass("sa-pop-hidden-close") && e.keyCode === 27) {
            $("#sa-popup-cont").remove();
            $("#sa-popup-overlay").remove();

            //when close popup window scroll is show
            $('html, body').removeClass("sa-hide-scroll");
        }
    });

    /** Determine and set embed campaigns cookie */
    function saSetEmbedCookie() {
        $(".sa-embed-info").each(function () {
            var info_array = $(this).serializeArray();
            var campaign_id = info_array[0]["value"];
            var last = info_array[1]["value"];
            var last_id = info_array[2]["value"];
            var change_interval = info_array[3]["value"];

            var sa_emb_info = {};
            sa_emb_info["campaign_id"] = campaign_id;
            sa_emb_info["last"] = last;
            sa_emb_info["last_id"] = last_id;

            // check if cookcie already set or not
            if (saGetCookie("sa_embeds_info") == "" || saGetCookie("sa_embeds_info") == null || saGetCookie("sa_embeds_info") == "undefined") {
                var sa_embeds_info = {};
            } else {
                sa_embeds_info = JSON.parse(saGetCookie("sa_embeds_info"));
            }

            // Set embed coockie
            sa_embeds_info[campaign_id] = sa_emb_info;
            var sa_embeds_info_str = JSON.stringify(sa_embeds_info);
            saSetCookie("sa_embeds_info", sa_embeds_info_str, 30 * 86400);

            if (change_interval !== "dontset") {
                saSetCookie("sa_emb_change_interval_" + campaign_id, change_interval, parseInt(change_interval));
            }
        });
    }
    /** Ad links redirect */
    $(document).on('click', ".sa-ad-link", function (e) {

        if (e.target == this) {

            var link_to = $(this).attr("data-sa-link");
            var link_type = $(this).attr("data-sa-link-target");

            if (link_type === '_window') {
                link_type = '_blank';
                var location = 'location = yes,scrollbars=yes';
            }
            if (link_to !== "") {
                window.open(link_to, link_type, location);
            } else {
                return;
            }

            /** Request for save visit into Db */
            var ad_id = $(this).attr("data-sa-ad-id");

            $.ajax({
                type: "POST",
                url: ajax_url,
                //dataType: "json",
                data: {
                    action: "sa_ajax_update_ad_statistics",
                    ad_id: ad_id,
                    type: "visit",
                },
                success: function () {
                },
                error: function () {
                }
            });
        }

        e.stopPropagation();
    });

    /**
     * Make cursor pointer for ad links
     */
    $(document).on("mousemove", ".sa-ad-link", (function (e) {
        if ($(e.target).hasClass("sa-ad-link")) {
            $(e.target).addClass("sa-cursor-pointer");
        } else {
            $(".sa-ad-link").removeClass("sa-cursor-pointer");
        }
    }));

    /*
     * set popup correction
     */
    function saSetPopupCorrection(pop_options, onLoad) {
        var warningDivHeight = $('.sa-warning-message').height() != undefined ? $('.sa-warning-message').height() : 0;
        var windowHeight = $(window).height();
        var windowWidth = $(window).width();
        var popHeight;
        // check popup height set % or px
        if(pop_options['pop_height'].slice(- 1) == '%'){
            if ((windowHeight - warningDivHeight) < (windowHeight * parseInt(pop_options['pop_height']) / 100 + 75))
                popHeight = (windowHeight - warningDivHeight - 75);
            else
                popHeight = windowHeight * parseInt(pop_options['pop_height']) / 100;
        }
        else{
            if ((windowHeight - warningDivHeight) < (parseInt(pop_options['pop_height']) + 75))
                popHeight = (windowHeight - warningDivHeight - 75);
            else
                popHeight = pop_options['pop_height'];
        }
        if (onLoad) {
            var pop_width = $("#sa-popup-cont").width();
            var pop_height = parseInt(popHeight);
            var pos_top;
            if (windowWidth >= 782) {
                pos_top = windowHeight / 2 - pop_height / 2 + warningDivHeight / 2;
                $('#sa-popup-cont').css('height', pop_height);
            } else {
                pos_top = warningDivHeight;
                $('#sa-popup-cont').css('height', windowHeight - warningDivHeight);
            }
            $("#sa-popup-cont").addClass('noTransition');
            $("#sa-popup-cont")[0].offsetHeight;
            if (pop_options['pop_popup_direction'] == "left") {
                $("#sa-popup-cont").css("left", -pop_width);
                $("#sa-popup-cont").css("top", pos_top);
                $("#sa-popup-cont").css("bottom", 'initial');
            } else if (pop_options['pop_popup_direction'] == "right") {
                $("#sa-popup-cont").css("left", "100%");
                $("#sa-popup-cont").css("top", pos_top);
                $("#sa-popup-cont").css("bottom", 'initial');
            } else if (pop_options['pop_popup_direction'] == "top") {
                $("#sa-popup-cont").css("top", -pop_height);
            } else if (pop_options['pop_popup_direction'] == "bottom") {
                $("#sa-popup-cont").css("top", "100%");
            } else if (pop_options['pop_popup_direction'] == "center") {
                $("#sa-popup-cont").css("opacity", "0");
                $("#sa-popup-cont").css("top", pos_top);
                $("#sa-popup-cont").css("bottom", 'initial');
            }
            $("#sa-popup-cont").removeClass('noTransition');
        } else {
            if (windowWidth >= 782) {
                $('#sa-popup-cont').css( 'margin-top', 'auto');
                $('#sa-popup-cont').removeClass('mobileView');
                var a = parseInt((windowHeight - warningDivHeight - parseInt(popHeight)) / 2);
                if (pop_options['pop_popup_direction'] == "top" || pop_options['pop_popup_direction'] == "bottom") {
                    $('#sa-popup-cont').css({
                        'top': warningDivHeight + a,
                        'height': popHeight
                    });
                } else if (pop_options['pop_popup_direction'] == "left" || pop_options['pop_popup_direction'] == "right") {
                    $('#sa-popup-cont').css({
                        'top': warningDivHeight + a,
                        'left': (windowWidth - $('#sa-popup-cont').width()) / 2,
                        'height': popHeight
                    });
                } else{
                    $('#sa-popup-cont').css({
                        'top': warningDivHeight + a,
                        'height': popHeight
                    });
                }
            } else {
                $('#sa-popup-cont').css({
                    'height': windowHeight - warningDivHeight,
                    'margin-top':warningDivHeight
                });
                $('#sa-popup-cont').addClass('mobileView');
            }
        }
    }
});