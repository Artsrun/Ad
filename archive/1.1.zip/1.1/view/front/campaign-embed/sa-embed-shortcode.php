<?php
defined('ABSPATH') or die('No script kiddies please!');
/**
 * Create shortcode for displaying smartad embed campaign
 */

/** [smartad id="campaign-id"] */
function sa_embed_campaign_func($atts, $content, $name, $sa_page_info = NULL, $sa_anticache = FALSE) {
    if(empty($sa_page_info)){
        $sa_page_info['sa_is_page'] = is_page();
        $sa_page_info['sa_is_single'] = is_single();
        $sa_page_info['sa_is_archive'] = is_archive();
        $get_queried_object = get_queried_object();
        if(!empty($get_queried_object))
            $sa_page_info['sa_get_queried_object'] = get_object_vars($get_queried_object);
        else
            $sa_page_info['sa_get_queried_object'] = array();
        $sa_page_info['sa_get_the_ID'] = get_the_ID();
        $sa_page_info['sa_get_taxonomies'] = get_taxonomies();
    }
    
    $a = shortcode_atts(array('id' => '0', 'widget' => 0), $atts);

    $campaign_id = intval($a['id']);

    $post_id = $sa_page_info['sa_get_the_ID'];

    $campaign = sa_get_campaigns($campaign_id);

    if (empty($campaign)) {
        return;
    }

	$sa_empty_embed = '<div class="sa-embed-cont sa_reset_style" id="'.$campaign_id.'" style="display:none;"></div>';
	
    $campaign = $campaign[0];

    /** Check if campaign not exists or not have status active */
    if ($campaign["status"] !== "active") {
        return $sa_empty_embed;
    }

    // Get campaign ads    
    $get_campaign_ads = sa_get_campaign_ads($campaign['id'], "priority");
    
    $campaign_ads = array();
    $ads_by_priority = array();
    
    if (!empty($get_campaign_ads)) {
        foreach ($get_campaign_ads as $ad_data) {
            $campaign_ads[$ad_data['id']] = $ad_data;
            $ads_by_priority[$ad_data['priority']] = $ad_data;
        }
    }

    $ad_ids = array_keys($campaign_ads);

    // Check whether campaign exists
    if (empty($campaign) || empty($campaign_ads)) {
        return $sa_empty_embed;
    }

    // Get campaign options
    $get_camp_options = sa_get_campaign_options($campaign['id']);
    $camp_options = array();

    if (!empty($get_camp_options)) {
        foreach ($get_camp_options as $camp_option) {
            $camp_options[$camp_option['option_name']] = $camp_option['option_value'];
        }
    }

    // Get campaign ads options
    $get_ads_options = sa_get_all_ad_options($ad_ids);
    $ads_options = array();

    if (!empty($get_ads_options)) {
        foreach ($get_ads_options as $ad_option) {
            $ads_options[$ad_option['ad_id']][$ad_option['option_name']] = $ad_option['option_value'];
        }
    }

    // Get campaign ads statistics 
    $get_ads_stat = sa_get_ad_stat_counts($ad_ids);
    $ads_stat = array();
    if (!empty($get_ads_stat)) {
        foreach ($get_ads_stat as $get_ad_stat) {
            $ads_stat[$get_ad_stat['ad_id']][$get_ad_stat['type']] = $get_ad_stat['total_count'];
        }
    }

    /** Check some options which must have a value */
    if (empty($camp_options["change_interval"])) {
        $camp_options["change_interval"] = -1;
    }

    if (empty($camp_options["width"])) {
        $camp_options["width"] = "100%";
    }

    if (empty($camp_options["height"])) {
        $camp_options["height"] = "100px";
    }else{
        $camp_options["height"] = $camp_options["height"] . 'px';
    }

    if (isset($camp_options["auto_play_video"]) && $camp_options["auto_play_video"] == "on") {
        $camp_options["auto_play_video"] = 1;
    } else {
        $camp_options["auto_play_video"] = 0;
    }

    if (empty($camp_options["background_type"])) {
        $camp_options["background_type"] = "contain";
    }

    if (empty($camp_options['link_color'])) {
        $camp_options['link_color'] = "#ffffff";
    }
    
    if (empty($camp_options['link_type'])) {
        $camp_options['link_type'] = "_blank";
    }

    /**
     * Check specifing campaign
     */
    $camp_include_tags = isset($camp_options["camp_include_tags"]) ? $camp_options["camp_include_tags"] : "";
    $camp_exclude_tags = isset($camp_options["camp_exclude_tags"]) ? $camp_options["camp_exclude_tags"] : "";

    $specify_ids['include']['category'] = array();
    $specify_ids['include']['post_tag'] = array();
    $specify_ids['include']['post'] = array();
    $specify_ids['include']['page'] = array();
    $specify_ids['exclude']['category'] = array();
    $specify_ids['exclude']['post_tag'] = array();
    $specify_ids['exclude']['post'] = array();
    $specify_ids['exclude']['page'] = array();

    if (!empty($camp_include_tags) || !empty($camp_exclude_tags)) {

        if (!empty($camp_include_tags)) {
            $camp_include_tags = explode("%smartad%,", $camp_include_tags);

            $tags_count = count($camp_include_tags);

            $exp_include_tags = explode("%smartad%", $camp_include_tags[$tags_count - 1]);
            $camp_include_tags[$tags_count - 1] = $exp_include_tags[0];

            foreach ($camp_include_tags as $key => $camp_include_tag) {
                $camp_include_tag = explode("%", $camp_include_tag);
                $camp_include_tags[$key] = $camp_include_tag;
            }

            foreach ($camp_include_tags as $key => $camp_include_tag) {
                if ($camp_include_tag[0] == "category") {
                    array_push($specify_ids['include']['category'], $camp_include_tag[1]);
                } elseif ($camp_include_tag[0] == "post_tag") {
                    array_push($specify_ids['include']['post_tag'], $camp_include_tag[1]);
                } elseif ($camp_include_tag[0] == "post") {
                    array_push($specify_ids['include']['post'], $camp_include_tag[1]);
                } elseif ($camp_include_tag[0] == "page") {
                    array_push($specify_ids['include']['page'], $camp_include_tag[1]);
                }
            }
        }

        if (!empty($camp_exclude_tags)) {
            $camp_exclude_tags = explode("%smartad%,", $camp_exclude_tags);

            $tags_count = count($camp_exclude_tags);
            $exp_exclude_tags = explode("%smartad%", $camp_exclude_tags[$tags_count - 1]);
            $camp_exclude_tags[$tags_count - 1] = $exp_exclude_tags[0];

            foreach ($camp_exclude_tags as $key => $camp_exclude_tag) {

                $camp_exclude_tag = explode("%", $camp_exclude_tag);

                $camp_exclude_tags[$key] = $camp_exclude_tag;
            }

            foreach ($camp_exclude_tags as $key => $camp_exclude_tag) {
                if ($camp_exclude_tag[0] == "category") {
                    array_push($specify_ids['exclude']['category'], $camp_exclude_tag[1]);
                } elseif ($camp_exclude_tag[0] == "post_tag") {
                    array_push($specify_ids['exclude']['post_tag'], $camp_exclude_tag[1]);
                } elseif ($camp_exclude_tag[0] == "post") {
                    array_push($specify_ids['exclude']['post'], $camp_exclude_tag[1]);
                } elseif ($camp_exclude_tag[0] == "page") {
                    array_push($specify_ids['exclude']['page'], $camp_exclude_tag[1]);
                }
            }
        }

        $camp_allow = TRUE;

        /** Check if current page included or excloded */
        if ($sa_page_info['sa_is_archive']) {
            $term = $sa_page_info['sa_get_queried_object'];

            if (!empty($term)) {
                $term_id = $term['term_id'];

                if (in_array($term_id, $specify_ids['include']['category']) || in_array($term_id, $specify_ids['include']['post_tag'])) {
                    $camp_allow = TRUE;
                } elseif (!empty($camp_include_tags)) {
                    $camp_allow = FALSE;
                }

                if (in_array($term_id, $specify_ids['exclude']['category']) || in_array($term_id, $specify_ids['exclude']['post_tag'])) {
                    $camp_allow = FALSE;
                }
            } elseif (!empty($camp_include_tags)) {
                $camp_allow = FALSE;
            }
        } elseif ($sa_page_info['sa_is_page'] || $sa_page_info['sa_is_single']) {

            $post_terms_ids = array();
            $post_tag_ids = array();
            $post_id = $sa_page_info['sa_get_the_ID'];

            $all_taxonomies = $sa_page_info['sa_get_taxonomies'];
            unset($all_taxonomies["link_taxonomy"]);
            unset($all_taxonomies["post_format"]);
            unset($all_taxonomies["post_tag"]);

            $post_terms = wp_get_post_terms($sa_page_info['sa_get_the_ID'], $all_taxonomies, array('fields' => 'ids'));
            if (!empty($post_terms)) {
                $post_terms_ids = array_merge($post_terms_ids, $post_terms);
            }

            $post_tags = wp_get_post_terms($sa_page_info['sa_get_the_ID'], "post_tag", array('fields' => 'ids'));
            if (!empty($post_tags)) {
                $post_tag_ids = array_merge($post_tag_ids, $post_tags);
            }


            $inter_terms = array_intersect($specify_ids['include']['category'], $post_terms_ids);
            $inter_tags = array_intersect($specify_ids['include']['post_tag'], $post_tag_ids);
            if (in_array($post_id, $specify_ids['include']['post']) || in_array($post_id, $specify_ids['include']['page']) || !empty($inter_terms) || !empty($inter_tags)) {
                $camp_allow = TRUE;
            } elseif (!empty($camp_include_tags)) {
                $camp_allow = FALSE;
            }

            $inter_terms = array_intersect($specify_ids['exclude']['category'], $post_terms_ids);
            $inter_tags = array_intersect($specify_ids['exclude']['post_tag'], $post_tag_ids);
            if (in_array($post_id, $specify_ids['exclude']['post']) || in_array($post_id, $specify_ids['exclude']['page']) || !empty($inter_terms) || !empty($inter_tags)) {
                $camp_allow = FALSE;
            }
        } else {
            if (!empty($camp_include_tags)) {
                $camp_allow = FALSE;
            }
        }
    } else {
        $camp_allow = TRUE;
    }

    if ($camp_allow == FALSE) {
        return $sa_empty_embed;
    }

    /** Separate enabled ads */
    foreach ($campaign_ads as $ad_id => $campaign_ad) {

        /** Check whether ad not expired or disabled */
        if (!empty($ads_options[$ad_id]["deadline"])) {
            $ads_options[$ad_id]["deadline"] = strtotime($ads_options[$ad_id]["deadline"]);
        }

        /**
         * Check specifing ad
         */
        $ad_include_tags = isset($ads_options[$ad_id]["ad_include_tags"]) ? $ads_options[$ad_id]["ad_include_tags"] : "";
        $ad_exclude_tags = isset($ads_options[$ad_id]["ad_exclude_tags"]) ? $ads_options[$ad_id]["ad_exclude_tags"] : "";

        $specify_ids['include']['category'] = array();
        $specify_ids['include']['post_tag'] = array();
        $specify_ids['include']['post'] = array();
        $specify_ids['include']['page'] = array();
        $specify_ids['exclude']['category'] = array();
        $specify_ids['exclude']['post_tag'] = array();
        $specify_ids['exclude']['post'] = array();
        $specify_ids['exclude']['page'] = array();

        if (!empty($ad_include_tags) || !empty($ad_exclude_tags)) {

            if (!empty($ad_include_tags)) {
                $ad_include_tags = explode("%smartad%,", $ad_include_tags);

                $tags_count = count($ad_include_tags);

                $exp_include_tags = explode("%smartad%", $ad_include_tags[$tags_count - 1]);
                $ad_include_tags[$tags_count - 1] = $exp_include_tags[0];

                foreach ($ad_include_tags as $key => $ad_include_tag) {
                    $ad_include_tag = explode("%", $ad_include_tag);
                    $ad_include_tags[$key] = $ad_include_tag;
                }

                foreach ($ad_include_tags as $key => $ad_include_tag) {
                    if ($ad_include_tag[0] == "category") {
                        array_push($specify_ids['include']['category'], $ad_include_tag[1]);
                    } elseif ($ad_include_tag[0] == "post_tag") {
                        array_push($specify_ids['include']['post_tag'], $ad_include_tag[1]);
                    } elseif ($ad_include_tag[0] == "post") {
                        array_push($specify_ids['include']['post'], $ad_include_tag[1]);
                    } elseif ($ad_include_tag[0] == "page") {
                        array_push($specify_ids['include']['page'], $ad_include_tag[1]);
                    }
                }
            }

            if (!empty($ad_exclude_tags)) {
                $ad_exclude_tags = explode("%smartad%,", $ad_exclude_tags);

                $tags_count = count($ad_exclude_tags);

                $exp_exclude_tags = explode("%smartad%", $ad_exclude_tags[$tags_count - 1]);
                $ad_exclude_tags[$tags_count - 1] = $exp_exclude_tags[0];

                foreach ($ad_exclude_tags as $key => $ad_exclude_tag) {

                    $ad_exclude_tag = explode("%", $ad_exclude_tag);

                    $ad_exclude_tags[$key] = $ad_exclude_tag;
                }

                foreach ($ad_exclude_tags as $key => $ad_exclude_tag) {
                    if ($ad_exclude_tag[0] == "category") {
                        array_push($specify_ids['exclude']['category'], $ad_exclude_tag[1]);
                    } elseif ($ad_exclude_tag[0] == "post_tag") {
                        array_push($specify_ids['exclude']['post_tag'], $ad_exclude_tag[1]);
                    } elseif ($ad_exclude_tag[0] == "post") {
                        array_push($specify_ids['exclude']['post'], $ad_exclude_tag[1]);
                    } elseif ($ad_exclude_tag[0] == "page") {
                        array_push($specify_ids['exclude']['page'], $ad_exclude_tag[1]);
                    }
                }
            }

            $ad_allow = TRUE;

            /** Check if current page included or excloded */
            if ($sa_page_info['sa_is_archive']) {
                $term = $sa_page_info['sa_get_queried_object'];

                if (!empty($term)) {
                    $term_id = $term['term_id'];

                    if (in_array($term_id, $specify_ids['include']['category']) || in_array($term_id, $specify_ids['include']['post_tag'])) {
                        $ad_allow = TRUE;
                    } elseif (!empty($ad_include_tags)) {
                        $ad_allow = FALSE;
                    }

                    if (in_array($term_id, $specify_ids['exclude']['category']) || in_array($term_id, $specify_ids['exclude']['post_tag'])) {
                        $ad_allow = FALSE;
                    }
                } elseif (!empty($ad_include_tags)) {
                    $ad_allow = FALSE;
                }
            } elseif ($sa_page_info['sa_is_page'] || $sa_page_info['sa_is_single']) {

                $post_terms_ids = array();
                $post_tag_ids = array();
                $post_id = $sa_page_info['sa_get_the_ID'];

                $all_taxonomies = $sa_page_info['sa_get_taxonomies'];
                unset($all_taxonomies["link_taxonomy"]);
                unset($all_taxonomies["post_format"]);
                unset($all_taxonomies["post_tag"]);

                $post_terms = wp_get_post_terms($sa_page_info['sa_get_the_ID'], $all_taxonomies, array('fields' => 'ids'));
                if (!empty($post_terms)) {
                    $post_terms_ids = array_merge($post_terms_ids, $post_terms);
                }

                $post_tags = wp_get_post_terms($sa_page_info['sa_get_the_ID'], "post_tag", array('fields' => 'ids'));
                if (!empty($post_tags)) {
                    $post_tag_ids = array_merge($post_tag_ids, $post_tags);
                }


                $inter_terms = array_intersect($specify_ids['include']['category'], $post_terms_ids);
                $inter_tags = array_intersect($specify_ids['include']['post_tag'], $post_tag_ids);
                if (in_array($post_id, $specify_ids['include']['post']) || in_array($post_id, $specify_ids['include']['page']) || !empty($inter_terms) || !empty($inter_tags)) {
                    $ad_allow = TRUE;
                } elseif (!empty($ad_include_tags)) {
                    $ad_allow = FALSE;
                }

                $inter_terms = array_intersect($specify_ids['exclude']['category'], $post_terms_ids);
                $inter_tags = array_intersect($specify_ids['exclude']['post_tag'], $post_tag_ids);
                if (in_array($post_id, $specify_ids['exclude']['post']) || in_array($post_id, $specify_ids['exclude']['page']) || !empty($inter_terms) || !empty($inter_tags)) {
                    $ad_allow = FALSE;
                }
            } else {
                if (!empty($ad_include_tags)) {
                    $ad_allow = FALSE;
                }
            }
        } else {
            $ad_allow = TRUE;
        }

        // Get restrict parameters
        $ad_restrict_views = isset($ads_options[$ad_id]["restrict_views"]) ? $ads_options[$ad_id]["restrict_views"] : "";
        $ad_restrict_visits = isset($ads_options[$ad_id]["restrict_visits"]) ? $ads_options[$ad_id]["restrict_visits"] : "";
        $ad_content = isset($ads_options[$ad_id]["ad_content"]) ? $ads_options[$ad_id]["ad_content"] : "";
        $ad_deadline = isset($ads_options[$ad_id]["deadline"]) ? $ads_options[$ad_id]["deadline"] : "";
        $ad_views = isset($ads_stat[$ad_id]["view"]) ? $ads_stat[$ad_id]["view"] : 0;
        $ad_visits = isset($ads_stat[$ad_id]["visit"]) ? $ads_stat[$ad_id]["visit"] : 0;

        // get curent date
        $current_date = date('Y-m-d', current_time('timestamp'));

        if ($ad_allow == FALSE || empty($ad_content) || $campaign_ad["status"] == "suspended" || (!empty($ad_deadline) && strtotime($current_date) > $ad_deadline) || (!empty($ad_restrict_views) && $ad_views >= $ad_restrict_views) || (!empty($ad_restrict_visits) && $ad_visits >= $ad_restrict_visits)) {
            unset($campaign_ads[$ad_id]);
        }
    }

    // Check whether campaign has enable ads
    if (empty($campaign_ads)) {
        return $sa_empty_embed;
    }

    // Get cookie for this campaign ads
    $sa_embeds_info = isset($_COOKIE['sa_embeds_info']) ? $_COOKIE['sa_embeds_info'] : '';

    if (!empty($sa_embeds_info)) {
        $sa_embeds_info = json_decode(stripslashes($sa_embeds_info));
        $sa_embeds_info = get_object_vars($sa_embeds_info);

        $sa_emb_info = isset($sa_embeds_info[$campaign_id]) ? $sa_embeds_info[$campaign_id] : FALSE;
    }

    // Check if cookie is set for this campaign ads
    if (!empty($sa_emb_info)) {
        $lasts_priority = $sa_emb_info->last;
        $last_id = $sa_emb_info->last_id;

        $last_ad = isset($campaign_ads[$last_id]) ? $campaign_ads[$last_id] : FALSE;

        if (!empty($_COOKIE['sa_emb_change_interval_' . $campaign_id]) && $camp_options["change_interval"] !== -1 && !empty($last_ad) && in_array($last_ad, $campaign_ads)) {
            $ad = $last_ad;

            $camp_options["change_interval"] = "dontset";
        } else {
            $ads_arr_vals = array_values($campaign_ads);
            $first_priority = $ads_arr_vals[0]["priority"];
            $last_priority = $ads_arr_vals[count($campaign_ads) - 1]["priority"];

            $ad_choosen = FALSE;
            while (empty($ad_choosen)) {
                $lasts_priority++;
                if ($lasts_priority > $last_priority) {
                    $lasts_priority = $first_priority;
                }

                $ad = $ads_by_priority[$lasts_priority];
                if (!empty($ad) && in_array($ad, $campaign_ads)) {
                    $ad_choosen = TRUE;
                }
            }
        }
    } else {
        // Get first ad(enable) by priority and display
        $ads_arr_vals = array_values($campaign_ads);
        $ad = $ads_arr_vals[0];
    }

    // Check if ad exists
    if (empty($ad)) {
        return $sa_empty_embed;
    }

    /** Determine embed content type and make html content for display */
    $emb_ad_html = "";

    if ($ad["type"] == "image") {
        if (!empty($ads_options[$ad['id']]["link_to"])) {
            $emb_ad_html = '<div data-sa-link-target="'.$camp_options["link_type"].'" data-sa-link="' . $ads_options[$ad['id']]["link_to"] . '" data-sa-ad-id="' . $ad["id"] . '" style="background-size: ' . $camp_options["background_type"] . '; background-image: url(' . $ads_options[$ad['id']]["ad_content"] . ')" class="sa-ad-link sa-embed-image"></div>';
        } else {
            $emb_ad_html = '<div style="background-size: ' . $camp_options["background_type"] . '; background-image: url(' . $ads_options[$ad['id']]["ad_content"] . ')" class="sa-embed-image"></div>';
        }
    } elseif ($ad["type"] == "video") {
        /** Convert youtube or vimeo url to embed */
        $url_data = json_decode($ads_options[$ad['id']]["ad_content"]);
        $parsed_url = $url_data->parsed;

        /** Convert youtube or vimeo url to embed */
        if ($parsed_url->provider == "youtube") {

            $start_time = (isset($parsed_url->params->start) ? '&start=' . $parsed_url->params->start : "");
            $emb_ad_html = '<iframe class="sa-embed-iframe" width="100%" height="100%" src="https://www.youtube.com/embed/' . $parsed_url->id . '?rel=0&autoplay=' . $camp_options['auto_play_video'] . $start_time . '" frameborder="0" allowfullscreen></iframe>';
        } else if ($parsed_url->provider == "vimeo") {

            $start_time = (isset($parsed_url->params->start) ? '#t=' . $parsed_url->params->start . 's' : "");
            $emb_ad_html = '<iframe class="sa-embed-iframe" src="http://player.vimeo.com/video/' . $parsed_url->id . '?autoplay=' . $camp_options['auto_play_video'] . $start_time . '" width="100%" height="100%" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>';
        }
    } elseif ($ad["type"] == "flash") {
        $emb_ad_html = '<embed src="' . $ads_options[$ad['id']]["ad_content"] . '" width="100%" height="100%">';
    } elseif ($ad["type"] == "html") {
        $emb_ad_html = '<div class="embed-code-type" style="height: '. $camp_options["height"] .'">'.$ads_options[$ad['id']]["ad_content"].'</div>';
        $emb_ad_html = apply_filters('the_content', $emb_ad_html);
    } elseif ($ad["type"] == "iframe") {
        $emb_ad_html = '<iframe class="sa-embed-iframe" src="' . $ads_options[$ad['id']]["ad_content"] . '" height="100%" width="100%" sandbox></iframe>';
    }

    // update ad statistics
    sa_update_ad_statistics($ad["id"], "view");

    $ad_link = '';
    $embed_html = '';
    
    if (!empty($ads_options[$ad['id']]["link_to"]) && !empty($camp_options["show_link"])) {
        $ad_link = '<div data-sa-link-target="'.$camp_options["link_type"].'" style="color: ' . $camp_options["link_color"] . '" class="sa-ad-link sa-emb-link" data-sa-ad-id="' . $ad["id"] . '" data-sa-link="' . $ads_options[$ad['id']]["link_to"] . '">' . $ads_options[$ad['id']]["link_to"] . '</div>';
    }

    if (!empty($ads_options[$ad['id']]["ad_content"])) {
        if ($ad["type"] == "html")
            $embed_height = ';';
        else 
            $embed_height = '; height: '. $camp_options["height"];
        $embed_html .= '<div class="sa-embed-cont sa_reset_style" style="width: ' . $camp_options["width"] . $embed_height .'" >'
                . '<form class="sa-embed-info">'
                . '<input type="hidden" name="campaign_id" value="' . $campaign_id . '" />'
                . '<input type="hidden" name="last" value="' . $ad["priority"] . '" />'
                . '<input type="hidden" name="last_id" value="' . $ad["id"] . '" />'
                . '<input type="hidden" name="change_interval" value="' . $camp_options["change_interval"] . '" />'
                . '</form>';
        $sa_extra_options = get_option('sa_extra_options');
        $cache = $sa_extra_options['sa_cache_enabled'];
        if($cache == 'true'){            
            if($sa_anticache)
                $embed_html = $embed_html . $emb_ad_html . $ad_link . '</div>';
            else
                $embed_html = $embed_html . '</div>';
        }
        else
            $embed_html = $embed_html . $emb_ad_html . $ad_link . '</div>';
    }

    return $embed_html;
}

add_shortcode('smartad', 'sa_embed_campaign_func');

/*
 * when anti-cache enabled ajax handler for get embed campain content
 */
function sa_call_embed_campaign_func(){
    $sa_page_info = $_POST['sa_page_info'];
    $sa_widget_id = $_POST['sa_widget_id'];
    if($sa_widget_id != 0){
        $sa_all_widgets = get_option('widget_sa_campaign');
        $sa_widget = $sa_all_widgets[$sa_widget_id];
        $sa_shortcode_id = $sa_widget['campaign_id'];
    }
    else
        $sa_shortcode_id = $_POST['shortcode_id'];
    $atts['id'] = $sa_shortcode_id;
    $sa_anticache = true;
    $content = '';
    $name = '';
    $result[$_POST['shortcode_id']] = sa_embed_campaign_func($atts,$content,$name,$sa_page_info,$sa_anticache);
    echo json_encode($result);
    die();
}
add_action('wp_ajax_nopriv_sa_call_embed_campaign_func', 'sa_call_embed_campaign_func');
add_action('wp_ajax_sa_call_embed_campaign_func', 'sa_call_embed_campaign_func');