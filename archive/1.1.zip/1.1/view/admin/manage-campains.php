<?php
defined('ABSPATH') or die('No script kiddies please!');
/**
 * Add SmartAd managing page in admin
 */
//Add menu item SmartAd
add_action('admin_menu', 'aparg_sa_compains_managing');
function aparg_sa_compains_managing() {
    add_menu_page('Manage campaigns', 'SmartAd', 'manage_options', 'manage-campaigns', '', plugin_dir_url(__FILE__) . 'images/plugin-icon.png');
}

//Add menu item for settings and campaigns managing in SmartAd
add_action( 'admin_menu', 'sa_settings_page_managing' );
function sa_settings_page_managing(){
    add_submenu_page( 'manage-campaigns', 'Campaigns page', __('Campaigns', 'aparg-smartad'), 'manage_options', 'manage-campaigns', 'aparg_sa_campaigns_manage_page');
    add_submenu_page( 'manage-campaigns', 'Settings page', __('Settings', 'aparg-smartad'), 'manage_options', 'manage-settings', 'sa_settings_page');
}

/*
 * create settings page 
 */
function sa_settings_page(){
    $wp_version = get_bloginfo('version');
    $sa_extra_options = get_option('sa_extra_options');
    ?>
    <!-- Messages -->
    <div class="sa-popup sa-transit-450" id="sa-message-popup" data-sa-open="false">
        <p></p>
        <span class="sa-close-popup"></span>
    </div>

    <div id="sa-managing-wrap" <?php echo (($wp_version >= 3.8) ? 'class="sa-mobile-admin"' : ""); ?>>
        <!-- Header -->
        <h2 id="sa-ad-campaign-header">
            <span><?php _e('Settings', 'aparg-smartad') ?></span>
            <div id="sa-save-camps-cont">
                <div class="sa-waiting-wrapper">
                    <button type="button" class="button button-primary" id="sa-update-settings"><?php _e('Update All', 'aparg-smartad') ?></button>
                </div>
            </div>
        </h2>
        <span class="sa-by-aparg"><?php _e('Developed by', 'aparg-smartad') ?> <a href="<?php echo SA_APARG_LINK ?>" target="blank">Aparg.</a></span>
        <!-- Custom Css -->
        <div>
            <div id="sa-custom-css-new" class="sa-code-type">
                <label><?php _e('Custom CSS', 'aparg-smartad') ?></label>
                <div class="sa-code-type-textarea">
                    <textarea id="sa-code-area" class="sa-code-area"></textarea>
                    <textarea class="sa-hold-code-content sa-hidden-textarea" id="sa-custom-css-value"><?php echo stripslashes($sa_extra_options['sa_custom_css']); ?></textarea>
                </div>
            </div>
            <!-- Warning text -->
            <div id="sa-warning-text-new" class="sa-code-type">
                <div>
                    <label><?php _e('AdBlock Warning', 'aparg-smartad') ?></label>
                    <div class="sa-warning-text-enabled" style="float: right; display: block">
                        <input type="checkbox" id="sa-warning-text-enabled" value="true" <?php checked('true', $sa_extra_options['sa_warning_text_enabled'], true); ?> />
                        <label for="sa-warning-text-enabled"><?php _e('Activate', 'aparg-smartad') ?></label>
                        <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('This warning will appear if AdBlock plugin installed in a client browser', 'aparg-smartad') ?>"></span>
                    </div>
                </div>
                <div class="sa-code-type-textarea">
                    <textarea id="sa-code-area" class="sa-code-area"></textarea>
                    <textarea class="sa-hold-code-content sa-hidden-textarea" id="sa-warning-text-value"><?php echo stripslashes($sa_extra_options['sa_warning_text']); ?></textarea>
                    <span class="sa-input-message"><?php _e('Default:', 'aparg-smartad');?> <?php _e('To get the best experience of using our site please disable ad blocker.', 'aparg-smartad');?> </span>
                </div>
            </div>
        </div>    
    </div>
    <?php
    echo '<script>var enaableLeavepage = false;</script>';
}

/**
 * Create compains manage page forms
 */
function aparg_sa_campaigns_manage_page() {

    /** Get All campaigns, also determine active and suspended campaigns count */
    $get_campaigns = sa_get_campaigns();
    $campaigns = array();
    $active_count = 0;
    $suspended_count = 0;
    if (!empty($get_campaigns)) {
        foreach ($get_campaigns as $camp_data) {
            $campaigns[$camp_data['id']] = $camp_data;

            /** Initialize additional fields */
            $campaigns[$camp_data['id']]['total_views'] = 0;
            $campaigns[$camp_data['id']]['total_visits'] = 0;
            $campaigns[$camp_data['id']]['ads_count'] = 0;
            $campaigns[$camp_data['id']]['active_ads_count'] = 0;
            $campaigns[$camp_data['id']]['suspend_ads_count'] = 0;

            if ($camp_data['status'] == 'active') {
                $active_count++;
                $campaigns[$camp_data['id']]['status_name'] = __('Active', 'aparg-smartad');
            } elseif ($camp_data['status'] == 'suspended') {
                $suspended_count++;
                $campaigns[$camp_data['id']]['status_name'] = __('Suspended', 'aparg-smartad');
            }
        }
    }

    /** Get all campaign options */
    $get_campaign_options = sa_get_all_campaign_options();
    $camp_options = array();

    if (!empty($get_campaign_options)) {
        foreach ($get_campaign_options as $campaign_option) {
            $camp_options[$campaign_option['campaign_id']][$campaign_option['option_name']] = $campaign_option['option_value'];
        }
    }

    /** Get all ads statistics */
    $get_ads_stat = sa_get_ad_stat_counts();
    $ads_stat = array();
    if (!empty($get_ads_stat)) {
        foreach ($get_ads_stat as $get_ad_stat) {
            $ads_stat[$get_ad_stat['ad_id']][$get_ad_stat['type']] = $get_ad_stat['total_count'];
        }
    }

    /** Get all ads, also calculate campaigns ads total views and visits count, active and suspended ads count */
    $get_ads = sa_get_ads();

    $ads = array();
    if (!empty($get_ads)) {
        foreach ($get_ads as $ad_data) {
            $ads[$ad_data['campaign_id']][$ad_data['id']] = $ad_data;

            /** Add views and visits counts to parent campaign totals */
            $ad_views = (isset($ads_stat[$ad_data['id']]['view'])) ? $ads_stat[$ad_data['id']]['view'] : 0;
            $ad_visits = (isset($ads_stat[$ad_data['id']]['visit'])) ? $ads_stat[$ad_data['id']]['visit'] : 0;

            $campaigns[$ad_data['campaign_id']]['total_views'] += $ad_views;
            $campaigns[$ad_data['campaign_id']]['total_visits'] += $ad_visits;

            /** Check if ad active or suspend, and increment respective counter of parent campaign, also ads */
            if ($ad_data['status'] == 'active') {
                $campaigns[$ad_data['campaign_id']]['active_ads_count'] ++;
                $ads[$ad_data['campaign_id']][$ad_data['id']]['status_name'] = __('Active', 'aparg-smartad');
            } elseif ($ad_data['status'] == 'suspended') {
                $campaigns[$ad_data['campaign_id']]['suspend_ads_count'] ++;
                $ads[$ad_data['campaign_id']][$ad_data['id']]['status_name'] = __('Suspended', 'aparg-smartad');
            }
            $campaigns[$ad_data['campaign_id']]['ads_count'] ++;
        }
    }

    /** Get all ad options */
    $get_ad_options = sa_get_all_ad_options();
    $ad_options = array();
    if (!empty($get_ad_options)) {
        foreach ($get_ad_options as $ad_option) {
            $ad_options[$ad_option['ad_id']][$ad_option['option_name']] = $ad_option['option_value'];
        }
    }

    /** Get or set required variables */
    // Popup directions
    $popup_directions = array('center' => __("Center", 'aparg-smartad'), 'top' => __("From top", 'aparg-smartad'), 'right' => __("From right", 'aparg-smartad'), 'bottom' => __("From bottom", 'aparg-smartad'), 'left' => __("From left", 'aparg-smartad'));
    ?>
    <div id="sa-managing-overlay"></div>
    <?php $wp_version = get_bloginfo('version'); $sa_extra_options = get_option('sa_extra_options');?>
    <div id="sa-managing-wrap" <?php echo (($wp_version >= 3.8) ? 'class="sa-mobile-admin"' : ""); ?>>
        <!-- Popup for adding new campaign -->
        <div class="sa-popup sa-wp-popup sa-transit-150" id="sa-add-campaign-popup" data-sa-open="false">
            <div class="sa-popup-header">
                <span class="sa-popup-title"><?php _e('Choose Campaign Type', 'aparg-smartad') ?></span>
                <span class="sa-close-popup"></span>
            </div>
            <div class="sa-popup-cont">
                <div id="sa-campaign-types"></div>
            </div>
            <div class="sa-popup-footer">
                <button class="button-primary" id="sa-campaign-save"><?php _e('Add', 'aparg-smartad') ?></button>
            </div>
        </div>
        <!-- Popup for choose new ad type -->
        <div class="sa-popup sa-wp-popup sa-transit-150" id="sa-add-ad-popup" data-sa-open="false">
            <div class="sa-popup-header">
                <span class="sa-popup-title"><?php _e('Choose Ad Type', 'aparg-smartad') ?></span>
                <span class="sa-close-popup"></span>
            </div>
            <div class="sa-popup-cont">
                <div id="sa-ad-types"></div>
            </div>
            <div class="sa-popup-footer">
                <button class="button-primary" id="sa-ad-save"><?php _e('Add', 'aparg-smartad') ?></button>
            </div>
        </div>
        <!-- Popup for type code -->
        <div class="sa-popup sa-wp-popup sa-transit-150" id="sa-code-popup" data-sa-open="false">
            <div class="sa-popup-header">
                <span class="sa-popup-title"><?php _e('Enter Code', 'aparg-smartad') ?></span>
                <span class="sa-close-popup"></span>
            </div>
            <textarea id="sa-code-area"></textarea>
            <div class="sa-popup-footer">
                <div class="sa-warning-text-enabled">
                    <input type="checkbox" id="sa-warning-text-enabled" value="true" <?php checked('true', get_option('sa_warning_text_enabled'), true); ?> />
                    <label for="sa-warning-text-enabled"><?php _e('Activate', 'aparg-smartad') ?></label>
                    <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('This warning will appear if AdBlock plugin installed in a client browser', 'aparg-smartad') ?>"></span>
                </div>
                <button id="sa-save-code" class="button button-primary"><?php _e('Ok', 'aparg-smartad') ?></button>
            </div>
        </div>
        <!-- Confirmation messages -->
        <div class="sa-popup sa-wp-popup sa-transit-150" id="sa-confirm-message" data-sa-open="false">
            <div class="sa-popup-header">
                <span class="sa-popup-title"></span>
                <span class="sa-close-popup"></span>
            </div>
            <div class="sa-popup-cont">
                <p id="sa-confirm-text"></p>
            </div>
            <div class="sa-popup-footer">
                <ul id="sa-confirm-options"></ul> 
            </div>
        </div>
        <!-- Export ranged date-->
        <div class="sa-popup sa-wp-popup sa-transit-150" id="sa-export-range" data-sa-open="false">
            <div class="sa-popup-header">
                <span class="sa-popup-title"><?php _e('Choose Period', 'aparg-smartad') ?></span>
                <span class="sa-close-popup"></span>
            </div>
            <div class="sa-popup-cont">
                <div class="sa-stat-filter">
                    <input type="text" class="sa-stat-from" placeholder="<?php _e('From', 'aparg-smartad') ?>" />
                    <input type="text" class="sa-stat-to" placeholder="<?php _e('To', 'aparg-smartad') ?>" />
                </div>
            </div>
            <div class="sa-popup-footer">
                <div class="sa-waiting-wrapper">
                    <button id="sa-export-period-stats" class="button button-primary"><?php _e('Export', 'aparg-smartad') ?></button>
                </div>
            </div>
        </div>
        <!-- Messages -->
        <div class="sa-popup sa-transit-450" id="sa-message-popup" data-sa-open="false">
            <p></p>
            <span class="sa-close-popup"></span>
        </div>
        <!-- Button for add new campaign -->
        <h2 id="sa-ad-campaign-header">
            <span><?php _e('Campaigns', 'aparg-smartad') ?></span>
            <button type="button" class="button sa-add-campaign" id="sa-add-campaign"><?php _e('Add New', 'aparg-smartad') ?></button>
            <button type="button" class="button sa-export-all sa-export-range <?php if (empty($campaigns)): ?> sa-all-action-hidden <?php endif; ?>" id="sa-export-all"><?php _e('Export Full Stats', 'aparg-smartad') ?></button>
            <div id="sa-anticache" class="sa-code-button">
                <input type="checkbox" value="true" id="sa-cache-enable" <?php checked('true', $sa_extra_options['sa_cache_enabled'], true); ?> />
                <label for="sa-cache-enable"><?php _e('Anti-Cache', 'aparg-smartad') ?></label>
                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('If enabled ads will be rotating in the campaign even with a cache plugin installed <br> Note: After enabling/disabling Anti-Cache clear cache files', 'aparg-smartad') ?>"></span>
                <textarea class="sa-hold-code-content sa-hidden-textarea"><?php echo $sa_extra_options['sa_cache_enabled']; ?></textarea>
            </div>
            <div id="sa-save-camps-cont">
                <div class="sa-waiting-wrapper">
                    <button type="button" class="button button-primary <?php if (empty($campaigns)): ?> sa-all-action-hidden <?php endif; ?>" id="sa-update-all"><?php _e('Update All', 'aparg-smartad') ?></button>
                </div>
            </div>
            
        </h2>
        <!-- Filter campaigns by status -->
        <?php
        /** Get campaigns count */
        $all_count = count($campaigns);
        ?>
        <ul class="sa-campaigns-filter">
            <li data-sa-filter="all">
                <span class="sa-status-name sa-selected-status"><?php _e('All', 'aparg-smartad') ?></span>
                <span class="sa-status-count"><?php echo $all_count ?></span>
            </li>
            <li class="sa-inside-li" data-sa-filter="active">
                <span class="sa-status-name"><?php _e('Active', 'aparg-smartad') ?></span>
                <span class="sa-status-count"><?php echo $active_count ?></span>
            </li>
            <li data-sa-filter="suspended">
                <span class="sa-status-name"><?php _e('Suspended', 'aparg-smartad') ?></span>
                <span class="sa-status-count"><?php echo $suspended_count ?></span>
            </li>
        </ul>
        <span id="sa-by-aparg" class="sa-by-aparg"><?php _e('Developed by', 'aparg-smartad') ?> <a href="<?php echo SA_APARG_LINK ?>" target="blank">Aparg.</a></span>
        <ul id="sa-campaigns-block">
            <?php
            /**
             * Show all campaigns 
             */
            /** Check if campaigns exists display else say it is not */
            if (!empty($campaigns)) {
                foreach ($campaigns as $camp_id => $campaign) {

                    // Get human creation date
                    $camp_creation_date = date_i18n(get_option('date_format'), strtotime($campaign["creation_date"]));

                    /** Get statistics */
                    $ads_count = isset($campaign['ads_count']) ? $campaign['ads_count'] : 0;
                    $views_count = isset($campaign['total_views']) ? $campaign['total_views'] : 0;
                    $visits_count = isset($campaign['total_visits']) ? $campaign['total_visits'] : 0;

                    $ads_kilo = $ads_count;
                    if ($ads_count >= 1000) {
                        $ads_kilo = round($ads_count / 1000, 1);
                        $ads_kilo .= "K";
                    }

                    $views_kilo = $views_count;
                    if ($views_count >= 1000) {
                        $views_kilo = round($views_count / 1000, 1);
                        $views_kilo .= "K";
                    }

                    $visits_kilo = $visits_count;
                    if ($visits_count >= 1000) {
                        $visits_kilo = round($visits_count / 1000, 1);
                        $visits_kilo .= "K";
                    }
                    ?>
                    <li class="sa-campaign-block sa-transit-150 sa-slide-cont" data-sa-camp-type="<?php echo $campaign['type']; ?>" data-sa-status="<?php echo $campaign['status']; ?>" data-sa-campaign-id="<?php echo $campaign['id']; ?>" id="sa-campaign-block-<?php echo $campaign['id']; ?>">
                        <div class="sa-campaign-header sa-slide-opener" data-sa-open-slide="false">
                            <div class="sa-campaign-type-logo" data-sa-campaign-type="<?php echo $campaign['type']; ?>"></div>
                            <div class="sa-camp-info">
                                <input type="text" class="sa-suspended-input sa-campaign-name" value="<?php echo $campaign['name']; ?>" title="<?php echo $campaign['name']; ?>" />
                                <p class="sa-dash-pub-date"><span><?php echo __('Date:', 'aparg-smartad') ?></span>&nbsp;<?php echo $camp_creation_date; ?></p>
                            </div>
                            <span class="sa-campaign-status <?php echo "sa-camp-status-" . $campaign['status'] ?>"><?php echo $campaign['status_name']; ?></span>
                            <ul class="sa-camp-data">
                                <li class="sa-views-count">
                                    <div><?php echo $views_kilo; ?></div>
                                    <div><?php _e('Views', 'aparg-smartad') ?></div>
                                </li>
                                <li class="sa-visits-count sa-inside-data">
                                    <div><?php echo $visits_kilo; ?></div>
                                    <div><?php _e('Clicks', 'aparg-smartad') ?></div>
                                </li>
                                <li class="sa-ads-count">
                                    <div><?php echo $ads_kilo; ?></div>
                                    <div><?php _e('Ads', 'aparg-smartad') ?></div>
                                </li>
                            </ul>
                            <span class="sa-slide-open-pointer"></span>                                   
                        </div>
                        <div class="sa-campaign-content sa-sliding-block" data-sa-open="false">                            
                            <!-- Display campaign ads -->
                            <div class="sa-campaign-ads">
                                <div class="sa-ads-header">
                                    <h3><?php _e('Ads', 'aparg-smartad') ?></h3>
                                    <ul class="sa-ads-filter">
                                        <li data-sa-ad-filter="all">
                                            <span class="sa-ad-status-name sa-selected-status"><?php _e('All', 'aparg-smartad') ?></span>
                                            <span class="sa-status-count"><?php echo $campaign['ads_count'] ?></span>
                                        </li>
                                        <li class="sa-inside-li" data-sa-ad-filter="active">
                                            <span class="sa-ad-status-name"><?php _e('Active', 'aparg-smartad') ?></span>
                                            <span class="sa-status-count"><?php echo $campaign['active_ads_count'] ?></span>
                                        </li>
                                        <li data-sa-ad-filter="suspended">
                                            <span class="sa-ad-status-name"><?php _e('Suspended', 'aparg-smartad') ?></span>
                                            <span class="sa-status-count"><?php echo $campaign['suspend_ads_count'] ?></span>
                                        </li>
                                    </ul>
                                    <button class="button button-primary sa-add-ad" data-sa-campaign-id="<?php echo $campaign['id']; ?>" data-sa-campaign-type="<?php echo $campaign['type']; ?>"><?php _e('Add New', 'aparg-smartad') ?></button>
                                </div>
                                <?php ?>
                                <ul class="sa-ads-list sa-sortable">                                
                                    <?php
                                    $campaign_ads = (!empty($ads[$camp_id])) ? $ads[$camp_id] : FALSE;
                                    if (!empty($campaign_ads)) {
                                        foreach ($campaign_ads as $ad_id => $campaign_ad) {

                                            $ad_creation_date = date_i18n(get_option('date_format'), strtotime($campaign_ad["creation_date"]));
                                            $ad_status = $campaign_ad["status"];
                                            $ad_status_name = $campaign_ad["status_name"];
                                            $ad_type = $campaign_ad["type"];

                                            /** Get statistics */
                                            $views_count = isset($ads_stat[$ad_id]['view']) ? $ads_stat[$ad_id]['view'] : 0;
                                            $visits_count = isset($ads_stat[$ad_id]['visit']) ? $ads_stat[$ad_id]['visit'] : 0;

                                            if (empty($views_count)) {
                                                $crt = 0;
                                            } else {
                                                $crt = round($visits_count / $views_count * 100);
                                            }

                                            $views_kilo = $views_count;
                                            if ($views_count >= 1000) {
                                                $views_kilo = round($views_count / 1000, 1);
                                                $views_kilo .= "K";
                                            }

                                            $visits_kilo = $visits_count;
                                            if ($visits_count >= 1000) {
                                                $visits_kilo = round($visits_count / 1000, 1);
                                                $visits_kilo .= "K";
                                            }
                                            ?>
                                            <li id="sa-ad-block-<?php echo $ad_id; ?>" class="sa-ad-block" data-sa-status="<?php echo $ad_status; ?>" data-sa-ad-id="<?php echo $ad_id; ?>">
                                                <form class="sa-ad-form">
                                                    <input type="hidden" name="action" class="sa-ad-action" value="update"/>
                                                    <input type="hidden" name="campaign_id" value="<?php echo $campaign['id']; ?>"/>
                                                    <input type="hidden" name="priority" class="sa-ad-priority" value="<?php echo $campaign_ad['priority']; ?>"/>
                                                    <input type="hidden" name="ad_id" value="<?php echo $ad_id; ?>"/>
                                                    <div class="sa-ad-controls">
                                                        <div class="sa-sort-mover" title="<?php echo ucfirst(__('Drag & Drop', 'aparg-smartad')) ?>"></div>
                                                        <ul class="sa-actions sa-ad-actions">
                                                            <?php if ($ad_status == "suspended"): ?>
                                                                <li data-sa-action="activate" title="<?php echo ucfirst(__('Activate', 'aparg-smartad')) ?>">
                                                                    <span class="sa-action-name sa-dash-activate"></span>
                                                                </li>
                                                            <?php else : ?>
                                                                <li data-sa-action="suspend" title="<?php echo ucfirst(__('Suspend', 'aparg-smartad')) ?>">
                                                                    <span class="sa-action-name sa-dash-suspend"></span>
                                                                </li>
                                                            <?php endif; ?>
                                                            <li data-sa-action="delete" title="<?php echo ucfirst(__('Delete', 'aparg-smartad')) ?>">
                                                                <span class="sa-action-name sa-dash-delete"></span>
                                                            </li>
                                                        </ul>
                                                        <div class="sa-ad-header">
                                                            <div class="sa-ad-type-logo" data-sa-ad-type="<?php echo $campaign_ad['type']; ?>">
                                                                <input type="hidden" name="type" value="<?php echo $campaign_ad['type']; ?>"/>
                                                            </div>
                                                            <div class="sa-ad-info">
                                                                <input type="text" class="sa-suspended-input sa-ad-name" name="title" value="<?php echo $campaign_ad['title']; ?>" title="<?php echo $campaign_ad['title']; ?>" />
                                                                <p class="sa-dash-pub-date"><span><?php echo __('Date:', 'aparg-smartad') ?></span>&nbsp;<?php echo $ad_creation_date; ?></p>
                                                            </div>                                                       
                                                            <span class="sa-ad-status sa-ad-status-<?php echo $ad_status; ?>"><?php echo $ad_status_name; ?></span>
                                                            <ul class="sa-ad-data">
                                                                <li class="sa-views-count">
                                                                    <div><?php echo $views_kilo; ?></div>
                                                                    <div><?php _e('Views', 'aparg-smartad') ?></div>
                                                                </li>
                                                                <li class="sa-visits-count sa-inside-data">
                                                                    <div><?php echo $visits_kilo; ?></div>
                                                                    <div><?php _e('Clicks', 'aparg-smartad') ?></div>
                                                                </li>
                                                                <li class="sa-crt">
                                                                    <div><?php echo $crt; ?></div>
                                                                    <div><?php _e('CTR', 'aparg-smartad') ?>(%)</div>
                                                                </li>
                                                            </ul>                                                        
                                                        </div>
                                                        <ul class="sa-ad-options">
                                                            <li class="sa-form-item sa-link-to">
                                                                <span><?php _e('Link To', 'aparg-smartad') ?></span>
                                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('URL to customer’s website', 'aparg-smartad') ?>"></span>
                                                                <div class="sa-input-block">
                                                                    <input type="text" class="sa-link" name="link_to" value="<?php echo (isset($ad_options[$ad_id]['link_to'])) ? $ad_options[$ad_id]['link_to'] : ""; ?>" />
                                                                </div>
                                                                <span class="sa-input-message"></span>
                                                            </li>                                                        
                                                            <li class="sa-form-item sa-ad-usual-input">
                                                                <?php
                                                                $ad_deadline = isset($ad_options[$ad_id]['deadline']) ? $ad_options[$ad_id]['deadline'] : "";
                                                                $deadline_date = '';
                                                                if (!empty($ad_deadline)) {
                                                                    $deadline_date = strtotime($ad_deadline);
                                                                }
                                                                $current_date = strtotime(date('Y-m-d', current_time('timestamp')));
                                                                ?>
                                                                <span><?php _e('Deadline', 'aparg-smartad') ?></span>
                                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Date after which the ad will be automatically suspended', 'aparg-smartad') ?>"></span>
                                                                <div class="sa-input-block">
                                                                    <input type="text" class="sa-deadline-date <?php if (!empty($deadline_date) && $current_date > $deadline_date): ?> sa-overdue-ad <?php endif; ?>" value="<?php echo (!empty($ad_deadline) ? date_i18n(get_option('date_format'), strtotime($ad_deadline)) : ''); ?>" />
                                                                    <input type="hidden" name="deadline" value="<?php echo $ad_deadline; ?>" />
                                                                </div>
                                                                <span class="sa-input-message"><?php echo __('Default:', 'aparg-smartad') . ' ' . __('each reload', 'aparg-smartad') ?></span>
                                                            </li>
                                                            <li class="sa-form-item sa-ad-usual-input">
                                                                <?php
                                                                $restrict_views = isset($ad_options[$ad_id]['restrict_views']) ? $ad_options[$ad_id]['restrict_views'] : "";
                                                                ?>
                                                                <span><?php _e('Max Views', 'aparg-smartad') ?></span>
                                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Number of views after which the ad will be automatically suspended', 'aparg-smartad') ?>"></span>
                                                                <div class="sa-input-block">
                                                                    <input type="text" class="sa-positive-int <?php if (!empty($restrict_views) && $views_count > $restrict_views): ?> sa-overdue-ad <?php endif; ?>" name="restrict_views" value="<?php echo $restrict_views; ?>" />
                                                                </div>
                                                                <span class="sa-input-message"><?php echo __('Default:', 'aparg-smartad') . ' ' . __('no restrict', 'aparg-smartad') ?></span>
                                                            </li>
                                                            <li class="sa-form-item sa-ad-usual-input">
                                                                <?php
                                                                $restrict_visits = isset($ad_options[$ad_id]['restrict_visits']) ? $ad_options[$ad_id]['restrict_visits'] : "";
                                                                ?>
                                                                <span><?php _e('Max Clicks', 'aparg-smartad') ?></span>
                                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Number of clicks after which the ad will be automatically suspended', 'aparg-smartad') ?>"></span>
                                                                <div class="sa-input-block">
                                                                    <input type="text" class="sa-positive-int <?php if (!empty($restrict_visits) && $visits_count > $restrict_visits): ?> sa-overdue-ad <?php endif; ?>" name="restrict_visits" value="<?php echo $restrict_visits; ?>" />
                                                                </div>
                                                                <span class="sa-input-message"><?php echo __('Default:', 'aparg-smartad') . ' ' . __('no restrict', 'aparg-smartad') ?></span>
                                                            </li>
                                                            <li class="sa-form-item sa-ad-file-input">
                                                                <?php if ($campaign_ad['type'] == 'image'): ?>
                                                                    <span><?php _e('Image file', 'aparg-smartad') ?></span>
                                                                    <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Path to image', 'aparg-smartad') ?>"></span>
                                                                    <div class="sa-input-block">
                                                                        <div class="sa-upload-wrap">
                                                                            <button type="button" class="sa-upload-file button" data-sa-file-type="image"><?php _e('Choose', 'aparg-smartad') ?></button>
                                                                        </div>
                                                                        <div class="sa-upload-input-wrap">
                                                                            <input type="text" class="sa-hold-ad-content" name="ad_content" value="<?php echo isset($ad_options[$ad_id]['ad_content']) ? $ad_options[$ad_id]['ad_content'] : ""; ?>" />
                                                                        </div>
                                                                    </div>
                                                                    <span class="sa-input-message"></span>
                                                                <?php elseif ($campaign_ad['type'] == 'flash'): ?>
                                                                    <span><?php _e('SWF File', 'aparg-smartad') ?></span>
                                                                    <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Path to SWF file', 'aparg-smartad') ?>"></span>
                                                                    <div class="sa-input-block">
                                                                        <div class="sa-upload-wrap">
                                                                            <button type="button" class="sa-upload-file button" data-sa-file-type="application"><?php _e('Choose', 'aparg-smartad') ?></button>
                                                                        </div>
                                                                        <div class="sa-upload-input-wrap">
                                                                            <input type="text" class="sa-hold-ad-content" name="ad_content" value="<?php echo isset($ad_options[$ad_id]['ad_content']) ? $ad_options[$ad_id]['ad_content'] : ""; ?>" />
                                                                        </div>
                                                                    </div>
                                                                    <span class="sa-input-message"></span>
                                                                <?php elseif ($campaign_ad['type'] == 'video'): ?>
                                                                    <?php
                                                                    $url_data = isset($ad_options[$ad_id]['ad_content']) ? json_decode($ad_options[$ad_id]['ad_content']) : "";
                                                                    $video_url = (!empty($url_data) ? $url_data->origin_url : '');
                                                                    ?>
                                                                    <span><?php _e('Youtube/Vimeo URL', 'aparg-smartad') ?></span>
                                                                    <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('URL of Youtube or Vimeo video', 'aparg-smartad') ?>"></span>
                                                                    <div class="sa-input-block">
                                                                        <input type="text" class="sa-hold-ad-content sa-video-url" name="ad_content" value="<?php echo $video_url ?>" />    
                                                                    </div>
                                                                    <span class="sa-input-message"></span>
                                                                <?php elseif ($campaign_ad['type'] == 'iframe'): ?>
                                                                    <span><?php _e('Source URL', 'aparg-smartad') ?></span>
                                                                    <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('URL of website to load', 'aparg-smartad') ?>"></span>
                                                                    <div class="sa-input-block">
                                                                        <input type="text" class="sa-hold-ad-content" name="ad_content" value="<?php echo isset($ad_options[$ad_id]['ad_content']) ? $ad_options[$ad_id]['ad_content'] : ""; ?>"" />    
                                                                    </div>
                                                                    <span class="sa-input-message"></span>
                                                                <?php elseif ($campaign_ad['type'] == 'html'): ?>
                                                                    <span><?php _e('HTML code', 'aparg-smartad') ?></span>
                                                                    <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Custom code', 'aparg-smartad') ?>"></span>
                                                                    <div class="sa-input-block sa-code-button">
                                                                        <input type="button" class="button sa-type-code" value="<?php _e('Enter', 'aparg-smartad') ?>" />
                                                                        <textarea class="sa-hold-ad-content sa-hold-code-content sa-hidden-textarea" name="ad_content"><?php echo isset($ad_options[$ad_id]['ad_content']) ? $ad_options[$ad_id]['ad_content'] : ""; ?></textarea>
                                                                    </div>
                                                                    <span class="sa-input-message"></span>
                                                                <?php endif; ?>
                                                            </li>                                                            
                                                        </ul>
                                                        <div class="sa-tags-inputs">
                                                            <span class="sa-tags-label"><?php _e('Include', 'aparg-smartad') ?></span>
                                                            <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message='<?php _e('Specify posts, pages, tags or categories where ad must be shown', 'aparg-smartad') ?>
                                                                  <br><br><span style="font-weight:900"><?php _e('Tag', 'aparg-smartad') ?> - <span style="color: #F0AD4E"><?php _e('Yellow', 'aparg-smartad') ?></span></span>
                                                                  <br><span style="font-weight:900"><?php _e('Category', 'aparg-smartad') ?> - <span style="color: #337AB7"><?php _e('Blue', 'aparg-smartad') ?></span></span>
                                                                  <br><span style="font-weight:900"><?php _e('Post', 'aparg-smartad') ?> - <span style="color: #D9534F"><?php _e('Red', 'aparg-smartad') ?></span></span>
                                                                  <br><span style="font-weight:900"><?php _e('Page', 'aparg-smartad') ?> - <span style="color: #5CB85C"><?php _e('Green', 'aparg-smartad') ?></span></span>'></span>
                                                            <div class="example sa-tags">
                                                                <input type="hidden" class="sa-tags-values" data-sa-tags-values="<?php echo isset($ad_options[$ad_id]["ad_include_tags"]) ? $ad_options[$ad_id]["ad_include_tags"] : ""; ?>" />
                                                                <div class="bs-example sa_tag_include">
                                                                    <input type="text" class="typeahead-auto"/>
                                                                </div>
                                                            </div>
                                                            <div class="sa-slide-cont">
                                                                <?php $ad_exclude_tags = isset($ad_options[$ad_id]["ad_exclude_tags"]) ? $ad_options[$ad_id]["ad_exclude_tags"] : "" ?>
                                                                <span class="sa-tags-label sa-action-name sa-slide-opener" data-sa-open-slide="<?php if (empty($ad_exclude_tags)): ?>false<?php else: ?>true<?php endif; ?>"><?php _e('Exclude', 'aparg-smartad') ?></span>
                                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message='<?php _e('Specify posts, pages, tags or categories where ad must be hidden', 'aparg-smartad') ?>
                                                                      <br><br><span style="font-weight:900"><?php _e('Tag', 'aparg-smartad') ?> - <span style="color: #F0AD4E"><?php _e('Yellow', 'aparg-smartad') ?></span></span>
                                                                      <br><span style="font-weight:900"><?php _e('Category', 'aparg-smartad') ?> - <span style="color: #337AB7"><?php _e('Blue', 'aparg-smartad') ?></span></span>
                                                                      <br><span style="font-weight:900"><?php _e('Post', 'aparg-smartad') ?> - <span style="color: #D9534F"><?php _e('Red', 'aparg-smartad') ?></span></span>
                                                                      <br><span style="font-weight:900"><?php _e('Page', 'aparg-smartad') ?> - <span style="color: #5CB85C"><?php _e('Green', 'aparg-smartad') ?></span></span>'></span>
                                                                <div class="example sa-tags sa-sliding-block" data-sa-open="<?php if (empty($ad_exclude_tags)): ?>false<?php else: ?>true<?php endif; ?>">
                                                                    <input type="hidden" class="sa-tags-values" data-sa-tags-values="<?php echo $ad_exclude_tags; ?>" />
                                                                    <div class="bs-example sa_tag_exclude">
                                                                        <input type="text" class="typeahead-auto"/>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                                <!-- Ad statistics by chart and table -->
                                                <div class="sa-slide-cont sa-ad-stat-cont sa-stat-cont">
                                                    <h3 class="sa-slide-opener sa-ad-stat-opener" data-sa-open-slide="false">
                                                        <span><?php _e('Statistics', 'aparg-smartad') ?></span>
                                                        <span class="sa-slide-open-pointer"></span>
                                                    </h3>
                                                    <div class="sa-sliding-block sa-range-stat" data-sa-open="false" >
                                                        <div class="sa-stat-filter">
                                                            <input type="text" class="sa-stat-from" placeholder="<?php _e('From', 'aparg-smartad') ?>" />
                                                            <span>-</span>
                                                            <input type="text" class="sa-stat-to" placeholder="<?php _e('To', 'aparg-smartad') ?>" />
                                                            <input type="button" class="button sa-get-statistics" value="<?php _e('Show', 'aparg-smartad') ?>" />
                                                            <div class="sa-export-single-stat sa-export-ad-stat">
                                                                <span class="sa-action-name sa-dash-export" title="<?php echo ucfirst(__('Export stats', 'aparg-smartad')) ?>"></span>
                                                            </div>
                                                        </div>
                                                        <div class="sa-stat-container sa-stat-block" data-sa-ad-id="<?php echo $ad_id; ?>" data-sa-ad-title="<?php echo $campaign_ad['title']; ?>"></div>
                                                    </div>    
                                                </div>
                                            </li>
                                            <?php
                                        }
                                    }
                                    ?>
                                </ul>
                            </div>
                            <div class="sa-campaign-settings">
                                <div class="sa-slide-cont sa-campaign-fate sa-campaign-part">
                                    <h3 class="sa-slide-opener" data-sa-open-slide="true">
                                        <span><?php _e('General', 'aparg-smartad') ?></span>
                                        <span class="sa-slide-open-pointer"></span>
                                    </h3>
                                    <div class="sa-sliding-block" data-sa-open="true">
                                        <ul>
                                            <?php if ($campaign['type'] == "embed"): ?>
                                                <li><span class="sa-dash-shortcode"><span><?php _e('Shortcode', 'aparg-smartad') ?></span> - <span class="sa-click-select"><?php echo '[smartad id="' . $campaign['id'] . '"]'; ?></span></span></li>
                                            <?php endif; ?>
                                            <ul class="sa-actions sa-campaign-actions">
                                                <?php if ($campaign['status'] == "active"): ?>
                                                    <li data-sa-action="suspended">
                                                        <span class="sa-action-name sa-dash-suspend"><?php _e('Suspend', 'aparg-smartad') ?></span>
                                                    </li>
                                                <?php elseif ($campaign['status'] == "suspended"): ?>
                                                    <li data-sa-action="active">
                                                        <span class="sa-action-name sa-dash-activate"><?php _e('Activate', 'aparg-smartad') ?></span>
                                                    </li>
                                                <?php endif; ?>
                                                <li data-sa-action="export" class="sa-export-camp-ads sa-export-range">
                                                    <span class="sa-action-name sa-dash-export"><?php _e('Export Campaign Stats', 'aparg-smartad') ?></span>
                                                </li>
                                                <li data-sa-action="delete">
                                                    <span class="sa-action-name sa-dash-delete"><?php _e('Delete', 'aparg-smartad') ?></span>
                                                </li>
                                                
                                            </ul>
                                        </ul> 
                                        <div class="sa-tags-inputs">
                                            <span class="sa-tags-label"><?php _e('Include', 'aparg-smartad') ?></span>
                                            <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message='<?php _e('Specify posts, pages, tags or categories where campaign must be shown', 'aparg-smartad') ?>
                                                  <br><br><span style="font-weight:900"><?php _e('Tag', 'aparg-smartad') ?> - <span style="color: #F0AD4E"><?php _e('Yellow', 'aparg-smartad') ?></span></span>
                                                  <br><span style="font-weight:900"><?php _e('Category', 'aparg-smartad') ?> - <span style="color: #337AB7"><?php _e('Blue', 'aparg-smartad') ?></span></span>
                                                  <br><span style="font-weight:900"><?php _e('Post', 'aparg-smartad') ?> - <span style="color: #D9534F"><?php _e('Red', 'aparg-smartad') ?></span></span>
                                                  <br><span style="font-weight:900"><?php _e('Page', 'aparg-smartad') ?> - <span style="color: #5CB85C"><?php _e('Green', 'aparg-smartad') ?></span></span>'></span>
                                            <div class="example sa-tags">
                                                <input type="hidden" class="sa-tags-values" data-sa-tags-values="<?php echo isset($camp_options[$camp_id]['camp_include_tags']) ? $camp_options[$camp_id]['camp_include_tags'] : ""; ?>" />
                                                <div class="bs-example sa_tag_include">
                                                    <input type="text" class="typeahead-auto"/>
                                                </div>
                                            </div>
                                            <div class="sa-slide-cont">
                                                <?php $camp_exclude_tags = isset($camp_options[$camp_id]["camp_exclude_tags"]) ? $camp_options[$camp_id]["camp_exclude_tags"] : "" ?>
                                                <span class="sa-tags-label sa-action-name sa-slide-opener" data-sa-open-slide="<?php if (empty($camp_exclude_tags)): ?>false<?php else: ?>true<?php endif; ?>"><?php _e('Exclude', 'aparg-smartad') ?></span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message='<?php _e('Specify posts, pages, tags or categories where campaign must be hidden', 'aparg-smartad') ?>
                                                      <br><br><span style="font-weight:900"><?php _e('Tag', 'aparg-smartad') ?> - <span style="color: #F0AD4E"><?php _e('Yellow', 'aparg-smartad') ?></span></span>
                                                      <br><span style="font-weight:900"><?php _e('Category', 'aparg-smartad') ?> - <span style="color: #337AB7"><?php _e('Blue', 'aparg-smartad') ?></span></span>
                                                      <br><span style="font-weight:900"><?php _e('Post', 'aparg-smartad') ?> - <span style="color: #D9534F"><?php _e('Red', 'aparg-smartad') ?></span></span>
                                                      <br><span style="font-weight:900"><?php _e('Page', 'aparg-smartad') ?> - <span style="color: #5CB85C"><?php _e('Green', 'aparg-smartad') ?></span></span>'></span>
                                                <div class="example sa-tags sa-sliding-block" data-sa-open="<?php if (empty($camp_exclude_tags)): ?>false<?php else: ?>true<?php endif; ?>">
                                                    <input type="hidden" class="sa-tags-values" data-sa-tags-values="<?php echo $camp_exclude_tags; ?>" />
                                                    <div class="bs-example sa_tag_exclude">
                                                        <input type="text" class="typeahead-auto"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="sa-save-camp-cont">
                                    <div class="sa-waiting-wrapper">
                                        <input type="button" class="button button-primary sa-save-campaign-options" sa-data-campaign-id="<?php echo $campaign['id']; ?>" value="<?php _e('Update', 'aparg-smartad') ?>" />
                                    </div>
                                </div>
                                <form class="sa-slide-cont sa-campaign-options-form sa-campaign-part"> 
                                    <h3 class="sa-slide-opener" data-sa-open-slide="false">
                                        <span><?php _e('Options', 'aparg-smartad') ?></span>
                                        <span class="sa-slide-open-pointer"></span>
                                    </h3>
                                    <ul class="sa-campaign-options sa-sliding-block" data-sa-open="false">
                                        <?php if ($campaign['type'] == "background"): ?>                                        
                                            <li class="sa-form-item">
                                                <span><?php _e('Change Interval', 'aparg-smartad') ?> </span>&nbsp;<span class="sa-no-cap">(<?php _e('s', 'aparg-smartad') ?>)</span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Interval between changing ads of the current campaign measured in seconds', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <input type="text" name="change_interval" class="sa-positive-int" value="<?php echo isset($camp_options[$camp_id]['change_interval']) ? $camp_options[$camp_id]['change_interval'] : ""; ?>" />
                                                </div>
                                                <span class="sa-input-message"><?php echo __('Default:', 'aparg-smartad') . ' ' . __('each reload', 'aparg-smartad') ?></span>
                                            </li>
                                            <li class="sa-form-item">
                                                <span><?php _e('Background Selector', 'aparg-smartad') ?></span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('CSS selector of the element to which background ad will be applied to', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <input type="text" name="background_selector" value="<?php echo isset($camp_options[$camp_id]['change_interval']) ? $camp_options[$camp_id]['background_selector'] : ""; ?>" />
                                                </div>
                                                <span class="sa-input-message"><?php _e('Default:', 'aparg-smartad') ?> body</span>
                                            </li>
                                            <li class="sa-form-item">
                                                <span><?php _e('Background Image Type', 'aparg-smartad') ?></span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Type of the background image', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <?php $bg_type = isset($camp_options[$camp_id]['background_type']) ? $camp_options[$camp_id]['background_type'] : ""; ?>
                                                    <select name="background_type">                                               
                                                        <option value="cover_bg"<?php if ($bg_type == 'cover_bg'): ?> selected="selected"<?php endif; ?>><?php _e('Cover', 'aparg-smartad') ?></option>
                                                        <option value="repeat_bg"<?php if ($bg_type == 'repeat_bg'): ?> selected="selected"<?php endif; ?>><?php _e('Repeat', 'aparg-smartad') ?></option>
                                                    </select>
                                                </div>
                                            </li>
                                            
                                            <li class="sa-form-item">
                                                <span><?php _e('Link Open Type', 'aparg-smartad') ?></span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Choose how to open the ad link', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <?php $link_type = isset($camp_options[$camp_id]['link_type']) ? $camp_options[$camp_id]['link_type'] : ""; ?>
                                                    <select name="link_type">                                               
                                                        <option value="_blank"<?php if ($link_type == '_blank'): ?> selected="selected"<?php endif; ?>><?php _e('New Tab', 'aparg-smartad') ?></option>
                                                        <option value="_self"<?php if ($link_type == '_self'): ?> selected="selected"<?php endif; ?>><?php _e('Self', 'aparg-smartad') ?></option>
                                                        <option value="_window"<?php if ($link_type == '_window'): ?> selected="selected"<?php endif; ?>><?php _e('New Window', 'aparg-smartad') ?></option>
                                                    </select>
                                                </div>
                                            </li>
                                            
                                        <?php elseif ($campaign['type'] == "popup"): ?>                                        
                                            <li class="sa-form-item">
                                                <span><?php _e('Change Interval', 'aparg-smartad') ?></span>&nbsp;<span class="sa-no-cap">(<?php _e('s', 'aparg-smartad') ?>)</span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Interval between changing ads of the current campaign measured in seconds', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <input type="text" name="change_interval" class="sa-positive-int" value="<?php echo isset($camp_options[$camp_id]['change_interval']) ? $camp_options[$camp_id]['change_interval'] : ""; ?>" />
                                                </div>
                                                <span class="sa-input-message"><?php echo __('Default:', 'aparg-smartad') . ' ' . __('each reload', 'aparg-smartad') ?></span>
                                            </li>
                                            <li class="sa-form-item">
                                                <span><?php _e('Show Interval', 'aparg-smartad') ?></span>&nbsp;<span class="sa-no-cap">(<?php _e('s', 'aparg-smartad') ?>)</span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Interval by the end of which the next ad will be shown measured in seconds', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <input type="text" name="view_interval" class="sa-positive-int" value="<?php echo isset($camp_options[$camp_id]['view_interval']) ? $camp_options[$camp_id]['view_interval'] : ""; ?>" />
                                                </div>
                                                <span class="sa-input-message"><?php echo __('Default:', 'aparg-smartad') . ' ' . __('each reload', 'aparg-smartad') ?></span>
                                            </li>
                                            <li class="sa-form-item">
                                                <span><?php _e('Popup Direction', 'aparg-smartad') ?></span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Direction of popup ad animation', 'aparg-smartad') ?>"></span>
                                                <?php $pop_directiom = isset($camp_options[$camp_id]['popup_direction']) ? $camp_options[$camp_id]['popup_direction'] : "" ?>
                                                <div class="sa-input-block">
                                                    <select name="popup_direction">
                                                        <?php foreach ($popup_directions as $key => $value): ?>                                                
                                                            <option value="<?php echo $key; ?>"<?php if ($key == $pop_directiom): ?> selected="selected"<?php endif; ?>><?php echo $value; ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </li>
                                            <li class="sa-form-item">
                                                <span><?php _e('Width', 'aparg-smartad') ?> </span>&nbsp;<span class="sa-no-cap">(px/%)</span></span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Width of the ad container element measured in both px and %', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <input type="text" name="width" class="sa-size" value="<?php echo isset($camp_options[$camp_id]['width']) ? $camp_options[$camp_id]['width'] : ""; ?>" />
                                                </div>
                                                <span class="sa-input-message"><?php _e('Default:', 'aparg-smartad') ?> 600px</span>
                                            </li>
                                            <li class="sa-form-item">
                                                <span><?php _e('Height', 'aparg-smartad') ?> </span>&nbsp;<span class="sa-no-cap">(px/%)</span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Height of the ad container element measured in both px and %', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <input type="text" name="height" class="sa-size" value="<?php echo isset($camp_options[$camp_id]['height']) ? $camp_options[$camp_id]['height'] : ""; ?>" />
                                                </div>
                                                <span class="sa-input-message"><?php _e('Default:', 'aparg-smartad') ?> 500px</span>
                                            </li>
                                            <li class="sa-form-item">
                                                <span><?php _e('Popup Show Delay', 'aparg-smartad') ?> </span>&nbsp;<span class="sa-no-cap">(<?php _e('s', 'aparg-smartad') ?>)</span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Delay of showing ad popup after page loaded measured in seconds', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <input type="text" class="sa-positive-int" name="view_after" value="<?php echo isset($camp_options[$camp_id]['view_after']) ? $camp_options[$camp_id]['view_after'] : ""; ?>" />
                                                </div>
                                                <span class="sa-input-message"><?php _e('Default:', 'aparg-smartad') ?> 0</span>
                                            </li>
                                            <li class="sa-form-item">
                                                <span><?php _e('Close Button Delay', 'aparg-smartad') ?> </span>&nbsp;<span class="sa-no-cap">(<?php _e('s', 'aparg-smartad') ?>)</span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Delay of showing close button after showing popup measured in seconds', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <input type="text" class="sa-positive-int" name="show_close_after" value="<?php echo isset($camp_options[$camp_id]['show_close_after']) ? $camp_options[$camp_id]['show_close_after'] : ""; ?>" />
                                                </div>
                                                <span class="sa-input-message"><?php _e('Default:', 'aparg-smartad') ?> 0</span>
                                            </li>
                                            <li class="sa-form-item">
                                                <span><?php _e('Popup Autoclose', 'aparg-smartad') ?> </span>&nbsp;<span class="sa-no-cap">(<?php _e('s', 'aparg-smartad') ?>)</span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Automatically close popup after given period of time measured in seconds', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <input type="text" class="sa-positive-int" name="hide_ad_after" value="<?php echo isset($camp_options[$camp_id]['hide_ad_after']) ? $camp_options[$camp_id]['hide_ad_after'] : ""; ?>" />
                                                </div>
                                                <span class="sa-input-message"><?php echo __('Default:', 'aparg-smartad') . ' ' . __('no autoclose', 'aparg-smartad') ?></span>
                                            </li>
                                            <li class="sa-form-item">
                                                <span><?php _e('Background Image Type', 'aparg-smartad') ?></span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Type of the background image', 'aparg-smartad') ?>"></span>
                                                <?php $bg_type = isset($camp_options[$camp_id]['background_type']) ? $camp_options[$camp_id]['background_type'] : "" ?>
                                                <div class="sa-input-block">
                                                    <select name="background_type">                                               
                                                        <option value="contain"<?php if ($bg_type == 'contain'): ?> selected="selected"<?php endif; ?>><?php _e('Contain', 'aparg-smartad') ?></option>
                                                        <option value="cover"<?php if ($bg_type == 'cover'): ?> selected="selected"<?php endif; ?>><?php _e('Cover', 'aparg-smartad') ?></option>
                                                    </select>
                                                </div>
                                            </li>
                                            
                                            <li class="sa-form-item">
                                                <span><?php _e('Link Open Type', 'aparg-smartad') ?></span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Choose how to open the ad link', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <?php $link_type = isset($camp_options[$camp_id]['link_type']) ? $camp_options[$camp_id]['link_type'] : ""; ?>
                                                    <select name="link_type">                                               
                                                        <option value="_blank"<?php if ($link_type == '_blank'): ?> selected="selected"<?php endif; ?>><?php _e('New Tab', 'aparg-smartad') ?></option>
                                                        <option value="_self"<?php if ($link_type == '_self'): ?> selected="selected"<?php endif; ?>><?php _e('Self', 'aparg-smartad') ?></option>
                                                        <option value="_window"<?php if ($link_type == '_window'): ?> selected="selected"<?php endif; ?>><?php _e('New Window', 'aparg-smartad') ?></option>
                                                    </select>
                                                </div>
                                            </li>
                                            
                                            <li class="sa-form-item">
                                                <?php $put_in_frame = isset($camp_options[$camp_id]['put_in_frame']) ? $camp_options[$camp_id]['put_in_frame'] : ""; ?>
                                                <?php $frame_color = isset($camp_options[$camp_id]['frame_color']) ? $camp_options[$camp_id]['frame_color'] : ""; ?>
                                                <div class="sa-input-block">
                                                    <span><?php _e('Put In Frame', 'aparg-smartad') ?></span>
                                                    <input type="checkbox" class="sa-pow-option" <?php if (!empty($put_in_frame)): ?> checked<?php endif; ?>/>
                                                    <input type="hidden" class="sa-hold-checkbox" name="put_in_frame"<?php if (!empty($put_in_frame)): ?> value="on"<?php endif; ?>>
                                                    <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Choose whether to wrap or not the ad popup into frame', 'aparg-smartad') ?>"></span>
                                                </div>
                                            </li>
                                            <li class="sa-form-item">
                                                <?php $put_in_frame = isset($camp_options[$camp_id]['put_in_frame']) ? $camp_options[$camp_id]['put_in_frame'] : ""; ?>
                                                <?php $frame_color = isset($camp_options[$camp_id]['frame_color']) ? $camp_options[$camp_id]['frame_color'] : ""; ?>
                                                <span><?php _e('Popup Color', 'aparg-smartad') ?></span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Choose the popup frame and the background color in HTML Hex format', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <input type="text" name="frame_color" class="sa-cheks-input sa-colorpicker"<?php echo empty($put_in_frame) ? " readonly" : ""; ?> value="<?php echo $frame_color; ?>">
                                                </div>
                                                <span class="sa-input-message"><?php _e('Default:', 'aparg-smartad') ?> #ffffff</span>
                                            </li>
                                            <li class="sa-form-item">
                                                <?php $show_link = isset($camp_options[$camp_id]['show_link']) ? $camp_options[$camp_id]['show_link'] : ""; ?>
                                                <?php $link_color = isset($camp_options[$camp_id]['link_color']) ? $camp_options[$camp_id]['link_color'] : ""; ?>
                                                <div class="sa-input-block">
                                                    <span><?php _e('Show Link', 'aparg-smartad') ?></span>
                                                    <input type="checkbox" class="sa-pow-option" <?php if (!empty($show_link)): ?> checked<?php endif; ?>/>
                                                    <input type="hidden" class="sa-hold-checkbox" name="show_link"<?php if (!empty($show_link)): ?> value="on"<?php endif; ?>>
                                                    <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Choose whether to show or not the ad link', 'aparg-smartad') ?>"></span>
                                                </div>
                                            </li>
                                            <li class="sa-form-item">
                                                <?php $show_link = isset($camp_options[$camp_id]['show_link']) ? $camp_options[$camp_id]['show_link'] : ""; ?>
                                                <?php $link_color = isset($camp_options[$camp_id]['link_color']) ? $camp_options[$camp_id]['link_color'] : ""; ?>
                                                <span><?php _e('Popup Header Color', 'aparg-smartad') ?></span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Choose the popup header color in HTML Hex format', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <input type="text" name="link_color" class="sa-cheks-input sa-colorpicker"<?php echo empty($show_link) ? " readonly" : ""; ?> value="<?php echo $link_color; ?>">
                                                </div>
                                                <span class="sa-input-message"><?php _e('Default:', 'aparg-smartad') ?> #ffffff</span>
                                            </li>
                                            <li class="sa-form-item">
                                                <?php $auto_play_video = isset($camp_options[$camp_id]['auto_play_video']) ? $camp_options[$camp_id]['auto_play_video'] : "" ?>
                                                <div class="sa-input-block">
                                                    <span><?php _e('Auto Play Video', 'aparg-smartad') ?></span>
                                                    <input type="checkbox" <?php if (!empty($auto_play_video)): ?> checked<?php endif; ?>/>
                                                    <input type="hidden" class="sa-hold-checkbox" name="auto_play_video"<?php if (!empty($auto_play_video)): ?> value="on"<?php endif; ?>>
                                                    <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Choose whether to automatically play ad video or not', 'aparg-smartad') ?>"></span>
                                                </div>
                                            </li>
                                            <li class="sa-form-item">
                                                <?php $gray_background = isset($camp_options[$camp_id]['gray_background']) ? $camp_options[$camp_id]['gray_background'] : "" ?>
                                                <div class="sa-input-block">
                                                    <span><?php _e('Gray Background', 'aparg-smartad') ?></span>
                                                    <input type="checkbox" <?php if (!empty($gray_background)): ?> checked<?php endif; ?>/>
                                                    <input type="hidden" class="sa-hold-checkbox" name="gray_background"<?php if (!empty($gray_background)): ?> value="on"<?php endif; ?>>
                                                    <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Choose whether to add fullscreen gray overlay under the ad popup or not', 'aparg-smartad') ?>"></span>
                                                </div>
                                            </li>
                                        <?php elseif ($campaign['type'] == "embed"): ?>                                        
                                            <li class="sa-form-item">
                                                <span><?php _e('Change Interval', 'aparg-smartad') ?> </span>&nbsp;<span class="sa-no-cap">(<?php _e('s', 'aparg-smartad') ?>)</span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Interval between changing ads of the current campaign measured in seconds', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <input type="text" name="change_interval" class="sa-positive-int" value="<?php echo isset($camp_options[$camp_id]['change_interval']) ? $camp_options[$camp_id]['change_interval'] : ""; ?>" />
                                                </div>
                                                <span class="sa-input-message"><?php echo __('Default:', 'aparg-smartad') . ' ' . __('each reload', 'aparg-smartad') ?></span>
                                            </li>
                                            <li class="sa-form-item">
                                                <span><?php _e('Width', 'aparg-smartad') ?> </span>&nbsp;<span class="sa-no-cap">(px/%)</span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Width of the ad container element measured in both px and %', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <input type="text" name="width" class="sa-size" value="<?php echo isset($camp_options[$camp_id]['width']) ? $camp_options[$camp_id]['width'] : ""; ?>" />
                                                </div>
                                                <span class="sa-input-message"><?php _e('Default:', 'aparg-smartad') ?> 100%</span>
                                            </li>
                                            <li class="sa-form-item">
                                                <span><?php _e('Height', 'aparg-smartad') ?></span>&nbsp;<span class="sa-no-cap">(px)</span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Height of the ad container element measured in px', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <input type="text" name="height" class="sa-positive-int" value="<?php echo isset($camp_options[$camp_id]['height']) ? $camp_options[$camp_id]['height'] : ""; ?>" />
                                                </div>
                                                <span class="sa-input-message"><?php _e('Default:', 'aparg-smartad') ?> 100</span>
                                            </li>
                                            <li class="sa-form-item">
                                                <span><?php _e('Background Image Type', 'aparg-smartad') ?></span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Type of the background image', 'aparg-smartad') ?>"></span>
                                                <?php $bg_type = isset($camp_options[$camp_id]['background_type']) ? $camp_options[$camp_id]['background_type'] : "" ?>
                                                <div class="sa-input-block">
                                                    <select name="background_type">                                               
                                                        <option value="contain"<?php if ($bg_type == 'contain'): ?> selected="selected"<?php endif; ?>><?php _e('Contain', 'aparg-smartad') ?></option>
                                                        <option value="cover"<?php if ($bg_type == 'cover'): ?> selected="selected"<?php endif; ?>><?php _e('Cover', 'aparg-smartad') ?></option>
                                                    </select>
                                                </div>
                                            </li>
                                            
                                            <li class="sa-form-item">
                                                <span><?php _e('Link Open Type', 'aparg-smartad') ?></span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Choose how to open the ad link', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <?php $link_type = isset($camp_options[$camp_id]['link_type']) ? $camp_options[$camp_id]['link_type'] : ""; ?>
                                                    <select name="link_type">                                               
                                                        <option value="_blank"<?php if ($link_type == '_blank'): ?> selected="selected"<?php endif; ?>><?php _e('New Tab', 'aparg-smartad') ?></option>
                                                        <option value="_self"<?php if ($link_type == '_self'): ?> selected="selected"<?php endif; ?>><?php _e('Self', 'aparg-smartad') ?></option>
                                                        <option value="_window"<?php if ($link_type == '_window'): ?> selected="selected"<?php endif; ?>><?php _e('New Window', 'aparg-smartad') ?></option>
                                                    </select>
                                                </div>
                                            </li>
                                            
                                            <li class="sa-form-item">
                                                <?php $show_link = isset($camp_options[$camp_id]['show_link']) ? $camp_options[$camp_id]['show_link'] : ""; ?>
                                                <?php $link_color = isset($camp_options[$camp_id]['link_color']) ? $camp_options[$camp_id]['link_color'] : ""; ?>
                                                <div class="sa-input-block">
                                                    <span><?php _e('Show Link', 'aparg-smartad') ?></span>
                                                    <input type="checkbox" class="sa-pow-option" <?php if (!empty($show_link)): ?> checked<?php endif; ?>/>
                                                    <input type="hidden" class="sa-hold-checkbox" name="show_link"<?php if (!empty($show_link)): ?> value="on"<?php endif; ?>>
                                                    <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Choose whether to show or not the ad link', 'aparg-smartad') ?>"></span>
                                                </div>
                                            </li>
                                            <li class="sa-form-item">
                                                <?php $show_link = isset($camp_options[$camp_id]['show_link']) ? $camp_options[$camp_id]['show_link'] : ""; ?>
                                                <?php $link_color = isset($camp_options[$camp_id]['link_color']) ? $camp_options[$camp_id]['link_color'] : ""; ?>
                                                <span><?php _e('Link Color', 'aparg-smartad') ?></span>
                                                <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Choose the link color in HTML Hex format', 'aparg-smartad') ?>"></span>
                                                <div class="sa-input-block">
                                                    <input type="text" name="link_color" class="sa-cheks-input sa-colorpicker"<?php echo empty($show_link) ? " readonly" : ""; ?> value="<?php echo $link_color; ?>">
                                                </div>
                                                <span class="sa-input-message"><?php _e('Default:', 'aparg-smartad') ?> #808080</span>
                                            </li>
                                            <li class="sa-form-item">
                                                <?php $auto_play_video = isset($camp_options[$camp_id]['auto_play_video']) ? $camp_options[$camp_id]['auto_play_video'] : "" ?>
                                                <div class="sa-input-block">
                                                    <span><?php _e('Auto Play Video', 'aparg-smartad') ?></span>
                                                    <input type="checkbox" <?php if (!empty($auto_play_video)): ?> checked<?php endif; ?>/>
                                                    <input type="hidden" class="sa-hold-checkbox" name="auto_play_video"<?php if (!empty($auto_play_video)): ?> value="on"<?php endif; ?>>
                                                    <span class="sa-with-question" title="<?php echo ucfirst(__('Detailed description', 'aparg-smartad')) ?>" data-sa-message="<?php _e('Choose whether to automatically play ad video or not', 'aparg-smartad') ?>"></span>
                                                </div>
                                                <span class="sa-input-message"></span>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </form>   
                                <div class="sa-campaign-stat-cont sa-stat-cont sa-slide-cont sa-campaign-part">
                                    <h3 class="sa-slide-opener sa-camp-stat-opener" data-sa-open-slide="false">
                                        <span><?php _e('Statistics', 'aparg-smartad') ?></span>
                                        <span class="sa-slide-open-pointer"></span>
                                    </h3>
                                    <div class="sa-sliding-block" data-sa-open="false">
                                        <div class="sa-stat-filter">
                                            <input type="text" class="sa-stat-from" placeholder="<?php _e('From', 'aparg-smartad') ?>" />
                                            <span>-</span>
                                            <input type="text" class="sa-stat-to" placeholder="<?php _e('To', 'aparg-smartad') ?>" />
                                            <input type="button" class="button sa-get-statistics" value="<?php _e('Show', 'aparg-smartad') ?>" />                                    
                                            <div class="sa-export-single-stat sa-export-camp-stat">
                                                <span class="sa-action-name sa-dash-export" title="<?php _e('Export stats', 'aparg-smartad') ?>"></span>
                                            </div>
                                        </div>
                                        <div class="sa-campaign-stat sa-stat-block" data-sa-camp-id="<?php echo $campaign["id"]; ?>" data-sa-camp-title="<?php echo $campaign['name']; ?>"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <?php
                }
            }
            ?>
            <li class="sa-add-block sa-add-campaign">
                <span></span>
                <h3><?php _e('Add New Campaign', 'aparg-smartad') ?></h3>
            </li>
        </ul>
    </div>
    <?php
    echo '<script>var disableLeavepage = true;</script>';
}
