<?php

defined('ABSPATH') or die('No script kiddies please!');

/* version 1.0 -> version 1.1 -> version 1.2 */
if (get_option('sa_plugin_version') === FALSE) {
// migrate custom css
    $sa_custom_css = get_option('sa_custom_css');
    $sa_extra_options = get_option('sa_extra_options');
    if ($sa_custom_css !== FALSE && $sa_extra_options !== FALSE) {
        $sa_extra_options['sa_custom_css'] = stripslashes($sa_custom_css);
        update_option('sa_extra_options', $sa_extra_options);
        delete_option('sa_custom_css');
    }

// migrate embad campaigns height option, set int value
    $sa_campaigns = sa_get_campaigns();
    if (!empty($sa_campaigns)) {
        foreach ($sa_campaigns as $sa_campaign) {
            if ($sa_campaign['type'] == 'embed') {
                $sa_height_option_name = 'height';
                $height = sa_get_campaign_options($sa_campaign['id'], $sa_height_option_name);
                if ($height != '') {
                    $find = array("px", "%");
                    $replace = array("");
                    $height = str_replace($find, $replace, $height);
                    $sa_height_option = array($sa_height_option_name => $height);
                    sa_update_campaign_options($sa_campaign['id'], $sa_height_option);
                }
            }
            /* version 1.1 -> version 1.2 */
            // migrate popup campaigns popup-direction option and gray-background option
            if ($sa_campaign['type'] == 'popup') {
                $sa_option_name = 'popup_direction';
                $sa_popup_direction = sa_get_campaign_options($sa_campaign['id'], $sa_option_name);
                if ($sa_popup_direction != '') {
                    if ($sa_popup_direction == 'center')
                        $sa_popup_direction = 'fade';
                    if ($sa_popup_direction == 'left')
                        $sa_popup_direction = 'fadeLeftBig';
                    if ($sa_popup_direction == 'bottom')
                        $sa_popup_direction = 'fadeUpBig';
                    if ($sa_popup_direction == 'top')
                        $sa_popup_direction = 'fadeDownBig';
                    if ($sa_popup_direction == 'right')
                        $sa_popup_direction = 'fadeRightBig';
                    $sa_option_new_name = 'popup_animation';
                    $sa_popup_direction_option = array($sa_option_new_name => $sa_popup_direction);
                    sa_update_campaign_options($sa_campaign['id'], $sa_popup_direction_option);
                    sa_delete_campaign_option($sa_campaign['id'],$sa_option_name);
                }
                $sa_option_name = 'gray_background';
                $sa_popup_gray_background = sa_get_campaign_options($sa_campaign['id'], $sa_option_name);
                if ($sa_popup_gray_background == 'on')
                    $sa_popup_gray_background = 'gray';
                else
                    $sa_popup_gray_background = 'none';
                $sa_option_new_name = 'overlay_pattern';
                $sa_popup_overlay_pattern_option = array($sa_option_new_name => $sa_popup_gray_background);
                sa_update_campaign_options($sa_campaign['id'], $sa_popup_overlay_pattern_option);
                sa_delete_campaign_option($sa_campaign['id'],$sa_option_name);
            }
            /* version 1.1 -> version 1.2 */
        }
    }
    update_option('sa_plugin_version', '1.2');
}

if (get_option('sa_plugin_version') <= 1.3) {
    
}


/**
 * Db tabels updates write here
 */
if (get_option('sa_db_version') <= 1.1) {
    
}

