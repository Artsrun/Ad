<?php
defined('ABSPATH') or die('No script kiddies please!');
/**
 * Create widget "Smartad campaign"
 */
class Sa_campaign_Embed extends WP_Widget {

    /**
     * Register widget with WordPress.
     */
    function __construct() {
        parent::__construct(
                'sa_campaign', // Base ID
                'SmartAd', // Name
                array('description' => __('A widget that displays ads of embed campaign.', 'aparg-smartad') // Description
                ) // Args
        );
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget($args, $instance) {
        echo $args['before_widget'];
        if (!empty($instance['campaign_id'])) {
            echo do_shortcode("[smartad id='{$instance["campaign_id"]}' widget='1']");
        }
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     */
    public function form($instance) {
        // Get campaigns
        $campaigns = sa_get_campaigns();

        /** Separate campaigns type of embed */
        if (!empty($campaigns)) {
            foreach ($campaigns as $key => $campaign) {
                if ($campaign['type'] !== 'embed') {
                    unset($campaigns[$key]);
                }
            }
        }

        $campaign_id = !empty($instance['campaign_id']) ? $instance['campaign_id'] : 0;
        ?>
        <?php if (!empty($campaigns)): ?>
            <p>
                <label for="<?php echo $this->get_field_id('campaign_id'); ?>"><?php _e('Embed campaign'); ?>:</label>
                <select class="widefat" id="<?php echo $this->get_field_id('campaign_id'); ?>" name="<?php echo $this->get_field_name('campaign_id'); ?>">
                    <option value="0"><?php _e('Select campaign', 'aparg-smartad') ?></option>
                    <?php
                    foreach ($campaigns as $key => $campaign) {
                        ?>
                        <option value="<?php echo $campaign['id']; ?>"<?php if ($campaign['id'] == esc_attr($campaign_id)): ?> selected="selected"<?php endif; ?>><?php echo!empty($campaign['name']) ? $campaign['name'] : "No tiltle (id is " . $campaign['id'] . ")"; ?></option>
                        <?php
                    }
                    ?>
                </select>
            </p>            
        <?php else: ?>
            <p><?php _e('There is no campaign to select', 'aparg-smartad') ?></p> 
        <?php endif; ?>
        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['campaign_id'] = (!empty($new_instance['campaign_id']) ) ? strip_tags($new_instance['campaign_id']) : '';

        return $instance;
    }

}

// register Foo_Widget widget
function register_sa_campaign_embed() {
    register_widget('Sa_campaign_Embed');
}

add_action('widgets_init', 'register_sa_campaign_embed');
