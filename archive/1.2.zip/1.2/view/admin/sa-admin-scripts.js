/**
 * Display Success or Error message
 * 
 * @param str message_type
 * @param str message_text
 * @returns {undefined}
 */
function sa_action_message(message_type, message_text) {
    if (message_text === undefined) {
        message_text = message_type;
        if (message_text == "error") {
            message_text = "Error";
        } else if (message_text == "success") {
            message_text = "Success";
        }
    }

    //Determine message show time

    var message_length = message_text.length;
    var show_time = 70 * message_length;
    if (show_time < 2100) {
        show_time = 2100;
    }

    message_text = "<div>" + saFirstToUpperCase(message_text) + "</div>"

    message_text = jQuery(message_text);

    if (typeof message_time !== 'undefined') {
        clearTimeout(message_time);
    }
    jQuery("#sa-message-popup").removeClass("sa-error-message");
    jQuery("#sa-message-popup").removeClass("sa-success-message");
    jQuery("#sa-message-popup").removeClass("sa-confirm-message");
    jQuery("#sa-message-popup").removeClass("sa-transit-450");
    jQuery('#sa-message-popup').attr('data-sa-open', "false");

    jQuery("#sa-message-popup").find('p').empty();
    jQuery("#sa-message-popup").addClass("sa-" + message_type + "-message");
    jQuery("#sa-message-popup").find('p').html(message_text);
    jQuery('#sa-message-popup').attr('data-sa-open', "true");

    message_time = setTimeout(function () {
        jQuery('#sa-message-popup').attr('data-sa-open', "false");

        jQuery("#sa-message-popup").removeClass("sa-" + message_type + "-message");
    }, show_time);
}

function sa_confirm_click_message(dom_obj, message_text, confirm_title) {

    if (confirm_title === undefined || confirm_title === "") {
        confirm_title = "Confirm";
    }

    confirm_title = saFirstToUpperCase(confirm_title);

    jQuery("#sa-confirm-message").find(".sa-popup-title").text(confirm_title);
    jQuery("#sa-confirm-text").text(saFirstToUpperCase(message_text));
    jQuery("#sa-confirm-options").empty();
    confirm_dom = dom_obj;

    jQuery("#sa-confirm-options").append("<li class='sa-confirm-option' data-sa-confirm-option='1'><button class='button button-primary'>" + sa_admin_labels["confirm_yes"] + "</button></li>");
    jQuery("#sa-confirm-options").append("<li class='sa-confirm-option' data-sa-confirm-option='0'><button class='button button-primary'>" + sa_admin_labels["confirm_cancel"] + "</button></li>");

    jQuery('#sa-managing-overlay').fadeIn(150);
    jQuery('#sa-confirm-message').attr('data-sa-open', "true");
    jQuery('body').addClass('modal-open');
}

/**
 * Detect IE version
 * 
 * @returns {Boolean}
 */
function saIeVersion() {
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");
    if (msie > 0)  // If Internet Explorer, return version number
    {
        return parseInt(ua.substring(msie + 5, ua.indexOf(".", msie)));
    } else if (!!navigator.userAgent.match(/Trident.*rv\:11\./)) {
        return 11;
    }

    return false;
}

/**
 * Detect Safari
 * 
 * @returns {Boolean}
 */
function saIsSafari() {
    return /Version\/[\d\.]+.*Safari/.test(navigator.userAgent);
}

/**
 * Refresh ads priority numbers, for determine display order
 * 
 * @param object campaign_ads_block
 * @returns {undefined}
 */
function sa_refresh_ads_priority(campaign_ads_block) {
    var counter = 0;
    campaign_ads_block.find(".sa-ad-priority").each(function () {

        jQuery(this).val(counter);
        counter++;
    });
}

/**
 * Makes ads lists sortable
 * 
 * @returns {undefined}
 */
function sa_make_ads_sortable() {
    jQuery(".sa-sortable").sortable({
        axis: "y",
        items: "> .sa-ad-block",
        handle: '.sa-sort-mover',
        stop: function () {
            sa_refresh_ads_priority(jQuery(this));
        }
    });
}

/**
 * Make ad chart from statistics
 */
function saMakeAdChart(container, statistics, title) {
    /** Create statistics chart chart */
    jQuery(container).highcharts({
        exporting: {
            enabled: false
        },
        chart: {
            type: 'areaspline'
        },
        title: {
            text: sa_admin_labels['ad_stat_title']
        },
        subtitle: {
            text: title
        },
        legend: {
            layout: 'vertical',
            align: 'left',
            verticalAlign: 'top',
            x: 150,
            y: 100,
            floating: true,
            borderWidth: 1,
            backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
        },
        xAxis: {
            allowDecimals: false,
            categories: statistics["days"],
        },
        yAxis: {
            title: {
                text: sa_admin_labels["stat_count"]
            }
        },
        tooltip: {
            shared: true,
            valueSuffix: ''
        },
        credits: {
            enabled: false
        },
        colors: ['#27ae60', '#2980b9'],
        plotOptions: {
            areaspline: {
                fillOpacity: 0.5
            }
        },
        series: [{
                name: saFirstToUpperCase(sa_admin_labels['stat_view']),
                data: statistics["views"]
            }, {
                name: saFirstToUpperCase(sa_admin_labels['stat_visit']),
                data: statistics["visits"]
            }]
    });
}

/**
 * Make campaign chart from statistics
 */
function saMakeCampChart(container, statistics, title) {
    /** Create statistics chart */
    container.highcharts({
        exporting: {
            enabled: false
        },
        credits: {
            enabled: false
        },
        colors: ['#1abc9c', '#0073aa'],
        chart: {
            type: 'column'
        },
        title: {
            text: sa_admin_labels['camp_stat_title']
        },
        subtitle: {
            text: title
        },
        xAxis: {
            categories: statistics["ads"],
            crosshair: true
        },
        yAxis: {
            allowDecimals: false,
            min: 0,
            title: {
                text: sa_admin_labels["stat_count"]
            }
        },
        tooltip: {
            shared: true,
            useHTML: true
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [{
                name: saFirstToUpperCase(sa_admin_labels['stat_view']),
                data: statistics["views"]

            }, {
                name: saFirstToUpperCase(sa_admin_labels['stat_visit']),
                data: statistics["visits"]

            }]
    });
}

/**
 * Create statistics chart
 * 
 * @param object container
 * @returns {undefined}
 */
function saCreateAdChart(container, from, to, export_chart) {
    container.addClass("sa-stat-loading");
    if (from === undefined) {
        from = 0;
    }

    if (to === undefined) {
        to = 0;
    }

    var ad_id = container.attr("data-sa-ad-id");
    var ad_title = container.attr("data-sa-ad-title");
    /** Ajax request for get ad statistics */
    jQuery.ajax({
        type: "POST",
        url: ajax_url,
        dataType: "json",
        async: saIsSafari() ? false : true,
        data: {
            action: "sa_ajax_get_ad_statistics",
            ad_id: ad_id,
            from: from,
            to: to
        },
        success: function (statistics) {
            /** Create statistics chart chart */
            saMakeAdChart(container, statistics, ad_title);
            if (export_chart === true) {
                var doc = new jsPDF("l", "mm", "a4");

                var range_date = "";
                var from_date = container.closest('.sa-stat-cont').find(".sa-stat-from").val();
                var to_date = container.closest('.sa-stat-cont').find(".sa-stat-to").val();

                if (from_date != '' && to_date != '') {
                    range_date = '<span style="font-weight:bold;font-size:12px;">' + sa_admin_labels["stat_from_place"] + ' </span><span style="font-size:12px;">' + from_date + '</span><span style="font-weight:bold;font-size:12px;"> ' + sa_admin_labels["stat_to_place"] + ' </span> <span style="font-size:12px;">' + to_date + '</span>';
                } else if (from_date != '') {
                    range_date = '<span style="font-weight:bold;font-size:12px;">' + sa_admin_labels["stat_from_place"] + ' </span><span style="font-size:12px;">' + from_date + '</span>';
                } else if (to_date != '') {
                    range_date = '<span style="font-weight:bold;font-size:12px;">' + sa_admin_labels["stat_to_place"] + ' </span><span style="font-size:12px;">' + to_date + '</span>';
                }

                //loop through each chart
                var imageData = container.highcharts().createCanvas(range_date);

                doc.addImage(imageData, 'JPEG', 15, 15, 257, 170);

                //save with name
                doc.save('smartad-stats.pdf');
            }
        },
        error: function () {
            sa_action_message("error", sa_admin_labels["cant_get_stat_msg"]);
        }
    });
}

function saCreateCampChart(container, from, to, export_chart) {
    container.addClass("sa-stat-loading");

    if (from === undefined) {
        from = 0;
    }

    if (to === undefined) {
        to = 0;
    }

    var camp_id = container.attr("data-sa-camp-id");
    var camp_title = container.attr("data-sa-camp-title");
    /** Ajax request for get campaign statistics */
    jQuery.ajax({
        type: "POST",
        url: ajax_url,
        dataType: "json",
        async: saIsSafari() ? false : true,
        data: {
            action: "sa_ajax_get_camp_statistics",
            camp_id: camp_id,
            from: from,
            to: to
        },
        success: function (statistics) {
            saMakeCampChart(container, statistics, camp_title);
            if (export_chart === true) {
                var doc = new jsPDF("l", "mm", "a4");

                var range_date = "";
                var from_date = container.closest('.sa-stat-cont').find(".sa-stat-from").val();
                var to_date = container.closest('.sa-stat-cont').find(".sa-stat-to").val();

                if (from_date != '' && to_date != '') {
                    range_date = '<span style="font-weight:bold;font-size:12px;">' + sa_admin_labels["stat_from_place"] + ' </span><span style="font-size:12px;">' + from_date + '</span><span style="font-weight:bold;font-size:12px;"> ' + sa_admin_labels["stat_to_place"] + ' </span> <span style="font-size:12px;">' + to_date + '</span>';
                } else if (from_date != '') {
                    range_date = '<span style="font-weight:bold;font-size:12px;">' + sa_admin_labels["stat_from_place"] + ' </span><span style="font-size:12px;">' + from_date + '</span>';
                } else if (to_date != '') {
                    range_date = '<span style="font-weight:bold;font-size:12px;">' + sa_admin_labels["stat_to_place"] + ' </span><span style="font-size:12px;">' + to_date + '</span>';
                }

                //loop through each chart
                var imageData = container.highcharts().createCanvas(range_date);

                doc.addImage(imageData, 'JPEG', 15, 15, 257, 170);

                //save with name
                doc.save('smartad-stats.pdf');
            }
        },
        error: function () {
            sa_action_message("error", sa_admin_labels["cant_get_stat_msg"]);
        }
    });
}

/**
 * Jquery ui ad statistics range 
 * 
 * @returns {undefined}
 */
function saChartsDatepicker() {
    jQuery(".sa-stat-filter").each(function () {
        var range_cont = jQuery(this);
        range_cont.find(".sa-stat-from").datepicker({
            changeMonth: true,
            changeYear: true,
            dateFormat: sa_date_format,
            monthNames: sa_month_names,
            monthNamesShort: sa_month_short_names,
            dayNamesShort: sa_day_short_names,
            dayNamesMin: sa_day_short_names,
            dayNames: sa_day_names,
            firstDay: sa_start_of_week,
            onClose: function (selectedDate) {
                range_cont.find("sa-stat-to").datepicker("option", "minDate", selectedDate);
            },
            onSelect: function () {
                jQuery(this).closest(".sa-campaign-block").attr("data-sa-camp-changed", "1");
            }
        });
        range_cont.find(".sa-stat-to").datepicker({
            changeMonth: true,
            changeYear: true,
            dateFormat: sa_date_format,
            monthNames: sa_month_names,
            monthNamesShort: sa_month_short_names,
            dayNamesShort: sa_day_short_names,
            dayNamesMin: sa_day_short_names,
            dayNames: sa_day_names,
            firstDay: sa_start_of_week,
            onClose: function (selectedDate) {
                range_cont.find(".sa-stat-from").datepicker("option", "maxDate", selectedDate);
            },
            onSelect: function () {
                jQuery(this).closest(".sa-campaign-block").attr("data-sa-camp-changed", "1");
            }
        });
    });
}

/**
 * Set datepicker on input element
 * 
 * @param object dom_element
 * @returns {undefined}
 */
function saSetDatepicker(dom_element) {
    jQuery(dom_element).datepicker({
        dateFormat: sa_date_format,
        monthNames: sa_month_names,
        monthNamesShort: sa_month_short_names,
        dayNamesShort: sa_day_short_names,
        dayNamesMin: sa_day_short_names,
        dayNames: sa_day_names,
        firstDay: sa_start_of_week,
        changeMonth: true,
        changeYear: true,
        onSelect: function () {
            var wp_date = jQuery(this).datepicker('getDate');
            var date = jQuery.datepicker.formatDate("yy-mm-dd", wp_date);

            jQuery(this).next('[type="hidden"]').val(date);

            jQuery(this).closest(".sa-campaign-block").attr("data-sa-camp-changed", "1");
        }
    });
}

/**
 * Check if positive integer
 * 
 * @param val
 * @returns {Number|Boolean}
 */
function saIsPositiveInteger(val) {
    return val == "0" || ((val | 0) > 0 && val % 1 == 0);
}

/**
 * Check if valid block size
 * 
 * @param string val
 * @returns {Boolean}
 */
function saIsSize(val) {

    var px_index = val.lastIndexOf('px');
    var percent_index = val.lastIndexOf('%');

    var int_val = false;

    if (val.length > 2 && px_index == val.length - 2) {
        int_val = val.replace(/px$/, '');
    } else if (val.length > 1 && percent_index == val.length - 1) {
        int_val = val.replace(/%$/, '');
    } else {
        return false;
    }

    return saIsPositiveInteger(int_val);
}

/**
 * Check if string valid url
 * 
 * @param str val
 * @returns {Boolean}
 */
function saIsUrl(val) {
    var myRegExp = /^(?:(?:https?|ftp):\/\/)(?:\S+(?::\S*)?@)?(?:(?!10(?:\.\d{1,3}){3})(?!127(?:\.\d{1,3}){3})(?!169\.254(?:\.\d{1,3}){2})(?!192\.168(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]+-?)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]+-?)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/[^\s]*)?$/i;
    if (!myRegExp.test(val)) {
        return false;
    } else {
        return true;
    }
}

/**
 * Uppercase only first letter of string
 * @param str str
 * @returns str
 */
function saFirstToUpperCase(str) {
    return str.substr(0, 1).toUpperCase() + str.substr(1);
}

/**
 * Make tags input for campaign and ad specifing
 */
function saMakeBloodhound() {
    var autocomplete = new Bloodhound({
        datumTokenizer: Bloodhound.tokenizers.obj.whitespace('text'),
        queryTokenizer: Bloodhound.tokenizers.whitespace,
        remote: {
            url: ajax_url + '?action=sa_ajax_autocomplete&query=%QUERY',
            wildcard: '%QUERY'
        }
    });
    autocomplete.initialize();

    /**
     * Categorizing tags
     */
    elt = jQuery('.sa-tags > > .typeahead-auto');
    elt.tagsinput({
        tagClass: function (item) {
            switch (item.type) {
                case 'category'   :
                    return 'label label-primary';
                case 'post_tag':
                    return 'label label-warning label-important';
                case 'post':
                    return 'label label-danger';
                case 'page':
                    return 'label label-success';
            }
        },
        itemValue: 'value',
        itemText: 'text',
        typeaheadjs: [
            {
                hint: true,
                highlight: true,
                minLength: 2
            },
            {
                name: 'autocomplete',
                displayKey: 'text',
                limit: 200,
                source: autocomplete.ttAdapter(),
                templates: {
                    empty: [sa_admin_labels["no_result"]],
                    suggestion: function (data) {
                        return '<p>' + data.text + ' - <strong>' + saFirstToUpperCase(sa_admin_labels["tagsinput_" + data.type].replace('post_', '')) + '</strong></p>';
                    }
                }
            }
        ]
    });

// HACK: overrule hardcoded display inline-block of typeahead.js
    jQuery(".twitter-typeahead").css('display', 'inline');
}

/**
 * add colorpicker to color inputs
 */
function saSetColorPicker(selector) {
    jQuery(selector).ColorPicker({
        onChange: function (hsb, hex, rgb, el) {
            var el = jQuery(this).data('colorpicker').el
            jQuery(el).val('#' + hex);
        },
        onSubmit: function (hsb, hex, rgb, el) {
            jQuery(el).val('#' + hex);
            jQuery(el).ColorPickerHide();
        },
        onBeforeShow: function (el, a, b, c) {
            var el = jQuery(el).data('colorpicker').el;
            jQuery(el).select();
            var color = (jQuery.trim(this.value) == '') ? '#3A98C8 ' : this.value;
            jQuery(this).ColorPickerSetColor(color.replace('#', ''));
        }
    });
}

/**
 * Select inner text whwn clicked on element
 */
function saSelectAll(e) {
    if ("undefined" != typeof window.getSelection && "undefined" != typeof document.createRange) {
        var t = document.createRange();
        t.selectNodeContents(e);
        var i = window.getSelection();
        i.removeAllRanges(), i.addRange(t)
    } else if ("undefined" != typeof document.selection && "undefined" != typeof document.body.createTextRange) {
        var o = document.body.createTextRange();
        o.moveToElementText(e), o.select()
    }
}

/** Document ready actions */
jQuery(document).ready(function ($) {

    var ie_version = saIeVersion();

    (function (API) {
        API.myText = function (txt, options, x, y) {
            options = options || {};

            if (options.align == "center") {
                // Get current font size
                var fontSize = this.internal.getFontSize();

                // Get page width
                var pageWidth = this.internal.pageSize.width;

                // Get the actual text's width
                txtWidth = this.getStringUnitWidth(txt) * fontSize / this.internal.scaleFactor;

                // Calculate text's x coordinate
                x = (pageWidth - txtWidth) / 2;
            }

            // Draw text at x,y
            this.text(txt, x, y);
        }
    })(jsPDF.API);

    saMakeBloodhound();

    var code_area = document.getElementById("sa-code-area");

    var myCodeMirror = CodeMirror.fromTextArea(code_area, {
        lineNumbers: true,
        mode: "htmlmixed",
    });

    /** Triger click event after confirmation */
    $(document).on("click", ".sa-confirm-option", function () {
        if ($(this).attr("data-sa-confirm-option") == "1") {
            confirm_dom.addClass("sa-confirmated");
            confirm_dom.trigger("click");
            confirm_dom = undefined;
        }

        $('#sa-managing-overlay').fadeOut(150);
        $("#sa-confirm-message").attr("data-sa-open", "false");
        jQuery('body').removeClass('modal-open');
    });
    // Make sortable all ad blocks
    sa_make_ads_sortable();
    /*
     * Add file uploader from media library
     */
    
    $(document).on('click', '.sa-upload-file', function (e) {

        that_button = $(this);
        e.preventDefault();

        // Extend the wp.media object
        var searchType = that_button.attr('data-sa-file-type');
        if(searchType == 'application')
            searchType = searchType + '/x-shockwave-flash';
        else
            searchType = searchType + '/';
        var add_file_uploader = wp.media.frames.file_frame = wp.media({
            title: 'Choose file',
            button: {
                text: 'Choose file'
            },
            library: {type: searchType},
            multiple: false
        });

        // When a file is selected, grab required info about that file
        add_file_uploader.on('select', function () {
            var attachment = add_file_uploader.state().get('selection').first().toJSON();
            /** Check if required type of file choosen */
            
            if (attachment.type == that_button.attr('data-sa-file-type')) {
                if(attachment.type == 'application' && attachment.subtype != 'x-shockwave-flash'){
                    sa_action_message("error", sa_admin_labels["unc_type_of_file_msg"]);
                    return false;
                }
                var file_url = attachment.url;
                that_button.closest('.sa-form-item').find('.sa-hold-ad-content').val(file_url);
            } else {
                sa_action_message("error", sa_admin_labels["unc_type_of_file_msg"]);
            }
            return false;
        });
        add_file_uploader.on('close', function () {
            add_file_uploader.remove();           
        });
        // Open the uploader dialog
        add_file_uploader.open();
    });

    /**
     * Open popup for add campaign
     */
    camp_creation_process = false;
    $(document).on('click', '.sa-add-campaign', function () {

        // check if any campaign in creation process not open popup
        if (camp_creation_process == true) {
            return false;
        }

        var camp_types = {background: sa_admin_labels["camp_type_bg"], popup: sa_admin_labels["camp_type_popup"], embed: sa_admin_labels["camp_type_embed"]};

        $("#sa-campaign-types").empty();

        $.each(camp_types, function (camp_type, camp_name) {
            if ((camp_type == "popup" || camp_type == "background") && $('[data-sa-camp-type="' + camp_type + '"]').length >= 1) {
                return true;
            }

            $("#sa-campaign-types").append('<div class="sa-campaign-type-cont">\n\
                        <h4>' + camp_name + '</h4>\n\
                        <div class="sa-campaign-type sa-selection-block" data-sa-campaign-type="' + camp_type + '"><div></div></div>\n\
                    </div>');
        });

        $('#sa-managing-overlay').fadeIn(150);
        $('#sa-add-campaign-popup').attr('data-sa-open', "true");
        jQuery('body').addClass('modal-open');
    });

    /**
     * Select type
     */
    $(document).on("click", ".sa-selection-block", function () {

        $(".sa-selection-block").removeClass("sa-block-selected");
        $(this).addClass("sa-block-selected");
    });

    /**
     * Unselect type
     */
    $(document).on("click", ".sa-block-selected", function () {
        $(this).removeClass("sa-block-selected");
    });

    /**
     * Add campaign
     */
    $("#sa-campaign-save").click(function (e) {

        var campaign_type = $("#sa-campaign-types").find(".sa-block-selected").attr('data-sa-campaign-type');
        if (campaign_type === undefined) {

            /** Close popup and return */
            $('#sa-add-campaign-popup').attr('data-sa-open', "false");
            jQuery('body').removeClass('modal-open');
            $('#sa-managing-overlay').fadeOut(150);
            sa_action_message("error", sa_admin_labels["camp_choose_type_msg"]);
            return;
        }

        camp_creation_process = true;

        /** Ajax request for insert new campaign in db */
        $.ajax({
            type: "POST",
            url: ajax_url,
            dataType: "json",
            data: {
                action: "sa_ajax_new_campaign",
                type: campaign_type
            },
            success: function (response) {
                if (response["success"] != 1) {
                    // Error message
                    sa_action_message("error", sa_admin_labels["cant_add_camp_msg"]);

                    return false;
                }

                /** Add new campaign to list of campaigns */
                var campaign_id = response['campaign_id'];

                var campaign_options = '';
                var overlay_patterns = '';
                $.each(sa_effects['patterns'], function(key, value){
                    overlay_patterns += '<option value="' + key + '">' + key + '</option>';
                });
                /** Take appropriate options for choosen type */
                if (campaign_type == "background") {
                    campaign_options = '<li class="sa-form-item">\n\
                                                <span>' + sa_admin_labels["change_interval"] + '</span>&nbsp;<span class="sa-no-cap">(' + sa_admin_labels["second"] + ')</span>\n\
                                                <span class="sa-with-question" title="' + saFirstToUpperCase(saFirstToUpperCase(sa_admin_labels["detailed_description"])) + '" data-sa-message="' + sa_admin_labels["change_interval_desc"] + '"></span>\n\
                                                <div class="sa-input-block">\n\
                                                <input type="text" name="change_interval" class="sa-positive-int" value="" />\n\
                                                </div>\n\
                                                <span class="sa-input-message">' + sa_admin_labels["default"] + ' ' + sa_admin_labels["change_interval_def"] + '</span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["bg_selector"] + '</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["bg_selector_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <input type="text" name="background_selector" value="" />\n\
                                            </div>\n\
                                            <span class="sa-input-message">' + sa_admin_labels["default"] + ' ' + 'body</span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span ' + (typeof sa_new == 'undefined' ? 'class="sa-new">' : '>' ) + sa_admin_labels["bg_img_type"] + '</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["bg_img_type_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                                <select name="background_type">\n\
                                                    <option value="cover_bg">' + sa_admin_labels["cover"] + '</option>\n\
                                                    <option value="repeat_bg">' + sa_admin_labels["repeat"] + '</option>\n\
                                                    <option value="cover_bg_parallax">' + sa_admin_labels["cover"] + ' (Parallax)</option>\n\
                                                    <option value="repeat_bg_parallax">' + sa_admin_labels["repeat"] + ' (Parallax)</option>\n\
                                                </select>\n\
                                            </div>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span ' + (typeof sa_new == 'undefined' ? 'class="sa-new">' : '>' ) + sa_admin_labels["background_pattern"] + '</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["background_pattern_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <select name="background_pattern"><option value="none">None</option>' + overlay_patterns + '</select>\n\
                                            </div>\n\
                                            <span class="sa-input-message"></span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["open_link_type"] + '</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["open_link_type_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                                <select name="link_type">\n\
                                                    <option value="_blank">' + sa_admin_labels["open_link_type_blank"] + '</option>\n\
                                                    <option value="_self">' + sa_admin_labels["open_link_type_self"] + '</option>\n\
                                                    <option value="_window">' + sa_admin_labels["open_link_type_window"] + '</option>\n\
                                                </select>\n\
                                            </div>\n\
                                        </li>';
                } else if (campaign_type == "popup") {
                    var popup_effects = '';
                    $.each(sa_effects['popup'], function(key, value){
                        popup_effects += '<option value="' + key + '">' + key + '</option>';
                    });
                    campaign_options = '<li class="sa-form-item">\n\
                                                <span>' + sa_admin_labels["change_interval"] + ' </span>&nbsp;<span class="sa-no-cap">(' + sa_admin_labels["second"] + ')</span>\n\
                                                <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["change_interval_desc"] + '"></span>\n\
                                                <div class="sa-input-block">\n\
                                                <input type="text" name="change_interval" class="sa-positive-int" value="" />\n\
                                                </div>\n\
                                                <span class="sa-input-message">' + sa_admin_labels["default"] + ' ' + sa_admin_labels["change_interval_def"] + '</span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["show_interval"] + '</span>&nbsp;<span class="sa-no-cap">(' + sa_admin_labels["second"] + ')</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["show_interval_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <input type="text" class="sa-positive-int" name="view_interval" value="" />\n\
                                            </div>\n\
                                            <span class="sa-input-message">' + sa_admin_labels["default"] + ' ' + sa_admin_labels["show_interval_def"] + '</span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span ' + (typeof sa_new == 'undefined' ? 'class="sa-new">' : '>' ) + sa_admin_labels["popup_direction"] + '</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["popup_direction_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <select name="popup_animation">' + popup_effects + '</select>\n\
                                            </div>\n\
                                            <span class="sa-input-message"></span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["width"] + ' </span>&nbsp;<span class="sa-no-cap">(px/%)</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["width_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <input type="text" name="width" class="sa-size" />\n\
                                            </div>\n\
                                            <span class="sa-input-message">' + sa_admin_labels["default"] + ' 600px</span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["height"] + '</span>&nbsp;<span class="sa-no-cap">(px/%)</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["height_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <input type="text" name="height" class="sa-size" />\n\
                                            </div>\n\
                                            <span class="sa-input-message">' + sa_admin_labels["default"] + ' 500px</span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["popup_show_delay"] + ' </span>&nbsp;<span class="sa-no-cap">(' + sa_admin_labels["second"] + ')</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["popup_show_delay_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <input type="text" class="sa-positive-int" name="view_after" />\n\
                                            </div>\n\
                                            <span class="sa-input-message">' + sa_admin_labels["default"] + ' 0</span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["close_button_delay"] + ' </span>&nbsp;<span class="sa-no-cap">(' + sa_admin_labels["second"] + ')</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["close_button_delay_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <input type="text" class="sa-positive-int" name="show_close_after" />\n\
                                            </div>\n\
                                            <span class="sa-input-message">' + sa_admin_labels["default"] + ' 0</span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["popup_autoclose"] + ' </span>&nbsp;<span class="sa-no-cap">(' + sa_admin_labels["second"] + ')</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["popup_autoclose_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <input type="text" class="sa-positive-int" name="hide_ad_after" />\n\
                                            </div>\n\
                                            <span class="sa-input-message">' + sa_admin_labels["default"] + ' ' + sa_admin_labels["popup_autoclose_def"] + '</span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["bg_img_type"] + '</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["bg_img_type_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                                <select name="background_type">\n\
                                                    <option value="contain">' + sa_admin_labels["contain"] + '</option>\n\
                                                    <option value="cover">' + sa_admin_labels["cover"] + '</option>\n\
                                                </select>\n\
                                            </div>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span ' + (typeof sa_new == 'undefined' ? 'class="sa-new">' : '>' ) + sa_admin_labels["overlay_pattern"] + '</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["overlay_pattern_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <select name="overlay_pattern"><option value="none">None</option><option value="gray" selected="selected">Gray</option>' + overlay_patterns + '</select>\n\
                                            </div>\n\
                                            <span class="sa-input-message"></span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["open_link_type"] + '</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["open_link_type_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                                <select name="link_type">\n\
                                                    <option value="_blank">' + sa_admin_labels["open_link_type_blank"] + '</option>\n\
                                                    <option value="_self">' + sa_admin_labels["open_link_type_self"] + '</option>\n\
                                                    <option value="_window">' + sa_admin_labels["open_link_type_window"] + '</option>\n\
                                                </select>\n\
                                            </div>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <div class="sa-input-block">\n\
                                            <span>' + sa_admin_labels["put_in_frame"] + '</span>\n\
                                            <input type="checkbox" class="sa-pow-option" checked="checked" />\n\
                                            <input type="hidden" class="sa-hold-checkbox" name="put_in_frame" value="on" />\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["put_in_frame_desc"] + '"></span>\n\
                                            </div>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["popup_color"] + '</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["popup_color_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <input type="text" name="frame_color" class="sa-cheks-input sa-colorpicker" value="#ffffff">\n\
                                            </div>\n\
                                            <span class="sa-input-message">' + sa_admin_labels["default"] + ' #ffffff</span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <div class="sa-input-block">\n\
                                            <span>' + sa_admin_labels["show_link"] + '</span>\n\
                                            <input type="checkbox" class="sa-pow-option" checked="checked" />\n\
                                            <input type="hidden" class="sa-hold-checkbox" name="show_link" value="on" />\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["link_color_desc"] + '"></span>\n\
                                            </div>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["popup_header_color"] + '</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["popup_header_color_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <input type="text" name="link_color" class="sa-cheks-input sa-colorpicker" value="#ffffff">\n\
                                            </div>\n\
                                            <span class="sa-input-message">' + sa_admin_labels["default"] + ' #ffffff</span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <div class="sa-input-block">\n\
                                            <span>' + sa_admin_labels["auto_play_video"] + '</span>\n\
                                            <input type="checkbox" />\n\
                                            <input type="hidden" class="sa-hold-checkbox" name="auto_play_video">\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["auto_play_video_desc"] + '"></span>\n\
                                            </div>\n\
                                            <span class="sa-input-message"></span>\n\
                                        </li>';
                } else if (campaign_type == "embed") {
                    var embed_effects = '';
                    $.each(sa_effects['embed'], function(key, value){
                        embed_effects += '<option value="' + key + '">' + key + '</option>';
                    });
                    campaign_options = '<li class="sa-form-item">\n\
                                                <span>' + sa_admin_labels["change_interval"] + ' </span>&nbsp;<span class="sa-no-cap">(' + sa_admin_labels["second"] + ')</span>\n\
                                                <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["change_interval_desc"] + '"></span>\n\
                                                <div class="sa-input-block">\n\
                                                <input type="text" name="change_interval" class="sa-positive-int" value="" />\n\
                                                </div>\n\
                                                <span class="sa-input-message">' + sa_admin_labels["default"] + ' ' + sa_admin_labels["change_interval_def"] + '</span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span ' + (typeof sa_new == 'undefined' ? 'class="sa-new">' : '>' ) + sa_admin_labels["embed_direction"] + '</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["embed_direction_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <select name="embed_direction"><option value="none">None</option>' + embed_effects + '</select>\n\
                                            </div>\n\
                                            <span class="sa-input-message"></span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["width"] + ' </span>&nbsp;<span class="sa-no-cap">(px/%)</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["width_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <input type="text" name="width" class="sa-size" />\n\
                                            </div>\n\
                                            <span class="sa-input-message">' + sa_admin_labels["default"] + ' 100%</span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["height"] + ' </span>&nbsp;<span class="sa-no-cap">(px)</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["height_desc_px"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <input type="text" name="height" class="sa-positive-int" />\n\
                                            </div>\n\
                                            <span class="sa-input-message">Default 100</span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["bg_img_type"] + '</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["bg_img_type_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                                <select name="background_type">\n\
                                                    <option value="contain">' + sa_admin_labels["contain"] + '</option>\n\
                                                    <option value="cover">' + sa_admin_labels["cover"] + '</option>\n\
                                                </select>\n\
                                            </div>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["open_link_type"] + '</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["open_link_type_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                                <select name="link_type">\n\
                                                    <option value="_blank">' + sa_admin_labels["open_link_type_blank"] + '</option>\n\
                                                    <option value="_self">' + sa_admin_labels["open_link_type_self"] + '</option>\n\
                                                    <option value="_window">' + sa_admin_labels["open_link_type_window"] + '</option>\n\
                                                </select>\n\
                                            </div>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <div class="sa-input-block">\n\
                                            <span>' + sa_admin_labels["show_link"] + '</span>\n\
                                            <input type="checkbox" class="sa-pow-option" checked="checked" />\n\
                                            <input type="hidden" class="sa-hold-checkbox" name="show_link" value="on" />\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["show_link_desc"] + '"></span>\n\
                                            </div>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <span>' + sa_admin_labels["link_color"] + '</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["link_color_desc"] + '"></span>\n\
                                            <div class="sa-input-block">\n\
                                            <input type="text" name="link_color" class="sa-cheks-input sa-colorpicker" value="#808080">\n\
                                            </div>\n\
                                            <span class="sa-input-message">' + sa_admin_labels["default"] + ' #808080</span>\n\
                                        </li>\n\
                                        <li class="sa-form-item">\n\
                                            <div class="sa-input-block">\n\
                                            <span>' + sa_admin_labels["auto_play_video"] + '</span>\n\
                                            <input type="checkbox" />\n\
                                            <input type="hidden" class="sa-hold-checkbox" name="auto_play_video">\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="Choose Whether to automatically play ad video or not"></span>\n\
                                            </div>\n\
                                            <span class="sa-input-message"></span>\n\
                                        </li>';
                }

                /** Append campaign block(li) */
                var current_hum_date = response['creation_date'];
                var campaign_name = sa_admin_labels['camp_name_' + campaign_type] + " - (" + current_hum_date + ")";

                var camp_shortcode = "";
                if (campaign_type == "embed") {
                    camp_shortcode = '<li><span class="sa-dash-shortcode"><span>' + sa_admin_labels["shortcode"] + '</span> - <span class="sa-click-select">[smartad id="' + campaign_id + '"]</span></span></li>';
                }

                $('#sa-campaigns-block').prepend('<li class="sa-campaign-block sa-transit-150 sa-slide-cont" data-sa-camp-type="' + campaign_type + '" data-sa-status="suspended" data-sa-campaign-id="' + campaign_id + '" id="sa-campaign-block-' + campaign_id + '">\n\
                        <div class="sa-campaign-header sa-slide-opener" data-sa-open-slide="false">\n\
                            <div class="sa-campaign-type-logo" data-sa-campaign-type="' + campaign_type + '"></div>\n\
                            <div class="sa-camp-info">\n\
                                <input type="text" class="sa-suspended-input sa-campaign-name" value="' + campaign_name + '" />\n\
                                <p class="sa-dash-pub-date"><span>' + sa_admin_labels["creation_date"] + '</span>&nbsp;' + current_hum_date + '</p>\n\
                            </div>\n\
                            <span class="sa-campaign-status sa-camp-status-suspended">' + sa_admin_labels["status_suspended"] + '</span>\n\
                            <ul class="sa-camp-data">\n\
                                <li class="sa-views-count">\n\
                                    <div>0</div>\n\
                                    <div>' + sa_admin_labels["camp_views_count"] + '</div>\n\
                                </li>\n\
                                <li class="sa-visits-count sa-inside-data">\n\
                                    <div>0</div>\n\
                                    <div>' + sa_admin_labels["camp_clicks_count"] + '</div>\n\
                                </li>\n\
                                <li class="sa-ads-count">\n\
                                    <div>0</div>\n\
                                    <div>' + sa_admin_labels["camp_ads_count"] + '</div>\n\
                                </li>\n\
                            </ul>\n\
                            <span class="sa-slide-open-pointer"></span>\n\
                        </div>\n\
                        <div class="sa-campaign-content sa-sliding-block" data-sa-open="false">\n\
                            <div class="sa-campaign-ads">\n\
                                <div class="sa-ads-header">\n\
                                    <h3>' + sa_admin_labels["camp_ads"] + '</h3>\n\
                                    <ul class="sa-ads-filter">\n\
                                        <li data-sa-ad-filter="all">\n\
                                            <span class="sa-ad-status-name sa-selected-status">' + sa_admin_labels["filter_ad_all"] + '</span>\n\
                                            <span class="sa-status-count">0</span>\n\
                                        </li>\n\
                                        <li class="sa-inside-li" data-sa-ad-filter="active">\n\
                                            <span class="sa-ad-status-name">' + sa_admin_labels["filter_ad_active"] + '</span>\n\
                                            <span class="sa-status-count">0</span>\n\
                                        </li>\n\
                                        <li data-sa-ad-filter="suspended">\n\
                                            <span class="sa-ad-status-name">' + sa_admin_labels["filter_ad_suspended"] + '</span>\n\
                                            <span class="sa-status-count">0</span>\n\
                                        </li>\n\
                                    </ul>\n\
                                    <button class="button button-primary sa-add-ad" data-sa-campaign-id="' + campaign_id + '" data-sa-campaign-type="' + campaign_type + '">' + sa_admin_labels["add_new_ad"] + '</button>\n\
                                </div>\n\
                                <ul class="sa-ads-list sa-sortable">\n\
                                </ul>\n\
                            </div>\n\
                            <div class="sa-campaign-settings">\n\
                                <div class="sa-slide-cont sa-campaign-fate sa-campaign-part">\n\
                                    <h3 class="sa-slide-opener" data-sa-open-slide="true">\n\
                                        <span>' + sa_admin_labels["general"] + '</span>\n\
                                        <span class="sa-slide-open-pointer"></span>\n\
                                    </h3>\n\
                                    <div class="sa-sliding-block" data-sa-open="true">\n\
                                        <ul>' + camp_shortcode + '\n\
                                            <ul class="sa-actions sa-campaign-actions">\n\
                                                <li data-sa-action="active">\n\
                                                    <span class="sa-action-name sa-dash-activate">' + sa_admin_labels["activate_camp"] + '</span>\n\
                                                </li>\n\
                                                <li data-sa-action="export" class="sa-export-camp-ads sa-export-range">\n\
                                                    <span class="sa-action-name sa-dash-export">' + sa_admin_labels["export_campaign_Stats"] + '</span>\n\
                                                </li>\n\
                                                <li data-sa-action="delete">\n\
                                                    <span class="sa-action-name sa-dash-delete">' + sa_admin_labels["delete_camp"] + '</span>\n\
                                                </li>\n\
                                            </ul>\n\
                                        </ul>\n\
                                        <div class="sa-tags-inputs">\n\
                                            <span class="sa-tags-label">' + sa_admin_labels["include"] + '</span>\n\
                                            <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message=\'' + sa_admin_labels["include_camp_desc"] + '\n\
                                                                                                                            <br><br><span style=\"font-weight:900\">' + sa_admin_labels["specify_tag"] + ' - <span style=\"color: #F0AD4E\">' + sa_admin_labels["yellow"] + '</span></span>\n\
                                                                                                                            <br><span style=\"font-weight:900\">' + sa_admin_labels["specify_category"] + ' - <span style=\"color: #337AB7\">' + sa_admin_labels["blue"] + '</span></span>\n\
                                                                                                                            <br><span style=\"font-weight:900\">' + sa_admin_labels["specify_post"] + ' - <span style=\"color: #D9534F\">' + sa_admin_labels["red"] + '</span></span>\n\
                                                                                                                            <br><span style=\"font-weight:900\">' + sa_admin_labels["specify_page"] + ' - <span style=\"color: #5CB85C\">' + sa_admin_labels["green"] + '</span></span>\'></span>\n\
                                            <div class="example sa-tags">\n\
                                                <div class="bs-example sa_tag_include">\n\
                                                    <input type="text" class="typeahead-auto"/>\n\
                                                </div>\n\
                                            </div>\n\
                                            <div class="sa-slide-cont">\n\
                                                <span class="sa-tags-label sa-action-name sa-slide-opener" data-sa-open-slide="false">' + sa_admin_labels["exclude"] + '</span>\n\
                                                <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message=\'' + sa_admin_labels["exclude_camp_desc"] + '\n\
                                                                                                                            <br><br><span style=\"font-weight:900\">' + sa_admin_labels["specify_tag"] + ' - <span style=\"color: #F0AD4E\">' + sa_admin_labels["yellow"] + '</span></span>\n\
                                                                                                                            <br><span style=\"font-weight:900\">' + sa_admin_labels["specify_category"] + ' - <span style=\"color: #337AB7\">' + sa_admin_labels["blue"] + '</span></span>\n\
                                                                                                                            <br><span style=\"font-weight:900\">' + sa_admin_labels["specify_post"] + ' - <span style=\"color: #D9534F\">' + sa_admin_labels["red"] + '</span></span>\n\
                                                                                                                            <br><span style=\"font-weight:900\">' + sa_admin_labels["specify_page"] + ' - <span style=\"color: #5CB85C\">' + sa_admin_labels["green"] + '</span></span>\'></span>\n\
                                                <div class="example sa-tags sa-sliding-block" data-sa-open="false">\n\
                                                    <div class="bs-example sa_tag_exclude">\n\
                                                        <input type="text" class="typeahead-auto"/>\n\
                                                    </div>\n\
                                                </div>\n\
                                            </div>\n\
                                        </div>\n\
                                    </div>\n\
                                </div>\n\
                                <div class="sa-save-camp-cont">\n\
                                    <div class="sa-waiting-wrapper">\n\
                                        <input type="button" class="button button-primary sa-save-campaign-options" sa-data-campaign-id="' + campaign_id + '" value="' + sa_admin_labels["update_camp"] + '" />\n\
                                    </div>\n\
                                </div>\n\
                                <form class="sa-slide-cont sa-campaign-options-form sa-campaign-part"> \n\
                                    <h3 class="sa-slide-opener" data-sa-open-slide="false">\n\
                                        <span>' + sa_admin_labels["options"] + '</span>\n\
                                        <span class="sa-slide-open-pointer"></span>\n\
                                    </h3>\n\
                                    <ul class="sa-campaign-options sa-sliding-block" data-sa-open="false">' + campaign_options + '</ul>\n\
                                </form>\n\
                                <div class="sa-campaign-stat-cont sa-stat-cont sa-slide-cont sa-campaign-part">\n\
                                    <h3 class="sa-slide-opener sa-camp-stat-opener" data-sa-open-slide="false">\n\
                                        <span>' + sa_admin_labels["statistics_camp"] + '</span>\n\
                                        <span class="sa-slide-open-pointer"></span>\n\
                                    </h3>\n\
                                    <div class="sa-sliding-block" data-sa-open="false">\n\
                                        <div class="sa-stat-filter">\n\
                                            <input type="text" class="sa-stat-from" placeholder="' + sa_admin_labels["stat_from_place"] + '" />\n\
                                            <span>-</span>\n\
                                            <input type="text" class="sa-stat-to" placeholder="' + sa_admin_labels["stat_to_place"] + '" />\n\
                                            <input type="button" class="button sa-get-statistics" value="' + sa_admin_labels["stat_show"] + '" />\n\
                                            <div class="sa-export-single-stat sa-export-camp-stat">\n\
                                                <span class="sa-action-name sa-dash-export" title="' + saFirstToUpperCase(sa_admin_labels["export_stats"]) + '"></span>\n\
                                            </div>\n\
                                        </div>\n\
                                        <div class="sa-campaign-stat sa-stat-block" data-sa-camp-id="' + campaign_id + '" data-sa-camp-title="' + campaign_name + '"></div>\n\
                                    </div>\n\
                                </div>\n\
                            </div>\n\
                        </div>\n\
                    </li>');
                // Enhance all campaigns count
                var count = $("[data-sa-filter='all']").find(".sa-status-count").text();
                count++;
                $("[data-sa-filter='all']").find(".sa-status-count").text(count);
                // Enhance active campaigns count
                var count = $("[data-sa-filter='suspended']").find(".sa-status-count").text();
                count++;
                $("[data-sa-filter='suspended']").find(".sa-status-count").text(count);
                // Make sortable this child ads block
                sa_make_ads_sortable();

                saChartsDatepicker();

                saSetColorPicker('.sa-colorpicker');

                saMakeBloodhound();

                $("#sa-export-all").removeClass("sa-all-action-hidden");
                $("#sa-update-all").removeClass("sa-all-action-hidden");

                // Success message
                sa_action_message("success", sa_admin_labels["created_new_camp_msg"]);
            },
            error: function () {
                // Error message
                sa_action_message("error", sa_admin_labels["cant_add_camp_msg"]);
            },
            complete: function () {
                camp_creation_process = false;
            }
        });
        /** Close popup after save */
        $('#sa-add-campaign-popup').attr('data-sa-open', "false");
        jQuery('body').removeClass('modal-open');
        $('#sa-managing-overlay').fadeOut(150);
    });
    
    /**
     * Close popup
     */
    $(document).on('click', '#sa-managing-overlay, .sa-close-popup', function () {
        $('.sa-popup').attr('data-sa-open', "false");
        jQuery('body').removeClass('modal-open');
        $('#sa-managing-overlay').fadeOut(150);
    });

    /** Close popup with escape key */
    $(document).on('keyup', function (e) {

        if (e.keyCode === 27) {
            $('.sa-popup').attr('data-sa-open', "false");
            jQuery('body').removeClass('modal-open');
            $('#sa-managing-overlay').fadeOut(150);
        }
    });

    /**
     * Slide block open and close
     */
    $(document).on('click', '.sa-slide-opener', function () {
        if ($(this).hasClass("sa-campaign-header") && $(this).next('.sa-sliding-block').attr('data-sa-open') == 'false') {
            $(".sa-campaign-header").each(function () {
                if ($(this).attr("data-sa-open-slide") == "true") {
                    $(this).attr("data-sa-open-slide", "false");
                    $(this).siblings('.sa-sliding-block').attr('data-sa-open', "false");
                }
            });
            $(this).next('.sa-sliding-block').attr('data-sa-open', "true");
        } else {
            if ($(this).siblings('.sa-sliding-block').attr('data-sa-open') == 'false') {
                $(this).siblings('.sa-sliding-block').attr('data-sa-open', "true");
            } else {
                $(this).siblings('.sa-sliding-block').attr('data-sa-open', "false");
            }
        }

        $(this).attr("data-sa-open-slide", $(this).attr("data-sa-open-slide") == "false" ? "true" : "false");
    });

    /**
     * Save campaign options
     */
    $(document).on('click', '.sa-save-campaign-options', function (e) {
        $('.sa-deadline-date').each(function () {
            if ($(this).val() == '') {
                $(this).next('[type="hidden"]').val('');
            }
        });

        var that_button = $(this);

        // Display spinner
        that_button.closest(".sa-waiting-wrapper").addClass('sa-waiting-button');
        e.preventDefault();

        /** Check required fields */
        var is_error_exist = false;

        var camp_include_tags = $(this).closest(".sa-campaign-settings").find(".sa_tag_include").find(".typeahead-auto").val();

        var camp_exclude_tags = $(this).closest(".sa-campaign-settings").find(".sa_tag_exclude").find(".typeahead-auto").val();


        // check requireds
        $(this).closest('.sa-campaign-block').find('.sa-required').each(function () {
            if ($(this).val() == "") {
                $(this).addClass('sa-error-input');
                $(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message", $(this).closest('.sa-form-item').find('.sa-input-message').text());
                $(this).closest('.sa-form-item').find('.sa-input-message').addClass('sa-error-valid');
                $(this).closest('.sa-form-item').find('.sa-input-message').text(sa_admin_labels["required_filed_error"]);
                is_error_exist = true;
            } else {
                $(this).removeClass('sa-error-input');
                $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
            }
        });

        // Check links
        $(this).closest('.sa-campaign-block').find('.sa-link').each(function () {
            if ($(this).val() !== "") {
                if (!saIsUrl($(this).val())) {
                    $(this).addClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message", $(this).closest('.sa-form-item').find('.sa-input-message').text());
                    $(this).closest('.sa-form-item').find('.sa-input-message').addClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text(sa_admin_labels["valid_url_error"]);
                    is_error_exist = true;
                } else {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            } else {
                if (!$(this).hasClass("sa-required")) {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            }
        });

        // Check positive integers
        $(this).closest('.sa-campaign-block').find('.sa-positive-int').each(function () {
            if ($(this).val() !== "") {
                if (!saIsPositiveInteger($(this).val())) {
                    $(this).addClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message", $(this).closest('.sa-form-item').find('.sa-input-message').text());
                    $(this).closest('.sa-form-item').find('.sa-input-message').addClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text(sa_admin_labels["positive_int_error"]);
                    is_error_exist = true;
                } else {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            } else {
                if (!$(this).hasClass("sa-required")) {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            }
        });

        // Check size
        $(this).closest('.sa-campaign-block').find('.sa-size').each(function () {
            if ($(this).val() !== "") {
                if (!saIsSize($(this).val())) {
                    $(this).addClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message", $(this).closest('.sa-form-item').find('.sa-input-message').text());
                    $(this).closest('.sa-form-item').find('.sa-input-message').addClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text(sa_admin_labels["positive_int_error"] + ' ' + '(px/%)');
                    is_error_exist = true;
                } else {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            } else {
                if (!$(this).hasClass("sa-required")) {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            }
        });

        // Check video urls
        $("#sa-campaigns-block").find('.sa-video-url').each(function () {
            if ($(this).val() !== "") {
                var parsed_url = urlParser.parse($(this).val());
                if (parsed_url == undefined || (parsed_url['provider'] != 'youtube' && parsed_url['provider'] != 'vimeo')) {
                    $(this).addClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message", $(this).closest('.sa-form-item').find('.sa-input-message').text());
                    $(this).closest('.sa-form-item').find('.sa-input-message').addClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text(sa_admin_labels["valid_url_error"]);
                    is_error_exist = true;
                } else {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            } else {
                if (!$(this).hasClass("sa-required")) {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            }
        });

        if (is_error_exist == true) {
            that_button.closest(".sa-waiting-wrapper").removeClass('sa-waiting-button');
            sa_action_message("error", sa_admin_labels["check_form_req_msg"]);
            return false;
        }

        var campaign_name = $(this).closest('.sa-campaign-block').find(".sa-campaign-name").val();
        var campaign_options = $(this).closest('.sa-campaign-block').find('.sa-campaign-options-form').serializeArray();

        campaign_options.push({name: "camp_include_tags", value: camp_include_tags});
        campaign_options.push({name: "camp_exclude_tags", value: camp_exclude_tags});

        var campaign_id = $(this).attr('sa-data-campaign-id');

        /** Save new and update old ads */
        var closest_campaign = $(this).closest('.sa-campaign-block');
        var ads = new Array();
        closest_campaign.find('.sa-ad-form').each(function () {
            var ad_data = $(this).serializeArray();

            if (ad_data[4]['value'] == 'video' && ad_data[10]['value'] != '') {
                var origin_url = ad_data[10]['value'];
                var url_data = new Object;
                url_data['parsed'] = urlParser.parse(origin_url);
                url_data['origin_url'] = origin_url;
                ad_data[10]['value'] = JSON.stringify(url_data)
            }

            var ad_include_tags = $(this).find(".sa_tag_include").find(".typeahead-auto").val();
            var ad_exclude_tags = $(this).find(".sa_tag_exclude").find(".typeahead-auto").val();

            ad_data.push({name: "ad_include_tags", value: ad_include_tags});
            ad_data.push({name: "ad_exclude_tags", value: ad_exclude_tags});

            ads.push(ad_data);

            // check if ad overdue
            var current_date = new Date();
            current_date.setHours(0, 0, 0, 0);
            var ad_deadline = new Date(ad_data[7]['value']);

            if (current_date.getTime() > ad_deadline.getTime()) {
                $(this).find('.sa-deadline-date').addClass('sa-overdue-ad');
            } else {
                $(this).find('.sa-deadline-date').removeClass('sa-overdue-ad');
            }

            var views = $(this).find('.sa-views-count div').first().text();
            var restrict_views = ad_data[8]['value'];

            if (parseInt(views) > parseInt(restrict_views)) {
                $(this).find('[name="restrict_views"]').addClass('sa-overdue-ad');
            } else {
                $(this).find('[name="restrict_views"]').removeClass('sa-overdue-ad');
            }

            var visits = $(this).find('.sa-visits-count div').first().text();
            var restrict_visits = ad_data[9]['value'];

            if (parseInt(visits) > parseInt(restrict_visits)) {
                $(this).find('[name="restrict_visits"]').addClass('sa-overdue-ad');
            } else {
                $(this).find('[name="restrict_visits"]').removeClass('sa-overdue-ad');
            }
        });

        /** Ajax request for update campaign options */
        $.ajax({
            type: "POST",
            url: ajax_url,
            dataType: "json",
            data: {
                action: "sa_ajax_update_campaign_options",
                campaign_name: campaign_name,
                campaign_id: campaign_id,
                campaign_options: campaign_options,
                campaign_ads: ads
            },
            success: function (response) {
                if (response['success'] != 1) {
                    sa_action_message("error", sa_admin_labels["camp_not_saved_msg"]);
                    return false;
                }

                that_button.closest(".sa-campaign-block").attr("data-sa-camp-changed", "0");
                closest_campaign.find('.sa-ad-action').val('update');
                that_button.closest(".sa-waiting-wrapper").removeClass('sa-waiting-button');
                sa_action_message("success", sa_admin_labels["camp_saved_msg"]);
            },
            error: function () {
                that_button.closest(".sa-waiting-wrapper").removeClass('sa-waiting-button');
                sa_action_message("error", sa_admin_labels["camp_not_saved_msg"]);
            }
        });

        e.stopPropagation();
    });

    /**
     * Hold form checkbox item value into hidden input
     */
    $(document).on('change', 'form [type=checkbox]', function () {
        if ($(this).is(':checked')) {
            $(this).next('.sa-hold-checkbox').val('on');
        } else {
            $(this).next('.sa-hold-checkbox').val('');
        }
    });

    $(document).on('change', '.sa-pow-option', function () {
        if ($(this).is(':checked')) {
            $(this).parent(".sa-input-block").find(".sa-cheks-input").removeAttr("readonly");
        } else {
            $(this).parent(".sa-input-block").find(".sa-cheks-input").attr("readonly", "readonly");
        }
    });

    /**
     * Add new ad
     */
    $(document).on('click', '.sa-add-ad', function () {

        /** Append ad type blocks to ad types popup */
        var background_types = {image: sa_admin_labels["ad_type_image"]}
        var popup_types = {image: sa_admin_labels["ad_type_image"], video: sa_admin_labels["ad_type_video"], flash: sa_admin_labels["ad_type_flash"], html: sa_admin_labels["ad_type_html"], iframe: sa_admin_labels["ad_type_iframe"]};
        var embed_types = {image: sa_admin_labels["ad_type_image"], video: sa_admin_labels["ad_type_video"], flash: sa_admin_labels["ad_type_flash"], html: sa_admin_labels["ad_type_html"], iframe: sa_admin_labels["ad_type_iframe"]};
        // Create ad type object
        var ad_type = {background: background_types, popup: popup_types, embed: embed_types};
        // Get current campaign type
        var campaign_type = $(this).attr('data-sa-campaign-type');
        // Get ad campaign id
        var campaign_id = $(this).attr('data-sa-campaign-id');
        // Separate appropriate types        
        var required_types = ad_type[campaign_type];
        // Append blocks

        $('#sa-ad-types').empty();
        $.each(required_types, function (type_key, type_name) {
            {
                $('#sa-ad-types').append('<div class="sa-ad-type-cont">\n\
                                      <h4>' + type_name + '</h4>\n\
                                    <div class="sa-ad-type sa-selection-block" data-sa-ad-type="' + type_key + '">\n\
                                    <div></div>\n\
                                    </div>\n\
                                    </div>');
            }
        })

        /** Display popup */
        $('#sa-managing-overlay').fadeIn(150);
        $('#sa-add-ad-popup').attr('data-sa-open', "true");
        jQuery('body').addClass('modal-open');
        $('#sa-add-ad-popup').attr('data-sa-type-for', campaign_id);
    });

    /**
     * Choose ad type and save in db, after save display ad block
     */
    $(document).on('click', '#sa-ad-save', function () {

        var ad_type = $("#sa-ad-types").find(".sa-block-selected").attr('data-sa-ad-type');
        if (ad_type === undefined) {

            /** Close popup after choose */
            $('#sa-add-ad-popup').attr('data-sa-open', "false");
            jQuery('body').removeClass('modal-open');
            $('#sa-managing-overlay').fadeOut(150);
            sa_action_message("error", sa_admin_labels["ad_choose_type_msg"]);
            return;
        }

        var campaign_id = $('#sa-add-ad-popup').attr('data-sa-type-for');
        /** Ajax request for ad add in db */
        $.ajax({
            type: "POST",
            url: ajax_url,
            dataType: "json",
            data: {
                action: "sa_ajax_add_ad",
                type: ad_type,
                campaign_id: campaign_id,
            },
            success: function (response) {

                if (response['success'] != 1) {
                    sa_action_message("error", sa_admin_labels["cant_add_ad_msg"]);
                    return false;
                }

                var ad_id = response['ad_id'];

                /** Add file input form item */
                var ad_block_file = "";

                /** Determin default ad name */
                var current_hum_date = response['creation_date'];

                var ad_title = sa_admin_labels["ad_name_" + ad_type] + " - (" + current_hum_date + ")";


                if (ad_type == "image") {
                    ad_block_file = '<li class="sa-form-item sa-ad-file-input">\n\
                                        <span>' + sa_admin_labels["image_file"] + '</span>\n\
                                        <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["image_file_desc"] + '"></span>\n\
                                        <div class="sa-input-block">\n\
                                        <div class="sa-upload-wrap">\n\
                                        <button type="button" class="sa-upload-file button" data-sa-file-type="image">' + sa_admin_labels["choose_img_file"] + '</button>\n\
                                        </div>\n\
                                        <div class="sa-upload-input-wrap">\n\
                                        <input type="text" class="sa-hold-ad-content" name="ad_content" value="" />\n\
                                        </div>\n\
                                        </div>\n\
                                        <span class="sa-input-message"></span>\n\
                                    </li>';
                } else if (ad_type == "flash") {
                    ad_block_file = '<li class="sa-form-item sa-ad-file-input">\n\
                                        <span>' + sa_admin_labels["swf_file"] + '</span>\n\
                                        <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["swf_file_desc"] + '"></span>\n\
                                        <div class="sa-input-block">\n\
                                        <div class="sa-upload-wrap">\n\
                                        <button type="button" class="sa-upload-file button" data-sa-file-type="application">' + sa_admin_labels["choose_swf_file"] + '</button>\n\
                                        </div>\n\
                                        <div class="sa-upload-input-wrap">\n\
                                        <input type="text" class="sa-hold-ad-content" name="ad_content" value="" />\n\
                                        </div>\n\
                                        </div>\n\
                                        <span class="sa-input-message"></span>\n\
                                    </li>';
                } else if (ad_type == "video") {
                    ad_block_file = '<li class="sa-form-item sa-ad-file-input">\n\
                                        <span>' + sa_admin_labels["video_url"] + '</span>\n\
                                        <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["video_url_desc"] + '"></span>\n\
                                        <div class="sa-input-block">\n\
                                        <input type="text" class="sa-hold-ad-content sa-video-url" name="ad_content" value="" />\n\
                                        </div>\n\
                                        <span class="sa-input-message"></span>\n\
                                    </li>';
                } else if (ad_type == "iframe") {
                    ad_block_file = '<li class="sa-form-item sa-ad-file-input">\n\
                                        <span>' + sa_admin_labels["source_url"] + '</span>\n\
                                        <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["source_url_desc"] + '"></span>\n\
                                        <div class="sa-input-block">\n\
                                        <input type="text" class="sa-hold-ad-content" name="ad_content" value="" />\n\
                                        </div>\n\
                                        <span class="sa-input-message"></span>\n\
                                    </li>';
                } else if (ad_type == "html") {
                    ad_block_file = '<li class="sa-form-item sa-ad-file-input">\n\
                                        <span>' + sa_admin_labels["html_code"] + '</span>\n\
                                        <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["html_code_desc"] + '"></span>\n\
                                        <div class="sa-input-block sa-code-button">\n\
                                        <input type="button" class="button sa-type-code" value="' + sa_admin_labels["type_code"] + '" />\n\
                                        <textarea class="sa-hold-ad-content sa-hold-code-content sa-hidden-textarea" name="ad_content"></textarea>\n\
                                        </div>\n\
                                        <span class="sa-input-message"></span>\n\
                                    </li>';
                }


                var ad_block_html = '<li id="sa-ad-block-' + ad_id + '" class="sa-ad-block" data-sa-status="active" data-sa-ad-id="' + ad_id + '">\n\
                                        <form class="sa-ad-form">\n\
                                            <input type="hidden" name="action" class="sa-ad-action" value="update"/>\n\
                                            <input type="hidden" name="campaign_id" value="' + campaign_id + '"/>\n\
                                            <input type="hidden" name="priority" class="sa-ad-priority" />\n\
                                            <input type="hidden" name="ad_id" value="' + ad_id + '"/>\n\
                                            <div class="sa-ad-controls"><div class="sa-sort-mover" title="' + saFirstToUpperCase(sa_admin_labels["sort-mover-tile"]) + '"></div>\n\
                                                <ul class="sa-actions sa-ad-actions">\n\
                                                    <li data-sa-action="suspend" title="' + saFirstToUpperCase(sa_admin_labels["suspend_ad"]) + '">\n\
                                                        <span class="sa-action-name sa-dash-suspend"></span>\n\
                                                    </li>\n\
                                                    <li data-sa-action="delete" title="' + saFirstToUpperCase(sa_admin_labels["delete_ad"]) + '">\n\
                                                        <span class="sa-action-name sa-dash-delete"></span>\n\
                                                    </li>\n\
                                                </ul>\n\
                                                <div class="sa-ad-header">\n\
                                                    <div class="sa-ad-type-logo" data-sa-ad-type="' + ad_type + '">\n\
                                                        <input type="hidden" name="type" value="' + ad_type + '"/>\n\
                                                    </div>\n\
                                                    <div class="sa-ad-info">\n\
                                                        <input type="text" name="title" class="sa-suspended-input sa-ad-name" value="' + ad_title + '" title="' + ad_title + '" />\n\
                                                        <p class="sa-dash-pub-date"><span>' + sa_admin_labels["creation_date"] + '</span>&nbsp;' + current_hum_date + '</p>\n\
                                                    </div>\n\
                                                    <span class="sa-ad-status sa-ad-status-active">' + sa_admin_labels["status_active"].toLowerCase() + '</span>\n\
                                                    <ul class="sa-ad-data">\n\
                                                        <li class="sa-views-count">\n\
                                                            <div>0</div>\n\
                                                            <div>' + sa_admin_labels["ad_views_count"] + '</div>\n\
                                                        </li>\n\
                                                        <li class="sa-visits-count sa-inside-data">\n\
                                                            <div>0</div>\n\
                                                            <div>' + sa_admin_labels["ad_clicks_count"] + '</div>\n\
                                                        </li>\n\
                                                        <li class="sa-crt">\n\
                                                            <div>0</div>\n\
                                                            <div>' + sa_admin_labels["ad_ctr"] + '(%)</div>\n\
                                                        </li>\n\
                                                    </ul>\n\
                                                </div>\n\
                                                <ul class="sa-ad-options">\n\
                                                    <li class="sa-form-item sa-link-to">\n\
                                                        <span>' + sa_admin_labels["link_to"] + '</span>\n\
                                                        <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["link_to_desc"] + '"></span>\n\
                                                        <div class="sa-input-block">\n\
                                                        <input type="text" class="sa-link" name="link_to" />\n\
                                                        </div>\n\
                                                        <span class="sa-input-message"></span>\n\
                                                    </li>\n\
                                                    <li class="sa-form-item sa-ad-usual-input">\n\
                                                        <span>' + sa_admin_labels["deadline"] + '</span>\n\
                                                        <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["deadline_desc"] + '"></span>\n\
                                                        <div class="sa-input-block">\n\
                                                        <input type="text" class="sa-deadline-date" />\n\
                                                        <input type="hidden" name="deadline" />\n\
                                                        </div>\n\
                                                        <span class="sa-input-message">' + sa_admin_labels["default"] + ' ' + sa_admin_labels["deadline_def"] + '</span>\n\
                                                    </li>\n\
                                                    <li class="sa-form-item sa-ad-usual-input">\n\
                                                        <span>' + sa_admin_labels["max_views"] + '</span>\n\
                                                        <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["max_views_desc"] + '"></span>\n\
                                                        <div class="sa-input-block">\n\
                                                        <input type="text" class="sa-positive-int" name="restrict_views" />\n\
                                                        </div>\n\
                                                        <span class="sa-input-message">' + sa_admin_labels["default"] + ' ' + sa_admin_labels["max_views_def"] + '</span>\n\
                                                    </li>\n\
                                                    <li class="sa-form-item sa-ad-usual-input">\n\
                                                        <span>' + sa_admin_labels["max_clicks"] + '</span>\n\
                                                        <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message="' + sa_admin_labels["max_clicks_desc"] + '"></span>\n\
                                                        <div class="sa-input-block">\n\
                                                        <input type="text" class="sa-positive-int" name="restrict_visits" />\n\
                                                        </div>\n\
                                                        <span class="sa-input-message">' + sa_admin_labels["default"] + ' ' + sa_admin_labels["max_clicks_def"] + '</span>\n\
                                                    </li>\n\
                                                    ' + ad_block_file + '\n\
                                                </ul>\n\
                                                <div class="sa-tags-inputs">\n\
                                                    <span class="sa-tags-label">' + sa_admin_labels["include"] + '</span>\n\
                                                    <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message=\'' + sa_admin_labels["include_ad_desc"] + '\n\
                                                                                                                    <br><br><span style=\"font-weight:900\">' + sa_admin_labels["specify_tag"] + ' - <span style=\"color: #F0AD4E\">' + sa_admin_labels["yellow"] + '</span></span>\n\
                                                                                                                    <br><span style=\"font-weight:900\">' + sa_admin_labels["specify_category"] + ' - <span style=\"color: #337AB7\">' + sa_admin_labels["blue"] + '</span></span>\n\
                                                                                                                    <br><span style=\"font-weight:900\">' + sa_admin_labels["specify_post"] + ' - <span style=\"color: #D9534F\">' + sa_admin_labels["red"] + '</span></span>\n\
                                                                                                                    <br><span style=\"font-weight:900\">' + sa_admin_labels["specify_page"] + ' - <span style=\"color: #5CB85C\">' + sa_admin_labels["green"] + '</span></span>\'></span>\n\
                                                    <div class="example sa-tags">\n\
                                                        <div class="bs-example sa_tag_include">\n\
                                                            <input type="text" class="typeahead-auto"/>\n\
                                                        </div>\n\
                                                    </div>\n\
                                                    <div class="sa-slide-cont">\n\
                                                        <span class="sa-tags-label sa-action-name sa-slide-opener" data-sa-open-slide="false">' + sa_admin_labels["exclude"] + '</span>\n\
                                                        <span class="sa-with-question" title="' + saFirstToUpperCase(sa_admin_labels["detailed_description"]) + '" data-sa-message=\'' + sa_admin_labels["exclude_ad_desc"] + '\n\
                                                                                                                    <br><br><span style=\"font-weight:900\">' + sa_admin_labels["specify_tag"] + ' - <span style=\"color: #F0AD4E\">Yellow</span></span>\n\
                                                                                                                    <br><span style=\"font-weight:900\">' + sa_admin_labels["specify_category"] + ' - <span style=\"color: #337AB7\">Blue</span></span>\n\
                                                                                                                    <br><span style=\"font-weight:900\">' + sa_admin_labels["specify_post"] + ' - <span style=\"color: #D9534F\">Red</span></span>\n\
                                                                                                                    <br><span style=\"font-weight:900\">' + sa_admin_labels["specify_page"] + ' - <span style=\"color: #5CB85C\">Green</span></span>\'></span>\n\
                                                        <div class="example sa-tags sa-sliding-block" data-sa-open="false">\n\
                                                            <div class="bs-example sa_tag_exclude">\n\
                                                                <input type="text" class="typeahead-auto"/>\n\
                                                            </div>\n\
                                                        </div>\n\
                                                    </div>\n\
                                                </div>\n\
                                            </div>\n\
                                        </form>\n\
                                        <!-- Ad statistics by chart and table -->\n\
                                        <div class="sa-slide-cont sa-ad-stat-cont sa-stat-cont">\n\
                                            <h3 class="sa-slide-opener sa-ad-stat-opener" data-sa-open-slide="false">\n\
                                                <span>' + sa_admin_labels["Statistics_ad"] + '</span>\n\
                                                <span class="sa-slide-open-pointer"></span>\n\
                                            </h3>\n\
                                            <div class="sa-sliding-block sa-range-stat" data-sa-open="false" >\n\
                                                <div class="sa-stat-filter">\n\
                                                    <input type="text" class="sa-stat-from" placeholder="' + sa_admin_labels["stat_from_place"] + '" />\n\
                                                    <span>-</span>\n\
                                                    <input type="text" class="sa-stat-to" placeholder="' + sa_admin_labels["stat_to_place"] + '" />\n\
                                                    <input type="button" class="button sa-get-statistics" value="' + sa_admin_labels["stat_show"] + '" />\n\
                                                    <div class="sa-export-single-stat sa-export-ad-stat">\n\
                                                    <span class="sa-action-name sa-dash-export" title="' + saFirstToUpperCase(sa_admin_labels["export_stats"]) + '"></span>\n\
                                                    </div>\n\
                                                </div>\n\
                                                <div class="sa-stat-container sa-stat-block" data-sa-ad-id="' + ad_id + '" data-sa-ad-title="' + ad_title + '"></div>\n\
                                            </div>\n\
                                        </div>\n\
                                    </li>';

                $('#sa-campaign-block-' + campaign_id).find('.sa-ads-list').prepend(ad_block_html);

                // Set chart range datepicker
                saChartsDatepicker();
                // Set deadlines datepicker
                saSetDatepicker(".sa-deadline-date");

                sa_refresh_ads_priority($('#sa-campaign-block-' + campaign_id).find('.sa-campaign-ads'));

                var count = $('#sa-campaign-block-' + campaign_id).find("[data-sa-ad-filter='active']").find(".sa-status-count").text();
                count++;
                $('#sa-campaign-block-' + campaign_id).find("[data-sa-ad-filter='active']").find(".sa-status-count").text(count);

                var count = $('#sa-campaign-block-' + campaign_id).find("[data-sa-ad-filter='all']").find(".sa-status-count").text();
                count++;
                $('#sa-campaign-block-' + campaign_id).find("[data-sa-ad-filter='all']").find(".sa-status-count").text(count);

                var ads_count = $('#sa-campaign-block-' + campaign_id + ' .sa-ad-block').length;
                $('#sa-campaign-block-' + campaign_id + ' .sa-ads-count div:first-child').text(ads_count);

                saMakeBloodhound();

                sa_action_message("success", sa_admin_labels["created_new_ad_msg"]);
            },
            error: function () {
                sa_action_message("error", sa_admin_labels["cant_add_ad_msg"]);
            }
        });
        /** Close popup after choose */
        $('#sa-add-ad-popup').attr('data-sa-open', "false");
        jQuery('body').removeClass('modal-open');
        $('#sa-managing-overlay').fadeOut(150);
    });

    /**
     * Open popup for typing code for ad content, when clicked type code button
     */
    $(document).on('click', '.sa-type-code', function () {
        /** Append current ad code to popup textarea */
        var custom_code = $(this).closest('.sa-code-button').find('.sa-hold-code-content').val();
        myCodeMirror.setValue(custom_code);
        
        $('#sa-managing-overlay').fadeIn(150);
        $('#sa-code-popup').attr('data-sa-open', "true");
        jQuery('body').addClass('modal-open');
        if (jQuery('.sa-popup .CodeMirror').css('max-height') == '100%') {
            jQuery('.CodeMirror').height(window.innerHeight - jQuery('[data-sa-open="true"] .sa-popup-header').outerHeight(true) - jQuery('[data-sa-open="true"] .sa-popup-footer').outerHeight(true));
        } else {
            jQuery('.CodeMirror').attr('style', '');
        }
        myCodeMirror.refresh();
        custom_code_owner = $(this);
    });

    $(document).on('click', '#sa-save-code', function () {

        var custom_code = myCodeMirror.getValue();
        custom_code_owner.closest('.sa-code-button').find('.sa-hold-code-content').text(custom_code).trigger('change');

        /** Close popup */
        $('#sa-code-popup').attr('data-sa-open', "false");
        jQuery('body').removeClass('modal-open');
        $('#sa-managing-overlay').fadeOut(150);

    });

    /**
     * Filter campaigns by status
     */
    $('.sa-campaigns-filter li').on('click', function () {

        /** Change selected status */
        $('.sa-status-name').removeClass('sa-selected-status');
        $(this).find('.sa-status-name').addClass('sa-selected-status');
        var filter_by = $(this).attr('data-sa-filter');
        if (filter_by == "all") {
            $('.sa-campaign-block').removeClass('sa-campaign-hidden');
        } else {
            $('.sa-campaign-block').each(function () {
                if ($(this).attr('data-sa-status') == filter_by) {
                    $(this).removeClass('sa-campaign-hidden');
                } else {
                    $(this).addClass('sa-campaign-hidden');
                }
            });
        }
    });

    /**
     * campaign actions functionality
     */
    $(document).on('click', '.sa-campaign-actions li', function (e) {
        var campaign_action = $(this).attr('data-sa-action');
        var campaign_type = $(this).closest(".sa-campaign-block").attr("data-sa-camp-type");

        if (campaign_action == "export") {
            return false;
        }

        if (!$(this).hasClass("sa-confirmated") && campaign_action == "delete") {
            sa_confirm_click_message($(this), sa_admin_labels["confirm_del_camp"], sa_admin_labels["confirm_del_camp_title"]);
            return false;
        }

        var campaign_id = $(this).closest('.sa-campaign-block').attr('data-sa-campaign-id');
        var this_button = $(this);

        /** Ajax request for update campaign status or delete */
        $.ajax({
            type: "POST",
            url: ajax_url,
            dataType: "json",
            data: {
                action: "sa_ajax_update_campaign_status",
                campaign_id: campaign_id,
                campaign_action: campaign_action,
                campaign_type: campaign_type,
            },
            success: function (response) {
                if (response['success'] != 1) {
                    sa_action_message("error", sa_admin_labels["camp_action_err_msg"]);
                    return false;
                }

                if (campaign_action == "delete") {
                    // Get deleted campaign status
                    var campaign_status = $("#sa-campaign-block-" + campaign_id).attr("data-sa-status");

                    // Reduce current type status count
                    var count = $("[data-sa-filter='" + campaign_status + "']").find(".sa-status-count").text();
                    count--;
                    $("[data-sa-filter='" + campaign_status + "']").find(".sa-status-count").text(count);

                    // Reduce all campaigns count
                    var count = $("[data-sa-filter='all']").find(".sa-status-count").text();
                    count--;
                    $("[data-sa-filter='all']").find(".sa-status-count").text(count);
                    $("#sa-campaign-block-" + campaign_id).remove();

                    if ($(".sa-campaign-block").length == 0) {
                        $("#sa-export-all").addClass("sa-all-action-hidden");
                        $("#sa-update-all").addClass("sa-all-action-hidden");
                    }

                    sa_action_message("success", sa_admin_labels["camp_deleted_msg"]);
                } else {
                    var status_name;
                    $("#sa-campaign-block-" + campaign_id).attr("data-sa-status", campaign_action);
                    if (campaign_action == "active") {

                        this_button.find(".sa-action-name").removeClass("sa-dash-activate").addClass("sa-dash-suspend");

                        this_button.find('.sa-action-name').text(sa_admin_labels["suspend_camp"]);
                        this_button.attr("data-sa-action", "suspended");
                        var count = $("[data-sa-filter='active']").find(".sa-status-count").text();
                        count++;
                        $("[data-sa-filter='active']").find(".sa-status-count").text(count);
                        var count = $("[data-sa-filter='suspended']").find(".sa-status-count").text();
                        count--;
                        $("[data-sa-filter='suspended']").find(".sa-status-count").text(count);

                        status_name = sa_admin_labels["status_active"].toLowerCase();
                        sa_action_message("success", sa_admin_labels["camp_active_msg"]);
                    } else if (campaign_action == "suspended") {

                        this_button.find(".sa-action-name").removeClass("sa-dash-suspend").addClass("sa-dash-activate");

                        this_button.find('.sa-action-name').text(sa_admin_labels["activate_camp"]);
                        this_button.attr("data-sa-action", "active");
                        var count = $("[data-sa-filter='suspended']").find(".sa-status-count").text();
                        count++;
                        $("[data-sa-filter='suspended']").find(".sa-status-count").text(count);
                        var count = $("[data-sa-filter='active']").find(".sa-status-count").text();
                        count--;
                        $("[data-sa-filter='active']").find(".sa-status-count").text(count);

                        status_name = sa_admin_labels["status_suspended"];
                        sa_action_message("success", sa_admin_labels["camp_suspend_msg"]);
                    }

                    /** Also change status on header */
                    this_button.closest(".sa-campaign-block").find(".sa-campaign-status").text(status_name);
                    this_button.closest(".sa-campaign-block").find(".sa-campaign-status").removeClass("sa-camp-status-suspended sa-camp-status-active").addClass("sa-camp-status-" + campaign_action);
                    if ($(".sa-selected-status").closest("li").attr("data-sa-filter") !== "all") {
                        $("#sa-campaign-block-" + campaign_id).addClass('sa-campaign-hidden');
                    }
                }
            },
            error: function () {
                sa_action_message("error", sa_admin_labels["camp_action_err_msg"]);
            }
        });
        e.stopPropagation();
    });
    /**
     * Ad actions functionality
     */
    $(document).on('click', '.sa-ad-actions li', function () {

        var ad_id = $(this).closest('.sa-ad-block').attr('data-sa-ad-id');
        var this_button = $(this);
        var ads_block = $(this).closest(".sa-campaign-ads");
        if ($(this).attr("data-sa-action") == "delete") {
            if (!$(this).hasClass("sa-confirmated")) {
                sa_confirm_click_message($(this), sa_admin_labels["confirm_del_ad"], sa_admin_labels["confirm_del_ad_title"]);
                return false;
            }

            /** Ajax request for delete ad */
            $.ajax({
                type: "POST",
                url: ajax_url,
                dataType: "json",
                data: {
                    action: "sa_ajax_delete_ad",
                    ad_id: ad_id,
                },
                success: function (response) {
                    if (response['success'] != 1) {
                        sa_action_message('error', sa_admin_labels["ad_del_err_msg"]);
                        return false;
                    }

                    var ad_status = $("#sa-ad-block-" + ad_id).attr("data-sa-status");

                    var count = this_button.closest(".sa-campaign-block").find("[data-sa-ad-filter='" + ad_status + "']").find(".sa-status-count").text();
                    count--;
                    this_button.closest(".sa-campaign-block").find("[data-sa-ad-filter='" + ad_status + "']").find(".sa-status-count").text(count);
                    // Reduce all ads count
                    var count = this_button.closest(".sa-campaign-block").find("[data-sa-ad-filter='all']").find(".sa-status-count").text();
                    count--;
                    this_button.closest(".sa-campaign-block").find("[data-sa-ad-filter='all']").find(".sa-status-count").text(count);

                    var ads_count = this_button.closest(".sa-campaign-block").find('.sa-ad-block').length;
                    ads_count--;
                    this_button.closest(".sa-campaign-block").find('.sa-ads-count div:first-child').text(ads_count);

                    $("[data-sa-ad-id='" + ad_id + "']").remove();

                    sa_refresh_ads_priority(ads_block);
                    sa_action_message("success", sa_admin_labels["ad_del_msg"]);
                },
                error: function () {
                    sa_action_message('error', sa_admin_labels["ad_del_err_msg"]);
                }
            });
        } else {
            var status;
            if ($(this).attr("data-sa-action") == "activate") {
                status = "active";
            } else if ($(this).attr("data-sa-action") == "suspend") {
                status = "suspended";
            }

            /** Ajax request for update ad */
            $.ajax({
                type: "POST",
                url: ajax_url,
                dataType: "json",
                data: {
                    action: "sa_ajax_update_ad_status",
                    ad_id: ad_id,
                    status: status
                },
                success: function (response) {
                    if (response['success'] != 1) {
                        sa_action_message('error', sa_admin_labels["ad_action_err_msg"]);
                        return false;
                    }

                    if (this_button.attr("data-sa-action") == "activate") {
                        this_button.closest('.sa-ad-block').attr("data-sa-status", "active");
                        this_button.attr("data-sa-action", "suspend");
                        this_button.attr("title", sa_admin_labels["suspend_ad"]);
                        this_button.find(".sa-action-name").removeClass("sa-dash-activate").addClass("sa-dash-suspend");
                        this_button.closest(".sa-ad-controls").find(".sa-ad-status").text(sa_admin_labels["status_active"].toLowerCase());
                        this_button.closest(".sa-ad-controls").find(".sa-ad-status").removeClass("sa-ad-status-suspended").addClass("sa-ad-status-active");

                        var count = this_button.closest(".sa-campaign-block").find("[data-sa-ad-filter='active']").find(".sa-status-count").text();
                        count++;
                        this_button.closest(".sa-campaign-block").find("[data-sa-ad-filter='active']").find(".sa-status-count").text(count);
                        var count = this_button.closest(".sa-campaign-block").find("[data-sa-ad-filter='suspended']").find(".sa-status-count").text();
                        count--;
                        this_button.closest(".sa-campaign-block").find("[data-sa-ad-filter='suspended']").find(".sa-status-count").text(count);

                        sa_action_message('success', sa_admin_labels["ad_active_msg"]);
                    } else if (this_button.attr("data-sa-action") == "suspend") {
                        this_button.closest('.sa-ad-block').attr("data-sa-status", "suspended");
                        this_button.attr("data-sa-action", "activate");
                        this_button.attr("title", sa_admin_labels["activate_ad"]);
                        this_button.find(".sa-action-name").removeClass("sa-dash-suspend").addClass("sa-dash-activate");
                        this_button.closest(".sa-ad-controls").find(".sa-ad-status").text(sa_admin_labels["status_suspended"]);
                        this_button.closest(".sa-ad-controls").find(".sa-ad-status").removeClass("sa-ad-status-active").addClass("sa-ad-status-suspended");

                        var count = this_button.closest(".sa-campaign-block").find("[data-sa-ad-filter='suspended']").find(".sa-status-count").text();
                        count++;
                        this_button.closest(".sa-campaign-block").find("[data-sa-ad-filter='suspended']").find(".sa-status-count").text(count);
                        var count = this_button.closest(".sa-campaign-block").find("[data-sa-ad-filter='active']").find(".sa-status-count").text();
                        count--;
                        this_button.closest(".sa-campaign-block").find("[data-sa-ad-filter='active']").find(".sa-status-count").text(count);

                        sa_action_message('success', sa_admin_labels["ad_suspend_msg"]);
                    }
                },
                error: function () {
                    sa_action_message('error', sa_admin_labels["ad_action_err_msg"]);
                }
            });
        }
    });

    /*
     * Show a prompt before the user leaves the current page
     */
    $(".sa-sortable").on("sortstop", function () {
        $(this).closest(".sa-campaign-block").attr("data-sa-camp-changed", "1");
    });

    $(window).load(function () {
        $(document).on('change', 'input, textarea, select', function () {
            $(this).closest(".sa-campaign-block").attr("data-sa-camp-changed", "1");
        });
    });

    $(window).bind('beforeunload', function () {
        if ($("[data-sa-camp-changed = '1']").length > 0 && typeof disableLeavepage != 'undefined' && disableLeavepage == true) {
            return sa_admin_labels['unsaved_reload'];
        }
    });

    $(document).on('click', '.sa-camp-stat-opener', function () {
        saCreateCampChart($(this).parent('div').find(".sa-campaign-stat"));
        $(this).removeClass('sa-camp-stat-opener');
    });

    $(document).on('click', '.sa-ad-stat-opener', function () {
        saCreateAdChart($(this).parent('div').find(".sa-stat-container"));
        $(this).removeClass('sa-ad-stat-opener');
    });

    /** Add datpickers */
    saChartsDatepicker();

    /** Get ad statistics by days */
    $(document).on("click", ".sa-get-statistics", function () {
        var container = $(this).closest(".sa-stat-cont").find(".sa-stat-block");

        var from = jQuery.datepicker.formatDate("yy-mm-dd", $(this).closest(".sa-stat-filter").find(".sa-stat-from").datepicker('getDate'));
        var to = jQuery.datepicker.formatDate("yy-mm-dd", $(this).closest(".sa-stat-filter").find(".sa-stat-to").datepicker('getDate'));

        container.empty();

        if ($(this).closest('.sa-stat-cont').hasClass('sa-campaign-stat-cont')) {
            saCreateCampChart(container, from, to);
        } else if ($(this).closest('.sa-stat-cont').hasClass('sa-ad-stat-cont')) {
            saCreateAdChart(container, from, to);
        }
    });

    // Set deadlines datepicker
    saSetDatepicker(".sa-deadline-date");

    saSetColorPicker('.sa-colorpicker');

    // Click to campaign name stopPropagation
    $(document).on("click", ".sa-campaign-name", function (e) {
        e.stopPropagation();
    });

    /** Always kepp ad name on stat chart */
    $(document).on("keyup", ".sa-ad-name", function () {
        var ad_name = $(this).val();
        $(this).closest(".sa-ad-block").find(".highcharts-subtitle").text(ad_name);
        $(this).closest(".sa-ad-block").find(".sa-stat-container").attr("data-sa-ad-title", ad_name);
    });

    /** Update statistics chart when updated ad name, for refresh stat subtitle */
    $(document).on("change", ".sa-ad-name", function () {
        $(this).closest(".sa-ad-block").find(".sa-get-statistics").trigger("click");
    });

    /** Always kepp campaign name on stat chart */
    $(document).on("keyup", ".sa-campaign-name", function () {
        var campaign_name = $(this).val();
        $(this).closest(".sa-campaign-block").find('.sa-campaign-stat').find(".highcharts-subtitle").text(campaign_name);
        $(this).closest(".sa-campaign-block").find('.sa-campaign-stat').attr("data-sa-camp-title", campaign_name);
    });

    /** Update statistics chart when updated ad name, for refresh stat subtitle */
    $(document).on("change", ".sa-campaign-name", function () {
        $(this).closest(".sa-campaign-block").find('.sa-campaign-stat-cont').find(".sa-get-statistics").trigger("click");
    });

    /** create canvas function from highcharts */
    (function (H) {
        H.Chart.prototype.createCanvas = function (range) {
            var title = this.title.textStr + '<br /><span style="font-size:12px;">' + range + '</span>';
            var svg = this.getSVG({chart: {width: Math.ceil(3035 / 3), height: Math.ceil(2008 / 3)}, title: {text: title}});

            canvas = document.createElement('canvas');
            canvas.width = Math.ceil(3035 / 2);
            canvas.height = Math.ceil(2008 / 2);
            if (canvas.getContext && canvas.getContext('2d')) {

                canvg(canvas, svg, {
                    ignoreDimensions: true,
                    scaleWidth: canvas.width,
                    scaleHeight: canvas.height
                });

                return canvas.toDataURL("image/jpeg");

            } else {
                sa_action_message('error', sa_admin_labels["general_err_msg"]);
                return false;
            }

        }
    }(Highcharts));

    /**
     * Export camp ads stats or all camp ads stats
     */
    $(document).on("click", ".sa-export-range", function () {

        if (ie_version && ie_version <= 9) {
            sa_action_message("info", sa_admin_labels["update_browser"]);
            return false;
        }

        var camp_id = "";
        if ($(this).hasClass("sa-export-camp-ads")) {
            camp_id = $(this).closest('.sa-campaign-block').data('sa-campaign-id');
        } else if ($(this).hasClass("sa-export-all")) {
            if ($(".sa-campaign-block").length == 0) {
                sa_action_message("info", sa_admin_labels["no_camp_stat_msg"]);

                return false;
            }
            camp_id = "";
        }

        $("#sa-export-period-stats").attr("data-sa-campaign-id", camp_id);

        /** Display popup */
        $('#sa-export-range').find("input").val("");
        $('#sa-managing-overlay').fadeIn(150);
        $('#sa-export-range').attr('data-sa-open', "true");
        jQuery('body').addClass('modal-open');
    });

    $(document).on("click", "#sa-export-period-stats", function () {

        var camp_id = $(this).attr('data-sa-campaign-id');

        var from_date = $("#sa-export-range").find(".sa-stat-from").val();
        var to_date = $("#sa-export-range").find(".sa-stat-to").val();

        var from = jQuery.datepicker.formatDate("yy-mm-dd", $("#sa-export-range").find(".sa-stat-from").datepicker('getDate'));
        var to = jQuery.datepicker.formatDate("yy-mm-dd", $("#sa-export-range").find(".sa-stat-to").datepicker('getDate'));

        var that_button = $(this);
        // Display spinner
        $(this).closest(".sa-waiting-wrapper").addClass('sa-waiting-button');

        /** Ajax request for get campaign ads statistics */
        $.ajax({
            type: "POST",
            url: ajax_url,
            dataType: "json",
            async: saIsSafari() ? false : true,
            data: {
                action: "sa_ajax_get_ads_stat",
                camp_id: camp_id,
                from: from,
                to: to
            },
            success: function (camps_ads_statistics) {
                if (camps_ads_statistics == "" || camps_ads_statistics == undefined) {
                    /** Hide popup */
                    $('#sa-export-range').attr('data-sa-open', "false");
                    jQuery('body').removeClass('modal-open');
                    $('#sa-managing-overlay').fadeOut(150);

                    sa_action_message("error", sa_admin_labels["cant_get_stat_msg"]);

                    return false;
                }

                $.each(camps_ads_statistics, function (camp_id, camp_ads_statistics) {
                    /** Draw campaign stat */
                    var camp_stat = camp_ads_statistics['camp_stat'];
                    var camp_stat_cont = $(".sa-stat-block[data-sa-camp-id='" + camp_id + "']");
                    var camp_title = camp_stat_cont.attr("data-sa-camp-title");

                    camp_stat_cont.closest(".sa-stat-cont").find(".sa-stat-filter").find('input[type="text"]').val('');
                    camp_stat_cont.closest(".sa-stat-cont").find(".sa-slide-opener").addClass("sa-camp-stat-opener");
                    camp_stat_cont.closest(".sa-stat-cont").find(".sa-camp-stat-opener").attr("data-sa-open-slide", 'false');
                    camp_stat_cont.closest(".sa-stat-cont").find(".sa-sliding-block").attr("data-sa-open", 'false');

                    saMakeCampChart(camp_stat_cont, camp_stat, camp_title);

                    /** Draw ads stats */
                    var ads_statistics = camp_ads_statistics["ads_stats"];

                    if (ads_statistics) {
                        $.each(ads_statistics, function (ad_id, ad_stat) {
                            var ad_stat_cont = $(".sa-stat-block[data-sa-ad-id='" + ad_id + "']");
                            var ad_title = ad_stat_cont.attr("data-sa-ad-title");

                            ad_stat_cont.closest(".sa-stat-cont").find(".sa-stat-filter").find('input[type="text"]').val('');
                            ad_stat_cont.closest(".sa-stat-cont").find(".sa-slide-opener").addClass("sa-ad-stat-opener");
                            ad_stat_cont.closest(".sa-stat-cont").find(".sa-camp-stat-opener").attr("data-sa-open-slide", 'false');
                            ad_stat_cont.closest(".sa-stat-cont").find(".sa-sliding-block").attr("data-sa-open", 'false');

                            saMakeAdChart(ad_stat_cont, ad_stat, ad_title);
                        });
                    }
                });

                /** Export charts */
                var doc = new jsPDF("l", "mm", "a4");

                var range_date = '';

                if (from_date != '' && to_date != '') {
                    range_date = '<span style="font-weight:bold;font-size:12px;">' + sa_admin_labels["stat_from_place"] + ' </span><span style="font-size:12px;">' + from_date + '</span><span style="font-weight:bold;font-size:12px;"> ' + sa_admin_labels["stat_to_place"] + ' </span> <span style="font-size:12px;">' + to_date + '</span>';
                } else if (from_date != '') {
                    range_date = '<span style="font-weight:bold;font-size:12px;">' + sa_admin_labels["stat_from_place"] + ' </span><span style="font-size:12px;">' + from_date + '</span>';
                } else if (to_date != '') {
                    range_date = '<span style="font-weight:bold;font-size:12px;">' + sa_admin_labels["stat_to_place"] + ' </span><span style="font-size:12px;">' + to_date + '</span>';
                }

                if (camp_id != "") {

                    var imageData = $('[data-sa-campaign-id="' + camp_id + '"]').find(".sa-campaign-stat").highcharts().createCanvas(range_date);

                    var stat_count = $('[data-sa-campaign-id="' + camp_id + '"]').find(".sa-stat-container").length;

                    doc.addImage(imageData, 'JPEG', 15, 15, 257, 170);

                    if (stat_count != 0) {
                        doc.addPage();
                    }

                    $('[data-sa-campaign-id="' + camp_id + '"]').find(".sa-stat-container").each(function (index) {

                        var imageData = $(this).highcharts().createCanvas(range_date);

                        doc.addImage(imageData, 'JPEG', 15, 15, 257, 170);

                        if (index + 1 < stat_count) {
                            doc.addPage();
                        }
                    });
                    //save with name
                    doc.save('smartad-stats.pdf');
                } else if (camp_id == "") {

                    //loop through each chart
                    var camps_count = $(".sa-campaign-block").length;
                    $.each($(".sa-campaign-block"), function (index) {
                        var imageData = $(this).closest($(this)).find(".sa-campaign-stat").highcharts().createCanvas(range_date);

                        var stat_count = $(this).find(".sa-stat-container").length;

                        doc.addImage(imageData, 'JPEG', 15, 15, 257, 170);

                        if (index + 1 < camps_count || stat_count != 0) {
                            doc.addPage();
                        }

                        $(this).find(".sa-stat-container").each(function (jindex) {

                            var imageData = $(this).highcharts().createCanvas(range_date);

                            doc.addImage(imageData, 'JPEG', 15, 15, 257, 170);

                            if (index + 1 < camps_count || jindex + 1 < stat_count) {
                                doc.addPage();
                            }
                        });
                    });

                    //save with name
                    doc.save('smartad-stats.pdf');
                }
            },
            error: function () {
                sa_action_message("error", sa_admin_labels["cant_get_stat_msg"]);
            },
            complete: function () {
                // hide spinner
                that_button.closest(".sa-waiting-wrapper").removeClass('sa-waiting-button');

                /** Hide popup */
                $('#sa-export-range').attr('data-sa-open', "false");
                jQuery('body').removeClass('modal-open');
                $('#sa-managing-overlay').fadeOut(150);
            }
        });
    });

    // Open campaign when clicked on campaign name
    $(document).on("click", ".sa-campaign-name", function () {
        if ($(this).closest(".sa-slide-opener").attr("data-sa-open-slide") == "false") {
            $(this).closest(".sa-slide-opener").trigger("click");
        }
    });

    $(document).on("focus", ".sa-ad-name, .sa-campaign-name", function () {
        $(this).removeClass("sa-suspended-input");
    }).on("blur", ".sa-ad-name, .sa-campaign-name", function () {
        $(this).addClass("sa-suspended-input");
    });

    /**
     * Display detailed description of field
     */
    $(document).on("click", ".sa-with-question", function () {
        sa_action_message("info", $(this).attr("data-sa-message"));
    });

    /**
     * Filter ads by status
     */
    $(document).on('click', '.sa-ads-filter li', function () {

        /** Change selected status */
        $(this).closest(".sa-campaign-block").find('.sa-ad-status-name').removeClass('sa-selected-status');
        $(this).find('.sa-ad-status-name').addClass('sa-selected-status');
        var filter_by = $(this).attr('data-sa-ad-filter');
        if (filter_by == "all") {
            $(this).closest(".sa-campaign-block").find('.sa-ad-block').removeClass('sa-ad-hidden');
        } else {
            $(this).closest(".sa-campaign-block").find('.sa-ad-block').each(function () {
                if ($(this).attr('data-sa-status') == filter_by) {
                    $(this).removeClass('sa-ad-hidden');
                } else {
                    $(this).addClass('sa-ad-hidden');
                }
            });
        }
    });

    /**
     * Import already setted tags
     */
    $(".sa-tags").each(function () {

        var tag_values = $(this).find(".sa-tags-values").data("sa-tags-values");
        tag_values = tag_values.split("%smartad%,");

        for (var i = 0; i < tag_values.length; i++) {
            var tag_value = tag_values[i];

            if (i == tag_values.length - 1) {
                tag_value = tag_value.substr(0, tag_value.indexOf('%smartad%'));
            }

            if (tag_value != "") {
                var tag_text = tag_value.split("%").slice(2);
                var tag_type = tag_value.substr(0, tag_value.indexOf('%'));
                tag_value = tag_value + "%smartad%";

                $(this).find(".typeahead-auto").tagsinput('add', {"value": tag_value, "text": tag_text, "type": tag_type});
            }
        }
    });

    /**
     * Export campaign statistics
     */
    $(document).on("click", ".sa-export-single-stat", function () {
        if (ie_version && ie_version <= 9) {
            sa_action_message("info", sa_admin_labels["update_browser"]);
            return false;
        }
        var container = $(this).closest('.sa-stat-cont').find('.sa-stat-block');
        var from = $.datepicker.formatDate("yy-mm-dd", $(this).closest(".sa-stat-filter").find(".sa-stat-from").datepicker('getDate'));
        var to = $.datepicker.formatDate("yy-mm-dd", $(this).closest(".sa-stat-filter").find(".sa-stat-to").datepicker('getDate'));

        if ($(this).closest('.sa-export-single-stat').hasClass('sa-export-camp-stat')) {
            saCreateCampChart(container, from, to, true);
        } else if ($(this).closest('.sa-export-single-stat').hasClass('sa-export-ad-stat')) {
            saCreateAdChart(container, from, to, true);
        }
    });

    /**
     * Save all campaigns with ads
     */
    $(document).on('click', '#sa-update-all', function (e) {
        $('.sa-deadline-date').each(function () {
            if ($(this).val() == '') {
                $(this).next('[type="hidden"]').val('');
            }
        });

        // Display spinner
        $(this).closest(".sa-waiting-wrapper").addClass('sa-waiting-button');
        e.preventDefault();

        /** Check required fields */
        var is_error_exist = false;

        // check requireds
        $("#sa-campaigns-block").find('.sa-required').each(function () {
            if ($(this).val() == "") {
                $(this).addClass('sa-error-input');
                $(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message", $(this).closest('.sa-form-item').find('.sa-input-message').text());
                $(this).closest('.sa-form-item').find('.sa-input-message').addClass('sa-error-valid');
                $(this).closest('.sa-form-item').find('.sa-input-message').text(sa_admin_labels["required_filed_error"]);
                is_error_exist = true;
            } else {
                $(this).removeClass('sa-error-input');
                $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
            }
        });

        // Check links
        $("#sa-campaigns-block").find('.sa-link').each(function () {
            if ($(this).val() !== "") {
                if (!saIsUrl($(this).val())) {
                    $(this).addClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message", $(this).closest('.sa-form-item').find('.sa-input-message').text());
                    $(this).closest('.sa-form-item').find('.sa-input-message').addClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text(sa_admin_labels["valid_url_error"]);
                    is_error_exist = true;
                } else {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            } else {
                if (!$(this).hasClass("sa-required")) {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            }
        });

        // Check positive integers
        $("#sa-campaigns-block").find('.sa-positive-int').each(function () {
            if ($(this).val() !== "") {
                if (!saIsPositiveInteger($(this).val())) {
                    $(this).addClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message", $(this).closest('.sa-form-item').find('.sa-input-message').text());
                    $(this).closest('.sa-form-item').find('.sa-input-message').addClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text(sa_admin_labels["positive_int_error"]);
                    is_error_exist = true;
                } else {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            } else {
                if (!$(this).hasClass("sa-required")) {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            }
        });

        // Check size
        $("#sa-campaigns-block").find('.sa-size').each(function () {
            if ($(this).val() !== "") {
                if (!saIsSize($(this).val())) {
                    $(this).addClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message", $(this).closest('.sa-form-item').find('.sa-input-message').text());
                    $(this).closest('.sa-form-item').find('.sa-input-message').addClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text(sa_admin_labels["positive_int_error"] + ' ' + '(px/%)');
                    is_error_exist = true;
                } else {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            } else {
                if (!$(this).hasClass("sa-required")) {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            }
        });

        // Check video urls
        $("#sa-campaigns-block").find('.sa-video-url').each(function () {
            if ($(this).val() !== "") {
                var parsed_url = urlParser.parse($(this).val());
                if (parsed_url == undefined || (parsed_url['provider'] != 'youtube' && parsed_url['provider'] != 'vimeo')) {
                    $(this).addClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message", $(this).closest('.sa-form-item').find('.sa-input-message').text());
                    $(this).closest('.sa-form-item').find('.sa-input-message').addClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text(sa_admin_labels["valid_url_error"]);
                    is_error_exist = true;
                } else {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            } else {
                if (!$(this).hasClass("sa-required")) {
                    $(this).removeClass('sa-error-input');
                    $(this).closest('.sa-form-item').find('.sa-input-message').removeClass('sa-error-valid');
                    $(this).closest('.sa-form-item').find('.sa-input-message').text($(this).closest('.sa-form-item').find('.sa-input-message').attr("data-sa-valid-message"));
                }
            }
        });

        if (is_error_exist == true) {
            $(this).closest(".sa-waiting-wrapper").removeClass('sa-waiting-button');
            sa_action_message("error", sa_admin_labels["check_form_req_msg"]);
            return false;
        }

        var all_camps = {};

        $(".sa-save-campaign-options").each(function () {

            var camp_include_tags = $(this).closest(".sa-campaign-settings").find(".sa_tag_include").find(".typeahead-auto").val();
            var camp_exclude_tags = $(this).closest(".sa-campaign-settings").find(".sa_tag_exclude").find(".typeahead-auto").val();

            var campaign_name = $(this).closest('.sa-campaign-block').find(".sa-campaign-name").val();
            var campaign_options = $(this).closest('.sa-campaign-block').find('.sa-campaign-options-form').serializeArray();

            campaign_options.push({name: "campaign_name", value: campaign_name});
            campaign_options.push({name: "camp_include_tags", value: camp_include_tags});
            campaign_options.push({name: "camp_exclude_tags", value: camp_exclude_tags});

            var campaign_id = $(this).attr('sa-data-campaign-id');
            all_camps[campaign_id] = [];
            all_camps[campaign_id].push(campaign_options);

            /**
             * Save new and update old ads
             */
            var closest_campaign = $(this).closest('.sa-campaign-block');
            var ads = new Array();
            closest_campaign.find('.sa-ad-form').each(function () {
                var ad_data = $(this).serializeArray();

                if (ad_data[4]['value'] == 'video' && ad_data[10]['value'] != '') {
                    var origin_url = ad_data[10]['value'];
                    var url_data = new Object;
                    url_data['parsed'] = urlParser.parse(origin_url);
                    url_data['origin_url'] = origin_url;
                    ad_data[10]['value'] = JSON.stringify(url_data)
                }

                var ad_include_tags = $(this).find(".sa_tag_include").find(".typeahead-auto").val();
                var ad_exclude_tags = $(this).find(".sa_tag_exclude").find(".typeahead-auto").val();

                ad_data.push({name: "ad_include_tags", value: ad_include_tags});
                ad_data.push({name: "ad_exclude_tags", value: ad_exclude_tags});

                ads.push(ad_data);

                // check if ad overdue
                var current_date = new Date();
                current_date.setHours(0, 0, 0, 0);
                var ad_deadline = new Date(ad_data[7]['value']);

                if (current_date.getTime() > ad_deadline.getTime()) {
                    $(this).find('.sa-deadline-date').addClass('sa-overdue-ad');
                } else {
                    $(this).find('.sa-deadline-date').removeClass('sa-overdue-ad');
                }

                var views = $(this).find('.sa-views-count div').first().text();
                var restrict_views = ad_data[8]['value'];

                if (parseInt(views) > parseInt(restrict_views)) {
                    $(this).find('[name="restrict_views"]').addClass('sa-overdue-ad');
                } else {
                    $(this).find('[name="restrict_views"]').removeClass('sa-overdue-ad');
                }

                var visits = $(this).find('.sa-visits-count div').first().text();
                var restrict_visits = ad_data[9]['value'];

                if (parseInt(visits) > parseInt(restrict_visits)) {
                    $(this).find('[name="restrict_visits"]').addClass('sa-overdue-ad');
                } else {
                    $(this).find('[name="restrict_visits"]').removeClass('sa-overdue-ad');
                }
            });

            all_camps[campaign_id].push(ads);

            e.stopPropagation();
        });

        /** Ajax request for update all campaigns */
        $.ajax({
            type: "POST",
            url: ajax_url,
            dataType: "json",
            data: {
                action: "sa_ajax_update_all_camps",
                all_camps: all_camps,
            },
            success: function (response) {
                if (response['success'] == 1) {
                    sa_action_message("success", sa_admin_labels["camps_updated_msg"]);
                    $(".sa-campaign-block").attr("data-sa-camp-changed", "0");
                } else {
                    sa_action_message("error", sa_admin_labels["update_failed_msg"]);
                }
            },
            error: function () {
                sa_action_message("error", sa_admin_labels["update_failed_msg"]);
            },
            complete: function () {
                // Remove spinner
                $("#sa-update-all").closest(".sa-waiting-wrapper").removeClass('sa-waiting-button');
            }
        });
    });

    /**
     * Select datepicker and colorpicker input text on click event
     */
    $(document).on('click', '.hasDatepicker, .sa-colorpicker', function () {
        $(this).select();
    });

    /**
     * Let use only backspace and delete keys on datepicker and colorpicker inputs
     */
    $(document).on('keydown', '.hasDatepicker, .sa-colorpicker', function (e) {
        if (e.which != 46 && e.which != 8) {
            return false;
        } else {
            $(this).val('');
        }
    });

    /**
     * Select inner text when clicked on element with sa-click-select class
     */
    $(document).on('click', '.sa-click-select', function () {
        saSelectAll($(this).get(0));
    });
    
    /*
     * update anti-cache checkbox   
     */
    jQuery(document).on("change", "#sa-cache-enable" ,function(){
    
        var extra_options = {};
        extra_options.sa_cache_enabled = this.checked;

        $.ajax({
            type: "POST",
            url: ajax_url,
            dataType: "json",
            data: {
                action: "sa_ajax_update_extra_options",
                sa_extra_options: extra_options,
            },
            success: function (response) {
                if (response['success'] == 1) {
                    sa_action_message("success", sa_admin_labels["success_update_msg"]);
                } else {
                    sa_action_message("error", sa_admin_labels["update_failed_msg"]);
                }
            },
            error: function () {
                sa_action_message("error", sa_admin_labels["update_failed_msg"]);
            }
        });

    });
    
    // desable sa-new class
    if(typeof sa_new != 'undefined' && sa_new == false){
        $('.sa-new').each(function(){
            $(this).addClass('sa-new-hide');
        });
    }
    
});