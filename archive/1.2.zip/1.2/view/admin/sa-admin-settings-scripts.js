jQuery(document).ready(function ($) {
    /*
     * set CodeMirror textareas values
     */
    var code_areas = document.getElementsByClassName("sa-code-area");
    var myCodeMirrors = {};
    myCodeMirrors.customCss = CodeMirror.fromTextArea(code_areas[0], {
        lineNumbers: true,
        mode: "htmlmixed",
    });
    myCodeMirrors.warningText = CodeMirror.fromTextArea(code_areas[1], {
        lineNumbers: true,
        mode: "htmlmixed",
    });
    myCodeMirrors.customCss.setValue($('#sa-custom-css-value').val());
    myCodeMirrors.warningText.setValue($('#sa-warning-text-value').val());
    
    /*
     * Display Success or Error message
     */
    function sa_action_message(message_type, message_text) {
        if (message_text === undefined) {
            message_text = message_type;
            if (message_text == "error") {
                message_text = "Error";
            } else if (message_text == "success") {
                message_text = "Success";
            }
        }

        //Determine message show time

        var message_length = message_text.length;
        var show_time = 70 * message_length;
        if (show_time < 2100) {
            show_time = 2100;
        }

        message_text = "<div>" + message_text + "</div>"

        message_text = jQuery(message_text);

        if (typeof message_time !== 'undefined') {
            clearTimeout(message_time);
        }
        jQuery("#sa-message-popup").removeClass("sa-error-message");
        jQuery("#sa-message-popup").removeClass("sa-success-message");
        jQuery("#sa-message-popup").removeClass("sa-confirm-message");
        jQuery("#sa-message-popup").removeClass("sa-transit-450");
        jQuery('#sa-message-popup').attr('data-sa-open', "false");

        jQuery("#sa-message-popup").find('p').empty();
        jQuery("#sa-message-popup").addClass("sa-" + message_type + "-message");
        jQuery("#sa-message-popup").find('p').html(message_text);
        jQuery('#sa-message-popup').attr('data-sa-open', "true");

        message_time = setTimeout(function () {
            jQuery('#sa-message-popup').attr('data-sa-open', "false");

            jQuery("#sa-message-popup").removeClass("sa-" + message_type + "-message");
        }, show_time);
    }
    
    /**
     * Display detailed description of field
     */
    $(document).on("click", ".sa-with-question", function () {
        sa_action_message("info", $(this).attr("data-sa-message"));
    });
    
    /*
     *  save extra options 
     */
    $(document).on("click", "#sa-update-settings", function () {
        var warningTextEnabled;
        if ($('#sa-warning-text-enabled').is(":checked"))
            warningTextEnabled = 'true';
        else
            warningTextEnabled = 'false';
        var extra_options = {};
        extra_options.sa_custom_css = myCodeMirrors.customCss.getValue();
        extra_options.sa_warning_text = myCodeMirrors.warningText.getValue();
        extra_options.sa_warning_text_enabled = warningTextEnabled;

        sa_extra_options.sa_custom_css = myCodeMirrors.customCss.getValue();
        sa_extra_options.sa_warning_text = myCodeMirrors.warningText.getValue();
        sa_extra_options.sa_warning_text_enabled = warningTextEnabled;

        /** Ajax request for update extra options */
        $.ajax({
            type: "POST",
            url: ajax_url,
            dataType: "json",
            data: {
                action: "sa_ajax_update_extra_options",
                sa_extra_options: extra_options,
            },
            success: function (response) {
                if (response['success'] == 1) {
                    enaableLeavepage = false;
                    sa_action_message("success", sa_admin_labels["success_update_msg"]);
                } else {
                    sa_action_message("error", sa_admin_labels["update_failed_msg"]);
                }
            },
            error: function () {
                sa_action_message("error", sa_admin_labels["update_failed_msg"]);
            }
        });
    });
    
    /*
    * Show a prompt before the user leaves the current page
    */

    $(window).load(function () {
        $(document).on('change', 'input, textarea, select', function () {
            enaableLeavepage = true;
        });
    });

    $(window).bind('beforeunload', function () {
        if (typeof enaableLeavepage != 'undefined' && enaableLeavepage == true) {
            return sa_admin_labels['unsaved_reload'];
        }
    });
    
    // desable sa-new class 
    if(typeof sa_new != 'undefined' && sa_new == false){
        $('.sa-new').each(function(){
            $(this).addClass('sa-new-hide');
        });
    }
    
});