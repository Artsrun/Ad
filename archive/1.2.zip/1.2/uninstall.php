<?php
defined('ABSPATH') or die('No script kiddies please!');

// Include configurations
include 'includes/smartad-config.php';

//if uninstall not called from WordPress exit
if (!defined('WP_UNINSTALL_PLUGIN'))
    exit();

/**
 * Delete custom table and options created by plugin
 */
global $sa_uninstall;
$sa_tables = $sa_uninstall['sa_tables'];
$sa_options = $sa_uninstall['sa_options'];
if (function_exists( 'is_multisite' ) && is_multisite() ) {
   global $wpdb;   
   $old_blog =  $wpdb->blogid;
   //Get all blog ids
   $blogids =  $wpdb->get_col( "SELECT blog_id FROM $wpdb->blogs" );
    foreach ( $blogids as $blog_id ) {
        switch_to_blog($blog_id);
        foreach ($sa_tables as $sa_table){
            sa_delete_table($sa_table);
        }
        foreach ($sa_options as $sa_option){
            delete_option($sa_option);
        }
    }
   switch_to_blog( $old_blog );
} else {
    foreach ($sa_tables as $sa_table){
        sa_delete_table($sa_table);
    }
    foreach ($sa_options as $sa_option){
        delete_option($sa_option);
    }
}

function sa_delete_table($sa_table_name){
   global $wpdb;
   $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}$sa_table_name" );
}